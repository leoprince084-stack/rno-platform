# RNO — primeira versão de trabalho

Este pacote contém uma cópia de trabalho do `App.js` fornecido e uma primeira extensão da aplicação. O ficheiro original enviado nesta conversa não foi alterado.

## O que foi acrescentado nesta versão

- Menu inicial expandido com Estudos, Serviços, Comunicação, Publicidade e Finanças.
- Ecrã de Estudos com categorias pesquisáveis demonstrativas.
- Ecrã de Serviços com categorias profissionais pesquisáveis demonstrativas.
- Formulário inicial para preparar um pedido de táxi, ainda sem despacho para motoristas.
- Ecrã informativo de Pagamentos, sem processamento financeiro real.
- Rascunhos locais de mensagens, sem envio para outros utilizadores.
- Preparação local de pedidos de publicidade, sem publicar anúncios.
- Registo temporário de receitas e despesas para experimentar um orçamento; os dados desaparecem ao reiniciar a aplicação.
- Ecrã para consultar entregas do cliente.
- Correção do uso de `userId` não definido no registo da empresa e prevenção de apagar os campos do formulário antes de tentar gravar o perfil.

## Importante: estado real da aplicação

A base original já contém fluxos ligados ao Supabase para algumas funções, por exemplo produtos, vagas, autenticação, encomendas e entregas. As novas áreas listadas acima são **protótipos de interface e interação local**; não estão ligadas a tabelas do Supabase, não enviam mensagens, não despacham táxis, não cobram pagamentos e não publicam publicidade. Precisam de modelação da base de dados, políticas de acesso, integração e testes antes de produção.

Não execute SQL automaticamente. Não foi feita qualquer alteração ao teu projeto Expo Snack nem à base de dados Supabase real por esta cópia.

## Como abrir esta cópia localmente (quando estiveres preparado)

1. Descompacta `RNO_App_MVP.zip` numa pasta no computador.
2. Instala Node.js compatível com Expo SDK 58 (Node.js 22.13 ou superior é indicado na referência atual do Expo).
3. Abre a pasta do projeto numa ferramenta de programação, como Cursor, ou num terminal.
4. Executa `npm install` e depois `npx expo start`.
5. Revê todos os erros e testa o aplicativo antes de o usar ou publicar.

Se não quiseres instalar nada agora, mantém o Snack original intacto. A migração para esta cópia local é uma etapa separada.

## Segurança

- Nunca coloques palavras-passe, service-role keys, tokens privados ou chaves de fornecedores no código cliente.
- A chave `sb_publishable_...` existente no `App.js` é uma chave pública do cliente; a proteção dos dados depende também de políticas RLS e funções do servidor.
- Antes de produção, confirma as políticas RLS e valida todas as funções RPC do Supabase.

## Testes realizados aqui

- Verificação sintática JSX do `App.js`: sem erros de análise sintática.
- Não foi executado `npm install`, não foram feitas chamadas reais ao Supabase e não foi feito teste num dispositivo. Portanto, esta cópia não é ainda uma versão aprovada para publicação.
