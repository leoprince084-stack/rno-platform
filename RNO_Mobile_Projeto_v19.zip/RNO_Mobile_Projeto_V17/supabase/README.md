# Supabase — RNO V16

## Estado conhecido
- A RPC `empresa_listar_entregadores_ativos()` foi criada no projeto original pelo utilizador e confirmada com `SECURITY DEFINER = true` e `EXECUTE` para `authenticated`.
- O esquema existente mantém RLS ativo em `entregadores` e `entregas`; não há políticas diretas para as duas tabelas, pelo que a app deve utilizar apenas RPCs protegidas.

## SQL necessário antes de usar a nova interface
1. `V16_EMPRESAS_ATRIBUICAO_ENTREGAS.sql` cria `empresa_entregas_com_atribuicao()` e reforça `atribuir_entrega()` para impedir nova atribuição quando já existe um entregador atribuído.
2. Reveja o ficheiro inteiro antes de executar no SQL Editor do projeto Supabase original.

`EMPRESA_LISTAR_ENTREGADORES_ATIVOS.sql` é uma cópia do script que foi usado para criar a RPC existente; não é necessário executá-lo novamente se a função já existe e foi verificada.

Não executar migrations automaticamente. Não há chaves administrativas neste pacote. É obrigatório testar com uma conta de empresa e um entregador ativo antes de considerar a funcionalidade pronta para produção.
