# Estado do backend de entregas — confirmado pelo utilizador

O utilizador confirmou que estas RPCs já foram criadas/existem no Supabase e que os privilégios reportados são:

- `public.empresa_listar_entregadores_ativos()` — `RETURNS TABLE(id uuid, nome_completo text, telefone text, provincia text)`, `SECURITY DEFINER = true`, `authenticated` pode executar.
- `public.empresa_entregas_com_atribuicao()` — inclui dados de entrega, `entregador_id uuid` e `entregador_nome text`, `SECURITY DEFINER = true`, `authenticated` pode executar.
- `public.atribuir_entrega(uuid, uuid)` já existia.

Não execute novamente os scripts de criação dessas RPCs sem necessidade. Para testar, use sessões autenticadas reais e respeite as validações internas das funções. Não conceda SELECT/UPDATE direto nas tabelas `entregadores` ou `entregas` só para contornar a interface.
