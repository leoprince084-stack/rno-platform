-- RNO: listar entregadores ativos para uma empresa autenticada.
-- PROPOSTA: rever antes de executar no Supabase.
-- Esta função é a única alteração proposta; não cria tabelas nem altera dados existentes.
-- Pressuposto a confirmar: public.empresas.id corresponde a auth.uid() para contas de empresa.

CREATE OR REPLACE FUNCTION public.empresa_listar_entregadores_ativos()
RETURNS TABLE (
    id uuid,
    nome_completo text,
    telefone text,
    provincia text
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path TO ''
AS $function$
BEGIN
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'É necessário iniciar sessão.';
    END IF;

    -- Só contas com perfil de empresa podem consultar a lista.
    IF NOT EXISTS (
        SELECT 1
        FROM public.empresas AS e
        WHERE e.id = auth.uid()
    ) THEN
        RAISE EXCEPTION 'Acesso reservado a contas de empresa.';
    END IF;

    -- Expor apenas os campos necessários e apenas entregadores ativos.
    RETURN QUERY
    SELECT
        en.id,
        en.nome_completo,
        en.telefone,
        en.provincia
    FROM public.entregadores AS en
    WHERE en.ativo IS TRUE
    ORDER BY en.nome_completo;
END;
$function$;

-- A função é acessível a utilizadores autenticados; a própria função valida a conta.
REVOKE ALL ON FUNCTION public.empresa_listar_entregadores_ativos() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.empresa_listar_entregadores_ativos() FROM anon;
GRANT EXECUTE ON FUNCTION public.empresa_listar_entregadores_ativos() TO authenticated;

-- Depois de criar a função, testar com sessão de empresa e com sessão de não-empresa.
-- Não chamar admin_listar_entregadores pela interface da empresa.
