-- RNO V16: tornar a atribuição de entregas visível e impedir reatribuição acidental.
-- Rever antes de executar no projeto Supabase original.
-- Pré-requisito já confirmado pelo utilizador: public.empresa_listar_entregadores_ativos() existe.
-- Este script cria uma nova RPC para listar entregas com dados do entregador e substitui
-- a implementação de atribuir_entrega para rejeitar entregas já atribuídas.
-- Não cria tabelas nem altera registos existentes.

CREATE OR REPLACE FUNCTION public.empresa_entregas_com_atribuicao()
RETURNS TABLE (
    entrega_id uuid,
    encomenda_id uuid,
    cliente_id uuid,
    estado text,
    endereco_recolha text,
    endereco_entrega text,
    telefone_destinatario text,
    custo_entrega numeric,
    codigo_entrega text,
    observacoes text,
    created_at timestamp with time zone,
    atribuido_em timestamp with time zone,
    recolhido_em timestamp with time zone,
    entregue_em timestamp with time zone,
    entregador_id uuid,
    entregador_nome text
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path TO ''
AS $function$
BEGIN
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'É necessário iniciar sessão.';
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM public.empresas AS e
        WHERE e.id = auth.uid()
    ) THEN
        RAISE EXCEPTION 'Acesso reservado a contas de empresa.';
    END IF;

    RETURN QUERY
    SELECT
        d.id,
        d.encomenda_id,
        d.cliente_id,
        d.estado,
        d.endereco_recolha,
        d.endereco_entrega,
        d.telefone_destinatario,
        d.custo_entrega,
        d.codigo_entrega,
        d.observacoes,
        d.created_at,
        d.atribuido_em,
        d.recolhido_em,
        d.entregue_em,
        d.entregador_id,
        en.nome_completo
    FROM public.entregas AS d
    LEFT JOIN public.entregadores AS en
        ON en.id = d.entregador_id
    WHERE d.empresa_id = auth.uid()
    ORDER BY d.created_at DESC;
END;
$function$;

REVOKE ALL ON FUNCTION public.empresa_entregas_com_atribuicao() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.empresa_entregas_com_atribuicao() FROM anon;
GRANT EXECUTE ON FUNCTION public.empresa_entregas_com_atribuicao() TO authenticated;

CREATE OR REPLACE FUNCTION public.atribuir_entrega(p_entrega_id uuid, p_entregador_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO ''
AS $function$
DECLARE
    v_estado text;
    v_entregador_atual uuid;
BEGIN
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'É necessário iniciar sessão.';
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM public.entregadores AS en
        WHERE en.id = p_entregador_id
          AND en.ativo IS TRUE
    ) THEN
        RAISE EXCEPTION 'O utilizador não está registado como entregador activo.';
    END IF;

    SELECT d.estado, d.entregador_id
    INTO v_estado, v_entregador_atual
    FROM public.entregas AS d
    WHERE d.id = p_entrega_id
      AND d.empresa_id = auth.uid()
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Entrega não encontrada ou não pertence à sua empresa.';
    END IF;

    IF v_estado IS DISTINCT FROM 'Aguardando recolha' THEN
        RAISE EXCEPTION 'A entrega deve estar a aguardar recolha.';
    END IF;

    IF v_entregador_atual IS NOT NULL THEN
        RAISE EXCEPTION 'Esta entrega já tem um entregador atribuído.';
    END IF;

    UPDATE public.entregas
    SET entregador_id = p_entregador_id,
        atribuido_em = pg_catalog.now(),
        updated_at = pg_catalog.now()
    WHERE id = p_entrega_id
      AND empresa_id = auth.uid()
      AND entregador_id IS NULL;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'A entrega foi atualizada por outra ação. Atualize a lista e tente novamente.';
    END IF;

    RETURN true;
END;
$function$;

REVOKE ALL ON FUNCTION public.atribuir_entrega(uuid, uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.atribuir_entrega(uuid, uuid) FROM anon;
GRANT EXECUTE ON FUNCTION public.atribuir_entrega(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.atribuir_entrega(uuid, uuid) TO service_role;

-- Depois de executar, verificar as funções em pg_proc e testar com uma conta de empresa.
-- Não chamar funções administrativas a partir da interface da empresa.
