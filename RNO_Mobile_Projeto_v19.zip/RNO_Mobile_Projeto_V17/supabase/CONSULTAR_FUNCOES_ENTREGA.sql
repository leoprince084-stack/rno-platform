-- RNO — Consulta de diagnóstico somente leitura.
-- Este script NÃO cria nem altera tabelas, funções, políticas ou dados.
-- Executar no Supabase Dashboard > SQL Editor, no projeto Supabase original.

SELECT
  n.nspname AS schema_name,
  p.proname AS function_name,
  pg_get_function_identity_arguments(p.oid) AS arguments,
  pg_get_function_result(p.oid) AS returns,
  p.prosecdef AS security_definer,
  pg_get_functiondef(p.oid) AS definition
FROM pg_proc AS p
JOIN pg_namespace AS n ON n.oid = p.pronamespace
WHERE n.nspname = 'public'
  AND p.proname IN (
    'atualizar_estado_entrega',
    'atualizar_estado_entregador',
    'solicitar_entrega',
    'entregas_empresa',
    'minhas_entregas',
    'minhas_entregas_como_entregador'
  )
ORDER BY p.proname, pg_get_function_identity_arguments(p.oid);
