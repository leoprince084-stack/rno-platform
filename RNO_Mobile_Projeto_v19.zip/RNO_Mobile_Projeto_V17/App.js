import React, { useState, useEffect, useRef } from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  Image,
  StyleSheet,
  StatusBar,
  Pressable,
  TextInput,
  Alert,
} from 'react-native';

import * as ImagePicker from 'expo-image-picker';
import rnoStorage from './lib/storage';

const SUPABASE_URL = 'https://bwkpmirlwrsbeiavzapm.supabase.co';
const SUPABASE_KEY =    "sb_publishable_m5Z5nOdirdaXyoaOoA-fxg_Y_zlNuXJ";
// A página web existente da RNO conclui a alteração da palavra-passe após o link do email.
const URL_RECUPERACAO_SENHA = 'https://leoprince084-stack.github.io/rno-platform/nova-senha.html';
const servicos = [
  { emoji: '💼', titulo: 'Emprego', descricao: 'Encontre oportunidades' },
  { emoji: '🛍️', titulo: 'Loja Online', descricao: 'Descubra e compre produtos' },
  { emoji: '🚚', titulo: 'Entregas', descricao: 'Envie e receba encomendas' },
  { emoji: '🚕', titulo: 'Táxi', descricao: 'Prepare um pedido de viagem' },
  { emoji: '💳', titulo: 'Pagamentos', descricao: 'Consulte opções de pagamento' },
  { emoji: '🏢', titulo: 'Empresas', descricao: 'Conheça os negócios' },
  { emoji: '🎓', titulo: 'Estudos', descricao: 'Cursos, bolsas e formação' },
  { emoji: '🧰', titulo: 'Serviços', descricao: 'Encontre profissionais' },
  { emoji: '💬', titulo: 'Comunicação', descricao: 'Mensagens e contactos' },
  { emoji: '📣', titulo: 'Publicidade', descricao: 'Promova o seu negócio' },
  { emoji: '💰', titulo: 'Finanças', descricao: 'Organize o seu orçamento' },
];

// Conteúdo de demonstração. Estes registos não são ofertas comerciais reais.
const exemplosEstudo = [
  { id: 'est-1', titulo: 'Bolsas de estudo', categoria: 'Bolsas', descricao: 'Consulte oportunidades de financiamento e prepare os seus documentos.' },
  { id: 'est-2', titulo: 'Cursos técnicos', categoria: 'Cursos', descricao: 'Formação profissional, competências digitais e áreas técnicas.' },
  { id: 'est-3', titulo: 'Cursos online', categoria: 'Online', descricao: 'Aprendizagem à distância e conteúdos para desenvolver competências.' },
  { id: 'est-4', titulo: 'Explicações e tutoria', categoria: 'Tutoria', descricao: 'Apoio ao estudo e preparação para exames.' },
];

const exemplosServicos = [
  { id: 'srv-1', nome: 'Informática e reparações', categoria: 'Tecnologia', descricao: 'Instalação, manutenção e apoio técnico.' },
  { id: 'srv-2', nome: 'Eletricistas', categoria: 'Casa', descricao: 'Instalações e pequenos trabalhos elétricos.' },
  { id: 'srv-3', nome: 'Canalizadores', categoria: 'Casa', descricao: 'Manutenção de canalização e instalações.' },
  { id: 'srv-4', nome: 'Cabeleireiros e beleza', categoria: 'Beleza', descricao: 'Cabelo, tranças, manicure e cuidados pessoais.' },
  { id: 'srv-5', nome: 'Explicadores', categoria: 'Educação', descricao: 'Apoio escolar e explicações individuais.' },
  { id: 'srv-6', nome: 'Limpeza e manutenção', categoria: 'Casa', descricao: 'Apoio doméstico e manutenção de espaços.' },
];

function interpretarResultadoBooleanoRPC(texto) {
  if (typeof texto !== 'string') return texto === true;
  try {
    const valor = JSON.parse(texto);
    return valor === true || valor === 'true';
  } catch {
    return texto.trim().replace(/^"|"$/g, '').toLowerCase() === 'true';
  }
}

function extrairMensagemErroRPC(texto, fallback) {
  if (!texto || !String(texto).trim()) return fallback;
  try {
    const dados = JSON.parse(texto);
    return dados?.message || dados?.details || dados?.hint || dados?.error_description || fallback;
  } catch {
    return String(texto);
  }
}

export default function App() {
  const [pagina, setPagina] = useState('inicio');
  const [enderecoEntregaCliente, setEnderecoEntregaCliente] = useState('');
const [telefoneEntregaCliente, setTelefoneEntregaCliente] = useState('');
const [observacoesEntregaCliente, setObservacoesEntregaCliente] = useState('');
  const [encomendasVendedor, setEncomendasVendedor] = useState([]);
const [carregandoEncomendasVendedor, setCarregandoEncomendasVendedor] = useState(false);
const [erroEncomendasVendedor, setErroEncomendasVendedor] = useState('');
// O formulário de entrega mantém um rascunho separado por encomenda,
// para não reutilizar moradas, custos ou observações de outra encomenda.
const [rascunhosEntregaPorEncomenda, setRascunhosEntregaPorEncomenda] = useState({});
  const [encomendasCandidato, setEncomendasCandidato] = useState([]);
const [carregandoEncomendas, setCarregandoEncomendas] = useState(false);
const [erroEncomendas, setErroEncomendas] = useState('');
  const [servicoSelecionado, setServicoSelecionado] = useState('');
const [vagas, setVagas] = useState([]);
const [pesquisaVagas, setPesquisaVagas] = useState('');
const [provinciaFiltro, setProvinciaFiltro] = useState('Todas');
const [tipoEmpregoFiltro, setTipoEmpregoFiltro] = useState('Todos');
const [vagaSelecionada, setVagaSelecionada] = useState(null);
const scrollVagasRef = useRef(null);
const offsetVagasRef = useRef(0);
const [emailCandidato, setEmailCandidato] = useState('');

const [nomeCandidato, setNomeCandidato] = useState('');
const [telefoneCandidato, setTelefoneCandidato] = useState('');
const [mensagemCandidatura, setMensagemCandidatura] = useState('');

const [enviandoCandidatura, setEnviandoCandidatura] = useState(false);
const [estadoEnvioCandidatura, setEstadoEnvioCandidatura] = useState('');

const [senhaCandidato, setSenhaCandidato] = useState('');
const [aEntrarCandidato, setAEntrarCandidato] = useState(false);
const [sessaoCandidato, setSessaoCandidato] = useState(null);

// Dados do formulário de criação de conta de candidato.
const [nomeCadastroCandidato, setNomeCadastroCandidato] = useState('');
const [telefoneCadastroCandidato, setTelefoneCadastroCandidato] = useState('');
const [provinciaCadastroCandidato, setProvinciaCadastroCandidato] = useState('');
const [areaCadastroCandidato, setAreaCadastroCandidato] = useState('');
const [experienciaCadastroCandidato, setExperienciaCadastroCandidato] = useState('');
const [emailCadastroCandidato, setEmailCadastroCandidato] = useState('');
const [senhaCadastroCandidato, setSenhaCadastroCandidato] = useState('');
const [confirmarSenhaCadastroCandidato, setConfirmarSenhaCadastroCandidato] = useState('');
const [mensagemCadastroCandidato, setMensagemCadastroCandidato] = useState('');
const [aCadastrarCandidato, setACadastrarCandidato] = useState(false);
const [emailEmpresa, setEmailEmpresa] = useState('');

const [nomeEmpresaCadastro, setNomeEmpresaCadastro] = useState('');
const [responsavelEmpresaCadastro, setResponsavelEmpresaCadastro] = useState('');
const [telefoneEmpresaCadastro, setTelefoneEmpresaCadastro] = useState('');
const [provinciaEmpresaCadastro, setProvinciaEmpresaCadastro] = useState('');
const [areaEmpresaCadastro, setAreaEmpresaCadastro] = useState('');
const [descricaoEmpresaCadastro, setDescricaoEmpresaCadastro] = useState('');
const [mensagemCadastroEmpresa, setMensagemCadastroEmpresa] = useState('');
const [aCadastrarEmpresa, setACadastrarEmpresa] = useState(false);

const [senhaEmpresa, setSenhaEmpresa] = useState('');
const [confirmarSenhaEmpresaCadastro, setConfirmarSenhaEmpresaCadastro] = useState('');
const [sessaoEmpresa, setSessaoEmpresa] = useState(null);
const [sessaoEmpresaPendentePerfil, setSessaoEmpresaPendentePerfil] = useState(null);
const [aCompletarPerfilEmpresa, setACompletarPerfilEmpresa] = useState(false);

const [sessaoAdmin, setSessaoAdmin] = useState(null);

const [emailAdmin, setEmailAdmin] = useState('leoprince084@gmail.com');
const [senhaAdmin, setSenhaAdmin] = useState('');

const [mensagemEmpresa, setMensagemEmpresa] = useState('');
const [mensagemEstadoCandidatura, setMensagemEstadoCandidatura] = useState('');
const [candidaturasEmpresa, setCandidaturasEmpresa] = useState([]);
const [carregandoCandidaturasEmpresa, setCarregandoCandidaturasEmpresa] = useState(false);
const [erroCandidaturasEmpresa, setErroCandidaturasEmpresa] = useState('');
const [candidaturasCandidato, setCandidaturasCandidato] = useState([]);
const [perfilCandidato, setPerfilCandidato] = useState(null);
const [carregandoPerfil, setCarregandoPerfil] = useState(false);
const [erroPerfil, setErroPerfil] = useState('');
const [mensagemPerfil, setMensagemPerfil] = useState('');
const [editarPerfil, setEditarPerfil] = useState(false);

const [nomePerfil, setNomePerfil] = useState('');
const [telefonePerfil, setTelefonePerfil] = useState('');
const [emailPerfil, setEmailPerfil] = useState('');
const [provinciaPerfil, setProvinciaPerfil] = useState('');
const [areaPerfil, setAreaPerfil] = useState('');
const [experienciaPerfil, setExperienciaPerfil] = useState('');
const [carregandoCandidaturasCandidato, setCarregandoCandidaturasCandidato] = useState(false);
const [erroCandidaturasCandidato, setErroCandidaturasCandidato] = useState('');
const [mensagemLogin, setMensagemLogin] = useState('');
const [emailRecuperacaoSenha, setEmailRecuperacaoSenha] = useState('');
const [aEnviarRecuperacaoSenha, setAEnviarRecuperacaoSenha] = useState(false);
const [mensagemRecuperacaoSenha, setMensagemRecuperacaoSenha] = useState('');
const [paginaAnteriorRecuperacaoSenha, setPaginaAnteriorRecuperacaoSenha] = useState('login');
const [carregandoVagas, setCarregandoVagas] = useState(false);
const [erroVagas, setErroVagas] = useState('');

// Gestão de vagas da empresa: utiliza apenas a tabela vagas já existente no Supabase.
const [tituloNovaVaga, setTituloNovaVaga] = useState('');
const [localizacaoNovaVaga, setLocalizacaoNovaVaga] = useState('');
const [tipoNovaVaga, setTipoNovaVaga] = useState('');
const [descricaoNovaVaga, setDescricaoNovaVaga] = useState('');
const [requisitosNovaVaga, setRequisitosNovaVaga] = useState('');
const [salarioNovaVaga, setSalarioNovaVaga] = useState('');
const [contactoNovaVaga, setContactoNovaVaga] = useState('');
const [mensagemPublicarVaga, setMensagemPublicarVaga] = useState('');
const [aPublicarVaga, setAPublicarVaga] = useState(false);
const [vagasEmpresa, setVagasEmpresa] = useState([]);
const [vagasEmpresaCarregada, setVagasEmpresaCarregada] = useState(false);
const [carregandoVagasEmpresa, setCarregandoVagasEmpresa] = useState(false);
const [erroVagasEmpresa, setErroVagasEmpresa] = useState('');
const [produtos, setProdutos] = useState([]);
const [pesquisaProduto, setPesquisaProduto] = useState('');
const [categoriaFiltroProduto, setCategoriaFiltroProduto] = useState('Todas');
const [ordenacaoProduto, setOrdenacaoProduto] = useState('recomendados');
const [produtoSelecionado, setProdutoSelecionado] = useState(null);
const [carregandoProdutos, setCarregandoProdutos] = useState(false);
const [erroProdutos, setErroProdutos] = useState('');
const [empresasPublicas, setEmpresasPublicas] = useState([]);
const [carregandoEmpresasPublicas, setCarregandoEmpresasPublicas] = useState(false);
const [erroEmpresasPublicas, setErroEmpresasPublicas] = useState('');
const [produtosVendedor, setProdutosVendedor] = useState([]);
const [carregandoProdutosVendedor, setCarregandoProdutosVendedor] = useState(false);
const [erroProdutosVendedor, setErroProdutosVendedor] = useState('');
const [nomeNovoProduto, setNomeNovoProduto] = useState('');
const [descricaoNovoProduto, setDescricaoNovoProduto] = useState('');
const [precoNovoProduto, setPrecoNovoProduto] = useState('');
const [stockNovoProduto, setStockNovoProduto] = useState('');
const [categoriaNovoProduto, setCategoriaNovoProduto] = useState('');
const [imagemNovoProduto, setImagemNovoProduto] = useState('');

const [fotografiaProduto, setFotografiaProduto] = useState(null);

const [mensagemNovoProduto, setMensagemNovoProduto] = useState('');
const [aGuardarProduto, setAGuardarProduto] = useState(false);
const [carrinho, setCarrinho] = useState([]);
const [mensagemCarrinho, setMensagemCarrinho] = useState('');

const [processandoEncomenda, setProcessandoEncomenda] = useState(false);
const [mensagemEncomenda, setMensagemEncomenda] = useState('');

const [nomeEntregador, setNomeEntregador] = useState('');
const [telefoneEntregador, setTelefoneEntregador] = useState('');
const [provinciaEntregador, setProvinciaEntregador] = useState('');
const [mensagemEntregador, setMensagemEntregador] = useState('');
const [aRegistarEntregador, setARegistarEntregador] = useState(false);
const [estadoEntregador, setEstadoEntregador] = useState(null);

const [entregadoresAdmin, setEntregadoresAdmin] = useState([]);
const [carregandoEntregadoresAdmin, setCarregandoEntregadoresAdmin] = useState(false);
const [erroEntregadoresAdmin, setErroEntregadoresAdmin] = useState('');
const [mensagemAdmin, setMensagemAdmin] = useState('');

const [entregasCliente, setEntregasCliente] = useState([]);
const [entregasEmpresa, setEntregasEmpresa] = useState([]);
const [entregasDoEntregador, setEntregasDoEntregador] = useState([]);
const [carregandoEntregas, setCarregandoEntregas] = useState(false);
const [erroEntregas, setErroEntregas] = useState('');
const [entregaEmAtualizacaoId, setEntregaEmAtualizacaoId] = useState(null);
const [entregadoresAtivos, setEntregadoresAtivos] = useState([]);
const [carregandoEntregadoresAtivos, setCarregandoEntregadoresAtivos] = useState(false);
const [erroEntregadoresAtivos, setErroEntregadoresAtivos] = useState('');
const [entregaEntregadoresAbertaId, setEntregaEntregadoresAbertaId] = useState(null);
const [entregaEmAtribuicaoId, setEntregaEmAtribuicaoId] = useState(null);

// Estados dos módulos novos. Por enquanto, os dados destes módulos ficam apenas nesta sessão.
const [pesquisaEstudos, setPesquisaEstudos] = useState('');
const [pesquisaProfissional, setPesquisaProfissional] = useState('');
const [origemTaxi, setOrigemTaxi] = useState('');
const [destinoTaxi, setDestinoTaxi] = useState('');
const [telefoneTaxi, setTelefoneTaxi] = useState('');
const [pedidoTaxiPreparado, setPedidoTaxiPreparado] = useState(null);
const [destinatarioMensagem, setDestinatarioMensagem] = useState('');
const [textoMensagem, setTextoMensagem] = useState('');
const [mensagensLocais, setMensagensLocais] = useState([]);
const [tipoAnuncio, setTipoAnuncio] = useState('Produto');
const [descricaoAnuncio, setDescricaoAnuncio] = useState('');
const [estadoPedidoPublicidade, setEstadoPedidoPublicidade] = useState('');
const [tipoMovimentoFinanceiro, setTipoMovimentoFinanceiro] = useState('Despesa');
const [descricaoMovimentoFinanceiro, setDescricaoMovimentoFinanceiro] = useState('');
const [valorMovimentoFinanceiro, setValorMovimentoFinanceiro] = useState('');
const [movimentosFinanceiros, setMovimentosFinanceiros] = useState([]);

// Restaurar e guardar sessões localmente, sem alterar o backend Supabase.
const [sessoesRestauradas, setSessoesRestauradas] = useState(false);

useEffect(() => {
  let cancelado = false;

  async function lerSessaoGuardada(valor, tipoEsperado) {
    if (!valor) return null;
    let sessao;
    try {
      sessao = JSON.parse(valor);
    } catch {
      return null;
    }

    if (!sessao || !sessao.access_token || !sessao.user || !sessao.user.id) {
      return null;
    }

    // Evita restaurar uma sessão de candidato como empresa (ou vice-versa)
    // quando os metadados identificam explicitamente outro tipo de conta.
    const tipoContaGuardado = String(sessao.user?.user_metadata?.tipo_conta || '').trim().toLowerCase();
    if (tipoEsperado !== 'admin' && tipoContaGuardado && tipoContaGuardado !== tipoEsperado) {
      return null;
    }

    // Uma sessão sem refresh token não deve ser restaurada se o token já expirou.
    const expiraEm = Number(sessao.expires_at || 0);
    if (!sessao.refresh_token && expiraEm > 0 && expiraEm <= Math.floor(Date.now() / 1000)) {
      return null;
    }
    if (!sessao.refresh_token) return sessao;

    // Renova o token ao reabrir a aplicação quando existe refresh_token.
    // Se a rede estiver indisponível, preserva a sessão guardada para nova tentativa.
    try {
      const resposta = await fetch(
        `${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            apikey: SUPABASE_KEY,
          },
          body: JSON.stringify({ refresh_token: sessao.refresh_token }),
        }
      );
      if (resposta.ok) {
        const sessaoAtualizada = await resposta.json();
        if (sessaoAtualizada?.access_token && sessaoAtualizada?.user?.id) {
          const tipoAtualizado = String(sessaoAtualizada.user?.user_metadata?.tipo_conta || '').trim().toLowerCase();
          if (tipoEsperado !== 'admin' && tipoAtualizado && tipoAtualizado !== tipoEsperado) return null;
          return sessaoAtualizada;
        }
      }
      // Respostas 4xx de refresh normalmente indicam uma sessão inválida/revogada.
      if (resposta.status >= 400 && resposta.status < 500) return null;
      return sessao;
    } catch {
      return sessao;
    }
  }

  async function restaurarSessoes() {
    try {
      const [candidatoGuardado, empresaGuardada, adminGuardada] = await Promise.all([
        rnoStorage.getItem('rno_session_candidato'),
        rnoStorage.getItem('rno_session_empresa'),
        rnoStorage.getItem('rno_session_admin'),
      ]);

      const [candidato, empresa, admin] = await Promise.all([
        lerSessaoGuardada(candidatoGuardado, 'candidato'),
        lerSessaoGuardada(empresaGuardada, 'empresa'),
        lerSessaoGuardada(adminGuardada, 'admin'),
      ]);
      if (cancelado) return;
      setSessaoCandidato(candidato);
      setSessaoEmpresa(empresa);
      setSessaoAdmin(admin);
    } catch (erro) {
      // A aplicação continua disponível mesmo se o armazenamento local falhar.
      console.warn('Não foi possível restaurar as sessões guardadas.');
    } finally {
      if (!cancelado) setSessoesRestauradas(true);
    }
  }

  restaurarSessoes();
  return () => { cancelado = true; };
}, []);

useEffect(() => {
  if (!sessoesRestauradas) return;

  async function guardarSessao(chave, sessao) {
    if (sessao && sessao.access_token && sessao.user && sessao.user.id) {
      await rnoStorage.setItem(chave, JSON.stringify(sessao));
    } else {
      await rnoStorage.removeItem(chave);
    }
  }

  Promise.all([
    guardarSessao('rno_session_candidato', sessaoCandidato),
    guardarSessao('rno_session_empresa', sessaoEmpresa),
    guardarSessao('rno_session_admin', sessaoAdmin),
  ]).catch(() => {
    console.warn('Não foi possível guardar a sessão neste dispositivo.');
  });
}, [sessoesRestauradas, sessaoCandidato, sessaoEmpresa, sessaoAdmin]);

async function terminarSessao(tipo) {
  const sessaoAtual =
    tipo === 'candidato' ? sessaoCandidato :
    tipo === 'empresa' ? sessaoEmpresa :
    tipo === 'admin' ? sessaoAdmin : null;

  // Limpa imediatamente a sessão local e volta à página inicial.
  if (tipo === 'candidato') setSessaoCandidato(null);
  if (tipo === 'empresa') setSessaoEmpresa(null);
  if (tipo === 'admin') setSessaoAdmin(null);
  setPagina('inicio');
  setSenhaCandidato('');
  setSenhaEmpresa('');
  setSenhaAdmin('');

  // Tenta também encerrar a sessão no Supabase. A aplicação continua a sair
  // localmente mesmo que o servidor esteja temporariamente indisponível.
  let encerramentoRemotoConfirmado = false;
  try {
    if (sessaoAtual?.access_token) {
      const respostaLogout = await fetch(`${SUPABASE_URL}/auth/v1/logout`, {
        method: 'POST',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessaoAtual.access_token}`,
        },
      });
      encerramentoRemotoConfirmado = respostaLogout.ok;
    }
  } catch {
    encerramentoRemotoConfirmado = false;
  }

  Alert.alert(
    'Sessão terminada',
    encerramentoRemotoConfirmado
      ? 'A sessão foi terminada neste dispositivo e o Supabase confirmou o encerramento.'
      : 'A sessão foi removida deste dispositivo. Não foi possível confirmar o encerramento no servidor; verifica a ligação à internet.'
  );
}

async function escolherFotografiaProduto() {
  const permissao = await ImagePicker.requestMediaLibraryPermissionsAsync();

  if (!permissao.granted) {
    setMensagemNovoProduto(
      'Precisamos de autorização para aceder às fotografias.'
    );
    return;
  }

  const resultado = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ['images'],
    allowsEditing: true,
    aspect: [1, 1],
    quality: 0.8,
  });

  if (!resultado.canceled && resultado.assets?.length > 0) {
    setFotografiaProduto(resultado.assets[0]);
    setMensagemNovoProduto('Fotografia selecionada com sucesso.');
  }
}

function adicionarAoCarrinho(produto) {
  const itemExistente = carrinho.find(
    (item) => item.id === produto.id
  );

  const quantidadeAtual = itemExistente
    ? itemExistente.quantidade
    : 0;

  if (quantidadeAtual >= Number(produto.stock ?? 0)) {
    setMensagemCarrinho('Stock insuficiente para este produto.');
    return;
  }

  if (itemExistente) {
    setCarrinho(
      carrinho.map((item) =>
        item.id === produto.id
          ? { ...item, quantidade: item.quantidade + 1 }
          : item
      )
    );
  } else {
    setCarrinho([
      ...carrinho,
      { ...produto, quantidade: 1 },
    ]);
  }

  setMensagemCarrinho(produto.nome + ' adicionado ao carrinho!');
}

// Atualiza a quantidade do carrinho sem ultrapassar o stock apresentado.
// A RPC criar_encomenda continua a validar o stock real no servidor.
function atualizarQuantidadeCarrinho(produtoId, quantidadeSolicitada) {
  const itemAtual = carrinho.find((item) => item.id === produtoId);
  if (!itemAtual) return;

  const quantidade = Math.floor(Number(quantidadeSolicitada));
  const stockDisponivel = Math.floor(Number(itemAtual.stock ?? 0));

  if (!Number.isFinite(quantidade)) {
    setMensagemCarrinho('Introduza uma quantidade válida.');
    return;
  }

  if (quantidade <= 0) {
    setCarrinho(carrinho.filter((item) => item.id !== produtoId));
    setMensagemCarrinho(itemAtual.nome + ' removido do carrinho.');
    return;
  }

  if (!Number.isFinite(stockDisponivel) || quantidade > stockDisponivel) {
    setMensagemCarrinho(
      `Stock insuficiente para ${itemAtual.nome}. Disponível: ${Math.max(0, stockDisponivel)} unidade(s).`
    );
    return;
  }

  setCarrinho(
    carrinho.map((item) =>
      item.id === produtoId ? { ...item, quantidade } : item
    )
  );
  setMensagemCarrinho('Quantidade de ' + itemAtual.nome + ' atualizada.');
}

async function finalizarEncomenda() {
  if (processandoEncomenda) return;

  if (!sessaoCandidato?.access_token || !sessaoCandidato?.user?.id) {
    setMensagemEncomenda('Inicie sessão para finalizar a encomenda.');
    setPagina('login');
    return;
  }

  if (carrinho.length === 0) {
    setMensagemEncomenda('O carrinho está vazio.');
    return;
  }

  const linhaInvalida = carrinho.find((item) => {
    const preco = Number(item.preco);
    const quantidade = Number(item.quantidade);
    const stock = Number(item.stock ?? 0);
    return (
      !item.id ||
      !Number.isFinite(preco) || preco < 0 ||
      !Number.isInteger(quantidade) || quantidade < 1 ||
      !Number.isFinite(stock) || quantidade > stock
    );
  });

  if (linhaInvalida) {
    setMensagemEncomenda(
      `Verifique o produto ${linhaInvalida.nome || ''}: preço, quantidade ou stock inválido. Atualize o carrinho antes de finalizar.`
    );
    return;
  }

if (!enderecoEntregaCliente.trim()) {
  setMensagemEncomenda('Introduza o endereço de entrega.');
  return;
}

if (!(telefoneEntregaCliente.trim() || telefonePerfil?.trim())) {
  setMensagemEncomenda('Introduza o telefone para a entrega.');
  return;
}

  setProcessandoEncomenda(true);
  setMensagemEncomenda('A registar a encomenda...');

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/rpc/criar_encomenda`,
      {
        method: 'POST',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessaoCandidato.access_token}`,
          'Content-Type': 'application/json',
          'Content-Profile': 'public',
          'Accept-Profile': 'public',
        },
        body: JSON.stringify({
  p_itens: carrinho.map((item) => ({
    produto_id: item.id,
    quantidade: item.quantidade,
  })),
  p_telefone: telefoneEntregaCliente.trim() || telefonePerfil || null,
  p_endereco_entrega: enderecoEntregaCliente.trim() || null,
  p_observacoes: observacoesEntregaCliente.trim() || null,
}),
      }
    );

    const texto = await resposta.text();
    let dados = null;

    try {
      dados = texto ? JSON.parse(texto) : null;
    } catch {
      dados = null;
    }

    if (!resposta.ok) {
      throw new Error(
        dados?.message ||
        dados?.hint ||
        texto ||
        'Não foi possível registar a encomenda.'
      );
    }

    setCarrinho([]);
    setMensagemCarrinho('');
    const valorNumeroEncomenda =
      typeof dados === 'string' || typeof dados === 'number'
        ? String(dados).trim()
        : dados?.numero ?? dados?.id ?? dados?.encomenda_id ?? dados?.order_id ?? null;
    const numeroEncomenda =
      valorNumeroEncomenda && !['null', 'undefined', '[object Object]'].includes(String(valorNumeroEncomenda).toLowerCase())
        ? String(valorNumeroEncomenda).replace(/^"|"$/g, '')
        : '';

    setMensagemEncomenda(
      numeroEncomenda
        ? 'Encomenda registada com sucesso! Número: ' + numeroEncomenda
        : 'Encomenda registada com sucesso.'
    );
  } catch (erro) {
    setMensagemEncomenda(
      erro.message || 'Erro ao registar a encomenda.'
    );
  } finally {
    setProcessandoEncomenda(false);
  }
}

async function carregarEntregadoresAdmin(sessaoParaUsar = sessaoAdmin) {
  // Permite carregar a lista com a sessão recém-obtida durante o login,
  // sem depender de uma atualização assíncrona do estado React.
  if (!sessaoParaUsar?.access_token) {
    setErroEntregadoresAdmin(
      'Inicia sessão com a conta de administrador para continuar.'
    );
    setEntregadoresAdmin([]);
    return;
  }


  setCarregandoEntregadoresAdmin(true);
  setErroEntregadoresAdmin('');
  setMensagemAdmin('');

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/rpc/admin_listar_entregadores`,
      {
        method: 'POST',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessaoParaUsar.access_token}`,
          'Content-Type': 'application/json',
          'Accept-Profile': 'public',
          'Content-Profile': 'public',
        },
        body: JSON.stringify({}),
      }
    );

    const dados = await resposta.json();

    if (!resposta.ok) {
      throw new Error(
        dados.message ||
        dados.details ||
        'Não foi possível carregar os entregadores.'
      );
    }

    setEntregadoresAdmin(Array.isArray(dados) ? dados : []);
  } catch (erro) {
    setErroEntregadoresAdmin(
      erro.message || 'Ocorreu um erro ao carregar os entregadores.'
    );
  } finally {
    setCarregandoEntregadoresAdmin(false);
  }
}

async function alterarEstadoEntregadorAdmin(entregadorId, aprovado) {
  if (!sessaoAdmin?.access_token) {
    setMensagemAdmin('Inicia sessão como administrador.');
    return;
  }

  setMensagemAdmin('');
  setErroEntregadoresAdmin('');

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/rpc/admin_atualizar_estado_entregador`,
      {
        method: 'POST',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessaoAdmin.access_token}`,
          'Content-Type': 'application/json',
          'Accept-Profile': 'public',
          'Content-Profile': 'public',
        },
        body: JSON.stringify({
          p_entregador_id: entregadorId,
          p_aprovado: aprovado,
        }),
      }
    );

    if (!resposta.ok) {
      const detalhe = await resposta.text();
      throw new Error(
        detalhe || 'Não foi possível atualizar o estado do entregador.'
      );
    }

    setMensagemAdmin(
      aprovado
        ? 'Entregador aprovado com sucesso.'
        : 'Entregador desativado com sucesso.'
    );

    await carregarEntregadoresAdmin();
  } catch (erro) {
    setErroEntregadoresAdmin(
      erro.message || 'Ocorreu um erro ao atualizar o entregador.'
    );
  }
}

async function carregarEncomendasCandidato() {
  if (!sessaoCandidato?.access_token || !sessaoCandidato?.user?.id) {
    setErroEncomendas('Inicie sessão para consultar as suas encomendas.');
    setEncomendasCandidato([]);
    return;
  }

  setCarregandoEncomendas(true);
  setErroEncomendas('');

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/encomendas?select=id,estado,total,created_at&cliente_id=eq.${encodeURIComponent(sessaoCandidato.user.id)}&order=created_at.desc`,
      {
        method: 'GET',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessaoCandidato.access_token}`,
          Accept: 'application/json',
          'Accept-Profile': 'public',
        },
      }
    );

    const texto = await resposta.text();
    let dados = [];

    try {
      dados = texto ? JSON.parse(texto) : [];
    } catch {
      throw new Error('O servidor devolveu uma resposta inválida.');
    }

    if (!resposta.ok) {
      throw new Error(
        dados?.message ||
        dados?.hint ||
        texto ||
        'Não foi possível carregar as encomendas.'
      );
    }

   
const encomendasComItens = await Promise.all(
  dados.map(async (encomenda) => {
    const respostaItens = await fetch(
      `${SUPABASE_URL}/rest/v1/itens_encomenda?select=encomenda_id,produto_id,nome_produto,preco_unitario,quantidade,subtotal&encomenda_id=eq.${encodeURIComponent(encomenda.id)}`,
      {
        method: 'GET',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessaoCandidato.access_token}`,
          Accept: 'application/json',
          'Accept-Profile': 'public',
        },
      }
    );

    const textoItens = await respostaItens.text();
    let itens = [];

    try {
      itens = textoItens ? JSON.parse(textoItens) : [];
    } catch {
      throw new Error('Não foi possível ler os artigos da encomenda.');
    }

    if (!respostaItens.ok) {
      throw new Error(
        'Erro ao carregar os artigos: ' + textoItens
      );
    }

    return {
      ...encomenda,
      itens: itens,
    };
  })
);

setEncomendasCandidato(encomendasComItens);

  } catch (erro) {
    setErroEncomendas(
      erro.message || 'Erro ao consultar as encomendas.'
    );
    setEncomendasCandidato([]);
  } finally {
    setCarregandoEncomendas(false);
  }
}
async function carregarProdutosVendedor() {
  if (
  !sessaoEmpresa ||
  !sessaoEmpresa.access_token ||
  !sessaoEmpresa.user ||
  !sessaoEmpresa.user.id
) {
  setErroProdutosVendedor(
    'A sessão da empresa não está disponível. Entre novamente pela página da empresa.'
  );
  setProdutosVendedor([]);
  return;
}
  setCarregandoProdutosVendedor(true);
  setErroProdutosVendedor('');

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/produtos?select=id,nome,descricao,preco,imagem_url,categoria,stock,publicado,empresa_id,created_at&empresa_id=eq.${encodeURIComponent(sessaoEmpresa.user.id)}&order=created_at.desc`,
      {
        method: 'GET',
        headers: {
  apikey: SUPABASE_KEY,
  Authorization: `Bearer ${sessaoEmpresa.access_token}`,
  'Content-Type': 'application/json',
  'Accept-Profile': 'public',
  'Content-Profile': 'public',
  Prefer: 'return=minimal',
},
      }
    );

    const texto = await resposta.text();
    let dados = [];

    try {
      dados = texto ? JSON.parse(texto) : [];
    } catch {
      throw new Error('O servidor devolveu uma resposta inválida.');
    }

    if (!resposta.ok) {
      throw new Error(
        dados?.message ||
        dados?.hint ||
        texto ||
        'Não foi possível carregar os produtos.'
      );
    }

    setProdutosVendedor(dados);
  } catch (erro) {
    setErroProdutosVendedor(
      erro.message || 'Erro ao consultar os produtos.'
    );
    setProdutosVendedor([]);
  } finally {
    setCarregandoProdutosVendedor(false);
  }
}

async function registarEntregador() {
  if (!sessaoCandidato?.access_token || !sessaoCandidato?.user?.id) {
    setMensagemEntregador(
      'Entre na sua conta antes de se registar como entregador.'
    );
    return;
  }

  if (
    !nomeEntregador.trim() ||
    !telefoneEntregador.trim() ||
    !provinciaEntregador.trim()
  ) {
    setMensagemEntregador(
      'Preencha o nome completo, telefone e província.'
    );
    return;
  }

  setARegistarEntregador(true);
  setMensagemEntregador('');

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/rpc/registar_entregador`,
      {
        method: 'POST',
       headers: {
  apikey: SUPABASE_KEY,
  Authorization: `Bearer ${sessaoCandidato.access_token}`,
  'Content-Type': 'application/json',
  'Content-Profile': 'public',
  'Accept-Profile': 'public',
},
        body: JSON.stringify({
          p_nome_completo: nomeEntregador.trim(),
          p_telefone: telefoneEntregador.trim(),
          p_provincia: provinciaEntregador.trim(),
        }),
      }
    );

    const resultado = await resposta.text();

    if (!resposta.ok) {
      throw new Error(resultado || 'Não foi possível registar o entregador.');
    }

    setMensagemEntregador(
      'Registo enviado com sucesso! Aguarde a aprovação para começar a receber entregas.'
    );

    setNomeEntregador('');
    setTelefoneEntregador('');
    setProvinciaEntregador('');
  } catch (erro) {
    setMensagemEntregador(
      `Erro no registo: ${erro.message}`
    );
  } finally {
    setARegistarEntregador(false);
  }
}

async function carregarEstadoEntregador() {
  if (!sessaoCandidato?.access_token || !sessaoCandidato?.user?.id) {
    setMensagemEntregador('Inicie sessão para consultar o registo.');
    return;
  }

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/rpc/estado_registo_entregador`,
      {
        method: 'POST',
       headers: {
  apikey: SUPABASE_KEY,
  Authorization: `Bearer ${sessaoCandidato.access_token}`,
  'Content-Type': 'application/json',
  'Content-Profile': 'public',
  'Accept-Profile': 'public',
},
        body: JSON.stringify({}),
      }
    );

    const texto = await resposta.text();

    if (!resposta.ok) {
      throw new Error(texto || 'Não foi possível consultar o registo.');
    }

    const dados = texto ? JSON.parse(texto) : [];

    setEstadoEntregador(
      Array.isArray(dados) && dados.length > 0 ? dados[0] : null
    );

    if (!Array.isArray(dados) || dados.length === 0) {
      setMensagemEntregador('Ainda não tem registo como entregador.');
    } else if (dados[0].ativo) {
      setMensagemEntregador('O seu registo de entregador está activo.');
    } else {
      setMensagemEntregador('O seu registo está pendente de aprovação.');
    }
  } catch (erro) {
    setMensagemEntregador(
      `Erro ao consultar registo: ${erro.message}`
    );
  }
}

async function carregarEntregasCliente() {
  if (!sessaoCandidato?.access_token || !sessaoCandidato?.user?.id) {
    setErroEntregas('Inicie sessão para consultar as suas entregas.');
    setEntregasCliente([]);
    return;
  }

  setCarregandoEntregas(true);
  setErroEntregas('');

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/rpc/minhas_entregas`,
      {
        method: 'POST',
        
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessaoCandidato.access_token}`,
          'Content-Type': 'application/json',
          'Content-Profile': 'public',
          'Accept-Profile': 'public',
        },
        body: JSON.stringify({}),

      }
    );

    const texto = await resposta.text();
    let dados = [];

    try {
      dados = texto ? JSON.parse(texto) : [];
    } catch {
      throw new Error('A resposta das entregas não é válida.');
    }

    if (!resposta.ok) {
      throw new Error(
        dados?.message ||
        texto ||
        'Não foi possível carregar as entregas.'
      );
    }

    setEntregasCliente(Array.isArray(dados) ? dados : []);
  } catch (erro) {
    setErroEntregas(erro.message || 'Erro ao consultar as entregas.');
    setEntregasCliente([]);
  } finally {
    setCarregandoEntregas(false);
  }
}

async function carregarEntregasEmpresa() {
  if (!sessaoEmpresa?.access_token || !sessaoEmpresa?.user?.id) {
    setErroEntregas('Entre na conta da empresa para consultar as entregas.');
    setEntregasEmpresa([]);
    return;
  }

  setCarregandoEntregas(true);
  setErroEntregas('');

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/rpc/empresa_entregas_com_atribuicao`,
      {
        method: 'POST',
        headers: {
  apikey: SUPABASE_KEY,
  Authorization: `Bearer ${sessaoEmpresa.access_token}`,
  'Content-Type': 'application/json',
  'Content-Profile': 'public',
  'Accept-Profile': 'public',
},
        body: JSON.stringify({}),
      }
    );

    const texto = await resposta.text();
    let dados = [];

    try {
      dados = texto ? JSON.parse(texto) : [];
    } catch {
      throw new Error('A resposta das entregas não é válida.');
    }

    if (!resposta.ok) {
      throw new Error(
        dados?.message ||
        texto ||
        'Não foi possível carregar as entregas da empresa.'
      );
    }

    setEntregasEmpresa(Array.isArray(dados) ? dados : []);
  } catch (erro) {
    setErroEntregas(
      erro.message || 'Erro ao consultar as entregas da empresa.'
    );
    setEntregasEmpresa([]);
  } finally {
    setCarregandoEntregas(false);
  }
}

async function carregarEntregadoresAtivos() {
  if (!sessaoEmpresa?.access_token || !sessaoEmpresa?.user?.id) {
    setErroEntregadoresAtivos('Entre na conta da empresa para consultar entregadores.');
    setEntregadoresAtivos([]);
    return;
  }

  setCarregandoEntregadoresAtivos(true);
  setErroEntregadoresAtivos('');

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/rpc/empresa_listar_entregadores_ativos`,
      {
        method: 'POST',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessaoEmpresa.access_token}`,
          'Content-Type': 'application/json',
          'Content-Profile': 'public',
          'Accept-Profile': 'public',
        },
        body: JSON.stringify({}),
      }
    );

    const texto = await resposta.text();
    let dados = [];
    try {
      dados = texto ? JSON.parse(texto) : [];
    } catch {
      throw new Error('A resposta da lista de entregadores não é válida.');
    }

    if (!resposta.ok) {
      throw new Error(extrairMensagemErroRPC(texto, 'Não foi possível carregar os entregadores ativos.'));
    }

    setEntregadoresAtivos(Array.isArray(dados) ? dados : []);
  } catch (erro) {
    setErroEntregadoresAtivos(erro.message || 'Erro ao consultar os entregadores ativos.');
    setEntregadoresAtivos([]);
  } finally {
    setCarregandoEntregadoresAtivos(false);
  }
}

async function atribuirEntregadorEntrega(entregaId, entregadorId, nomeEntregadorSelecionado) {
  if (!sessaoEmpresa?.access_token || !sessaoEmpresa?.user?.id) {
    setErroEntregadoresAtivos('Entre na conta da empresa para atribuir uma entrega.');
    return;
  }
  if (!entregaId || !entregadorId) {
    setErroEntregadoresAtivos('Não foi possível identificar a entrega ou o entregador.');
    return;
  }
  if (entregaEmAtribuicaoId) return;

  setEntregaEmAtribuicaoId(`${entregaId}:${entregadorId}`);
  setErroEntregadoresAtivos('');
  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/rpc/atribuir_entrega`,
      {
        method: 'POST',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessaoEmpresa.access_token}`,
          'Content-Type': 'application/json',
          'Content-Profile': 'public',
          'Accept-Profile': 'public',
        },
        body: JSON.stringify({
          p_entrega_id: entregaId,
          p_entregador_id: entregadorId,
        }),
      }
    );

    const texto = await resposta.text();
    if (!resposta.ok) {
      throw new Error(extrairMensagemErroRPC(texto, 'Não foi possível atribuir a entrega.'));
    }
    if (!interpretarResultadoBooleanoRPC(texto)) {
      throw new Error('O Supabase não confirmou a atribuição da entrega.');
    }

    setEntregaEntregadoresAbertaId(null);
    setEntregadoresAtivos([]);
    await carregarEntregasEmpresa();
    Alert.alert('Sucesso', `Entrega atribuída a ${nomeEntregadorSelecionado || 'o entregador selecionado'}.`);
  } catch (erro) {
    setErroEntregadoresAtivos(erro.message || 'Erro ao atribuir o entregador.');
  } finally {
    setEntregaEmAtribuicaoId(null);
  }
}

async function carregarEntregasDoEntregador() {
  if (!sessaoCandidato?.access_token || !sessaoCandidato?.user?.id) {
    setErroEntregas('Inicie sessão para consultar as entregas atribuídas.');
    setEntregasDoEntregador([]);
    return;
  }

  setCarregandoEntregas(true);
  setErroEntregas('');

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/rpc/minhas_entregas_como_entregador`,
      {
        method: 'POST',
       headers: {
  apikey: SUPABASE_KEY,
  Authorization: `Bearer ${sessaoCandidato.access_token}`,
  'Content-Type': 'application/json',
  'Content-Profile': 'public',
  'Accept-Profile': 'public',
},
        body: JSON.stringify({}),
      }
    );

    const texto = await resposta.text();
    let dados = [];

    try {
      dados = texto ? JSON.parse(texto) : [];
    } catch {
      throw new Error('A resposta das entregas não é válida.');
    }

    if (!resposta.ok) {
      throw new Error(
        dados?.message ||
        texto ||
        'Não foi possível carregar as entregas atribuídas.'
      );
    }

    setEntregasDoEntregador(Array.isArray(dados) ? dados : []);
  } catch (erro) {
    setErroEntregas(
      erro.message || 'Erro ao consultar as entregas atribuídas.'
    );
    setEntregasDoEntregador([]);
  } finally {
    setCarregandoEntregas(false);
  }
}

async function atualizarEstadoEntregaEmpresa(entregaId, novoEstado) {
  if (!sessaoEmpresa?.access_token || !sessaoEmpresa?.user?.id) {
    setErroEntregas('Entre na conta da empresa para gerir as entregas.');
    return;
  }
  if (!entregaId) {
    setErroEntregas('Não foi possível identificar a entrega seleccionada.');
    return;
  }
  if (entregaEmAtualizacaoId) return;

  setEntregaEmAtualizacaoId(String(entregaId));
  setErroEntregas('');
  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/rpc/atualizar_estado_entrega`,
      {
        method: 'POST',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessaoEmpresa.access_token}`,
          'Content-Type': 'application/json',
          'Content-Profile': 'public',
          'Accept-Profile': 'public',
        },
        body: JSON.stringify({
          p_entrega_id: entregaId,
          p_novo_estado: novoEstado,
        }),
      }
    );

    const texto = await resposta.text();
    if (!resposta.ok) {
      throw new Error(extrairMensagemErroRPC(texto, 'Não foi possível actualizar o estado da entrega.'));
    }
    if (!interpretarResultadoBooleanoRPC(texto)) {
      throw new Error('O Supabase não confirmou a alteração do estado da entrega.');
    }

    await carregarEntregasEmpresa();
    Alert.alert('Sucesso', `Estado da entrega actualizado para: ${novoEstado}.`);
  } catch (erro) {
    setErroEntregas(
      erro.message || 'Erro ao actualizar o estado da entrega.'
    );
  } finally {
    setEntregaEmAtualizacaoId(null);
  }
}

async function atualizarEstadoEntregaEntregador(entregaId, novoEstado) {
  if (!sessaoCandidato?.access_token || !sessaoCandidato?.user?.id) {
    setErroEntregas('Inicie sessão para actualizar a entrega.');
    return;
  }
  if (!entregaId) {
    setErroEntregas('Não foi possível identificar a entrega seleccionada.');
    return;
  }
  if (entregaEmAtualizacaoId) return;

  setEntregaEmAtualizacaoId(String(entregaId));
  setErroEntregas('');
  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/rpc/atualizar_estado_entregador`,
      {
        method: 'POST',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessaoCandidato.access_token}`,
          'Content-Type': 'application/json',
          'Content-Profile': 'public',
          'Accept-Profile': 'public',
        },
        body: JSON.stringify({
          p_entrega_id: entregaId,
          p_novo_estado: novoEstado,
        }),
      }
    );

    const texto = await resposta.text();
    if (!resposta.ok) {
      throw new Error(extrairMensagemErroRPC(texto, 'Não foi possível actualizar o estado da entrega.'));
    }
    if (!interpretarResultadoBooleanoRPC(texto)) {
      throw new Error('O Supabase não confirmou a alteração do estado da entrega.');
    }

    await carregarEntregasDoEntregador();
    Alert.alert('Sucesso', `Estado da entrega actualizado para: ${novoEstado}.`);
  } catch (erro) {
    setErroEntregas(
      erro.message || 'Erro ao actualizar o estado da entrega.'
    );
  } finally {
    setEntregaEmAtualizacaoId(null);
  }
}

const RASCUNHO_ENTREGA_VAZIO = {
  enderecoRecolha: '',
  custo: '0',
  observacoes: '',
};

function obterRascunhoEntrega(encomendaId) {
  const chave = String(encomendaId ?? '');
  return rascunhosEntregaPorEncomenda[chave] || RASCUNHO_ENTREGA_VAZIO;
}

function atualizarRascunhoEntrega(encomendaId, campo, valor) {
  const chave = String(encomendaId ?? '');
  setRascunhosEntregaPorEncomenda((atuais) => ({
    ...atuais,
    [chave]: {
      ...(atuais[chave] || RASCUNHO_ENTREGA_VAZIO),
      [campo]: valor,
    },
  }));
}

function limparRascunhoEntrega(encomendaId) {
  const chave = String(encomendaId ?? '');
  setRascunhosEntregaPorEncomenda((atuais) => ({
    ...atuais,
    [chave]: { ...RASCUNHO_ENTREGA_VAZIO },
  }));
}

async function solicitarEntrega(
  encomendaId,
  enderecoRecolha,
  enderecoEntrega,
  telefoneDestinatario,
  custoEntrega = 0,
  observacoes = ''
) {
  if (!sessaoEmpresa?.access_token || !sessaoEmpresa?.user?.id) {
    setErroEntregas('Entre na conta da empresa para solicitar uma entrega.');
    return;
  }

  if (
    !encomendaId ||
    !enderecoRecolha?.trim() ||
    !enderecoEntrega?.trim() ||
    !telefoneDestinatario?.trim()
  ) {
    setErroEntregas(
      'Preencha a encomenda, os endereços de recolha e entrega e o telefone do destinatário.'
    );
    return;
  }

  const custo = Number(custoEntrega);

  if (!Number.isFinite(custo) || custo < 0) {
    setErroEntregas('Introduza um custo de entrega válido.');
    return;
  }

  try {
    setErroEntregas('');
    setCarregandoEntregas(true);

    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/rpc/solicitar_entrega`,
      {
        method: 'POST',
        headers: {
  apikey: SUPABASE_KEY,
  Authorization: `Bearer ${sessaoEmpresa.access_token}`,
  'Content-Type': 'application/json',
  'Content-Profile': 'public',
  'Accept-Profile': 'public',
},
        body: JSON.stringify({
          p_encomenda_id: encomendaId,
          p_endereco_recolha: enderecoRecolha.trim(),
          p_endereco_entrega: enderecoEntrega.trim(),
          p_telefone_destinatario: telefoneDestinatario.trim(),
          p_custo_entrega: custo,
          p_observacoes: observacoes.trim() || null,
        }),
      }
    );

    const texto = await resposta.text();

    if (!resposta.ok) {
      let detalhe = texto;

      try {
        const dados = texto ? JSON.parse(texto) : null;
        detalhe = dados?.message || dados?.details || texto;
      } catch {
        // Mantém a mensagem original da resposta.
      }

      throw new Error(
        detalhe || 'Não foi possível solicitar a entrega.'
      );
    }

    // Limpa apenas o formulário da encomenda confirmada pela API.
    limparRascunhoEntrega(encomendaId);
    await carregarEntregasEmpresa();

    Alert.alert('Sucesso', 'Entrega solicitada com sucesso.');
  } catch (erro) {
    setErroEntregas(
      erro.message || 'Erro ao solicitar a entrega.'
    );
  } finally {
    setCarregandoEntregas(false);
  }
}

async function carregarEncomendasVendedor() {
  if (!sessaoEmpresa?.access_token || !sessaoEmpresa?.user?.id) {
    setErroEncomendasVendedor(
      'Entre na conta da empresa para consultar as encomendas.'
    );
    setEncomendasVendedor([]);
    return;
  }

  setCarregandoEncomendasVendedor(true);
  setErroEncomendasVendedor('');

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/rpc/encomendas_vendedor`,
      {
        method: 'POST',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessaoEmpresa.access_token}`,
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'Content-Profile': 'public',
          'Accept-Profile': 'public',
        },
        body: JSON.stringify({}),
      }
    );

    const texto = await resposta.text();
    let dados = [];

    try {
      dados = texto ? JSON.parse(texto) : [];
    } catch {
      dados = [];
    }

    if (!resposta.ok) {
      throw new Error(
        dados?.message ||
        texto ||
        'Não foi possível carregar as encomendas.'
      );
    }

    setEncomendasVendedor(Array.isArray(dados) ? dados : []);
  } catch (erro) {
    setErroEncomendasVendedor(
      erro.message || 'Erro ao consultar as encomendas.'
    );
    setEncomendasVendedor([]);
  } finally {
    setCarregandoEncomendasVendedor(false);
  }
}

async function atualizarEstadoEncomenda(encomendaId, novoEstado) {
  if (!sessaoEmpresa?.access_token) {
    alert('Entre novamente na conta da empresa.');
    return;
  }

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/rpc/atualizar_estado_encomenda`,
      {
        method: 'POST',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessaoEmpresa.access_token}`,
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'Content-Profile': 'public',
        },
        body: JSON.stringify({
          p_encomenda_id: encomendaId,
          p_novo_estado: novoEstado,
        }),
      }
    );

    const texto = await resposta.text();

    if (!resposta.ok) {
      throw new Error(texto || 'Não foi possível atualizar o estado.');
    }

    await carregarEncomendasVendedor();
    alert('Estado da encomenda atualizado com sucesso!');
  } catch (erro) {
    alert(
      'Erro ao atualizar o estado: ' +
      (erro.message || 'Tente novamente.')
    );
  }
}

async function publicarProduto(produto) {
  if (
    !sessaoEmpresa ||
    !sessaoEmpresa.access_token ||
    !sessaoEmpresa.user ||
    !sessaoEmpresa.user.id
  ) {
    setMensagemNovoProduto(
      'Entre novamente na conta da empresa para publicar produtos.'
    );
    return;
  }

  try {
    setMensagemNovoProduto('A publicar o produto...');

    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/produtos?id=eq.${encodeURIComponent(produto.id)}&empresa_id=eq.${encodeURIComponent(sessaoEmpresa.user.id)}`,
      {
        method: 'PATCH',
       headers: {
  apikey: SUPABASE_KEY,
  Authorization: `Bearer ${sessaoEmpresa.access_token}`,
  'Content-Type': 'application/json',
  Accept: 'application/json',
  'Accept-Profile': 'public',
  'Content-Profile': 'public',
  Prefer: 'return=representation',
},
        body: JSON.stringify({
          publicado: true,
        }),
      }
    );

    const textoResposta = await resposta.text();
    let produtosAtualizados = [];
    try {
      produtosAtualizados = textoResposta ? JSON.parse(textoResposta) : [];
    } catch {
      produtosAtualizados = [];
    }

    if (!resposta.ok) {
      throw new Error(textoResposta || 'Não foi possível publicar o produto.');
    }

    if (!Array.isArray(produtosAtualizados) || produtosAtualizados.length === 0) {
      throw new Error(
        'O Supabase não confirmou a publicação do produto. Verifique se o produto pertence à empresa autenticada e se as políticas de acesso permitem esta operação.'
      );
    }

    setMensagemNovoProduto('Produto publicado com sucesso!');
    await carregarProdutosVendedor();
  } catch (erro) {
    setMensagemNovoProduto(
      erro.message || 'Ocorreu um erro ao publicar o produto.'
    );
  }
}


async function adicionarProduto() {
  setMensagemNovoProduto('');

  if (
    !sessaoEmpresa ||
    !sessaoEmpresa.access_token ||
    !sessaoEmpresa.user ||
    !sessaoEmpresa.user.id
  ) {
    setMensagemNovoProduto(
      'Entre na sua conta de empresa antes de adicionar produtos.'
    );
    return;
  }

  if (
    !nomeNovoProduto.trim() ||
    !precoNovoProduto.trim() ||
    !stockNovoProduto.trim()
  ) {
    setMensagemNovoProduto(
      'Preencha o nome, o preço e o stock do produto.'
    );
    return;
  }

  const preco = Number(precoNovoProduto.replace(',', '.'));
  const stock = Number(stockNovoProduto);

  if (
    !Number.isFinite(preco) ||
    preco <= 0 ||
    !Number.isInteger(stock) ||
    stock < 0
  ) {
    setMensagemNovoProduto(
      'Introduza um preço válido e um stock inteiro igual ou superior a zero.'
    );
    return;
  }

  setAGuardarProduto(true);

  try {
    let imagemFinal = imagemNovoProduto.trim() || null;

    // Enviar a fotografia escolhida para o Supabase Storage.
    if (fotografiaProduto) {
      setMensagemNovoProduto('A enviar a fotografia...');

      const respostaImagem = await fetch(fotografiaProduto.uri);

      if (!respostaImagem.ok) {
        throw new Error('Não foi possível ler a fotografia selecionada.');
      }

      const ficheiro = await respostaImagem.blob();

      const tipoImagem =
        fotografiaProduto.mimeType || 'image/jpeg';

      const extensao =
        tipoImagem === 'image/png'
          ? 'png'
          : tipoImagem === 'image/webp'
          ? 'webp'
          : tipoImagem === 'image/heic'
          ? 'heic'
          : 'jpg';

      const nomeFicheiro =
        `produto_${Date.now()}.${extensao}`;

      const respostaUpload = await fetch(
        `${SUPABASE_URL}/storage/v1/object/produtos/${nomeFicheiro}`,
        {
          method: 'POST',
          headers: {
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${sessaoEmpresa.access_token}`,
            'Content-Type': tipoImagem,
            'x-upsert': 'false',
          },
          body: ficheiro,
        }
      );

      if (!respostaUpload.ok) {
        const detalhe = await respostaUpload.text();
        throw new Error(
          'Não foi possível enviar a fotografia: ' + detalhe
        );
      }

      imagemFinal =
        `${SUPABASE_URL}/storage/v1/object/public/produtos/${nomeFicheiro}`;
    }

    setMensagemNovoProduto('A guardar o produto...');

    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/produtos`,
      {
        method: 'POST',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessaoEmpresa.access_token}`,
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'Accept-Profile': 'public',
          'Content-Profile': 'public',
        },
        body: JSON.stringify({
          nome: nomeNovoProduto.trim(),
          descricao: descricaoNovoProduto.trim(),
          preco: preco,
          stock: stock,
          categoria: categoriaNovoProduto.trim(),
          imagem_url: imagemFinal,
          publicado: false,
          empresa_id: sessaoEmpresa.user.id,
        }),
      }
    );

    const resultado = await resposta.json().catch(() => null);

    if (!resposta.ok) {
      throw new Error(
        JSON.stringify({
          estadoHTTP: resposta.status,
          mensagem: resultado?.message,
          detalhes: resultado?.details,
          sugestao: resultado?.hint,
          codigo: resultado?.code,
        })
      );
    }

    setMensagemNovoProduto(
      'Produto registado com sucesso! Está guardado como não publicado.'
    );

    setNomeNovoProduto('');
    setDescricaoNovoProduto('');
    setPrecoNovoProduto('');
    setStockNovoProduto('');
    setCategoriaNovoProduto('');
    setImagemNovoProduto('');
    setFotografiaProduto(null);

    await carregarProdutosVendedor();
  } catch (erro) {
    setMensagemNovoProduto(
      'Erro ao guardar o produto: ' + erro.message
    );
  } finally {
    setAGuardarProduto(false);
  }
}

function prepararPedidoTaxi() {
  if (!origemTaxi.trim() || !destinoTaxi.trim() || !telefoneTaxi.trim()) {
    Alert.alert('Dados em falta', 'Preencha o local de partida, o destino e o telefone.');
    return;
  }
  const pedido = {
    origem: origemTaxi.trim(),
    destino: destinoTaxi.trim(),
    telefone: telefoneTaxi.trim(),
    criadoEm: new Date().toLocaleString('pt-PT'),
  };
  setPedidoTaxiPreparado(pedido);
  Alert.alert(
    'Pedido preparado',
    'Guardámos o pedido nesta sessão. Ainda não foi enviado a motoristas, porque a ligação a um serviço de táxi não está configurada.'
  );
}

function enviarMensagemLocal() {
  if (!destinatarioMensagem.trim() || !textoMensagem.trim()) {
    Alert.alert('Dados em falta', 'Indique o destinatário e escreva uma mensagem.');
    return;
  }
  setMensagensLocais((atuais) => [
    {
      id: `${Date.now()}-${Math.random()}`,
      destinatario: destinatarioMensagem.trim(),
      texto: textoMensagem.trim(),
      data: new Date().toLocaleString('pt-PT'),
    },
    ...atuais,
  ]);
  setTextoMensagem('');
  Alert.alert('Rascunho guardado', 'A mensagem ficou guardada apenas nesta sessão. Ainda não foi enviada para outro utilizador.');
}

function adicionarMovimentoFinanceiro() {
  const valor = Number(valorMovimentoFinanceiro.replace(',', '.'));
  if (!descricaoMovimentoFinanceiro.trim() || !Number.isFinite(valor) || valor <= 0) {
    Alert.alert('Dados inválidos', 'Indique uma descrição e um valor maior que zero.');
    return;
  }
  setMovimentosFinanceiros((atuais) => [
    {
      id: `${Date.now()}-${Math.random()}`,
      tipo: tipoMovimentoFinanceiro,
      descricao: descricaoMovimentoFinanceiro.trim(),
      valor,
      data: new Date().toLocaleDateString('pt-PT'),
    },
    ...atuais,
  ]);
  setDescricaoMovimentoFinanceiro('');
  setValorMovimentoFinanceiro('');
}

useEffect(() => {
  if (pagina !== 'servico' || servicoSelecionado !== 'Emprego') {
    return;
  }

  async function buscarVagas() {
    setCarregandoVagas(true);
    setErroVagas('');

    try {
      
const resposta = await fetch(

`${SUPABASE_URL}/rest/v1/vagas?select=id,titulo,empresa,localizacao,tipo,descricao,salario&order=created_at.desc`,

  {
    headers: {
      apikey: SUPABASE_KEY,
      'Accept-Profile': 'public',
    },
  }
);


      if (!resposta.ok) {
  const detalhe = await resposta.text();

  throw new Error(
    'Erro ' + resposta.status + ': ' + detalhe
  );
}

      const dados = await resposta.json();
      setVagas(dados);
    } catch (erro) {
      setErroVagas(erro.message || 'Ocorreu um erro ao procurar vagas.');
    } finally {
      setCarregandoVagas(false);
    }
  }

  buscarVagas();
}, [pagina, servicoSelecionado]);

useEffect(() => {
  if (pagina !== 'servico' || servicoSelecionado !== 'Empresas') {
    return;
  }

  async function carregarEmpresasPublicas() {
    setCarregandoEmpresasPublicas(true);
    setErroEmpresasPublicas('');

    try {
      const resposta = await fetch(
        `${SUPABASE_URL}/rest/v1/vendedores_publicos?select=id,nome_empresa,provincia,area_atuacao,descricao&order=nome_empresa.asc`,
        {
          headers: {
            apikey: SUPABASE_KEY,
            'Accept-Profile': 'public',
          },
        }
      );

      if (!resposta.ok) {
        throw new Error(await resposta.text());
      }

      const dados = await resposta.json();
      setEmpresasPublicas(dados);
    } catch (erro) {
      setErroEmpresasPublicas(
        erro.message || 'Não foi possível carregar as empresas.'
      );
      setEmpresasPublicas([]);
    } finally {
      setCarregandoEmpresasPublicas(false);
    }
  }

  carregarEmpresasPublicas();
}, [pagina, servicoSelecionado]);

useEffect(() => {
  if (pagina !== 'servico' || servicoSelecionado !== 'Loja Online') {
    return;
  }

  async function buscarProdutos() {
  setCarregandoProdutos(true);
  setErroProdutos('');

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/produtos?select=id,nome,descricao,preco,imagem_url,categoria,stock,empresa_id&publicado=eq.true&order=created_at.desc`,
      {
        headers: {
          apikey: SUPABASE_KEY,
          'Accept-Profile': 'public',
        },
      }
    );

      if (!resposta.ok) {
        const detalhe = await resposta.text();
        throw new Error(detalhe);
      }

    const dados = await resposta.json();
const respostaVendedores = await fetch(
  `${SUPABASE_URL}/rest/v1/vendedores_publicos?select=id,nome_empresa,provincia,area_atuacao,descricao&order=nome_empresa.asc`,
  {
    headers: {
      apikey: SUPABASE_KEY,
      'Accept-Profile': 'public',
    },
  }
);


if (!respostaVendedores.ok) {
  throw new Error(await respostaVendedores.text());
}

const vendedores = await respostaVendedores.json();

const produtosComVendedor = dados.map((produto) => ({
  ...produto,
  nome_vendedor:
    vendedores.find((vendedor) => vendedor.id === produto.empresa_id)
      ?.nome_empresa || 'não identificado',
}));

setProdutos(produtosComVendedor);
    } catch (erro) {
  console.log('Erro ao carregar produtos:', erro.message);
  setErroProdutos(erro.message || 'Erro desconhecido ao carregar produtos.');
  setProdutos([]);
    } finally {
      setCarregandoProdutos(false);
    }
  }

  buscarProdutos();
}, [pagina, servicoSelecionado]);

useEffect(() => {
  if (
    pagina !== 'painelVendedor' ||
    !sessaoEmpresa?.access_token ||
    !sessaoEmpresa?.user?.id
  ) {
    return;
  }

  carregarProdutosVendedor();
  carregarEncomendasVendedor();
}, [pagina, sessaoEmpresa]);

async function entrarCandidato() {
  const email = emailCandidato.trim().toLowerCase();

  if (!email || !senhaCandidato) {
    setMensagemLogin('Preencha o email e a palavra-passe.');
    return;
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    setMensagemLogin('Introduza um endereço de email válido.');
    return;
  }
  if (aEntrarCandidato) return;

  setAEntrarCandidato(true);
  setMensagemLogin('A verificar os seus dados...');

  try {
    const resposta = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', apikey: SUPABASE_KEY },
      body: JSON.stringify({ email, password: senhaCandidato }),
    });
    const dados = await resposta.json().catch(() => ({}));

    if (!resposta.ok || !dados.access_token || !dados.user?.id) {
      const erroServidor = String(
        dados.msg || dados.message || dados.error_description || dados.error || ''
      );
      if (/email_not_confirmed|email not confirmed|confirm.*email|email.*confirm/i.test(erroServidor)) {
        setMensagemLogin('Confirme o endereço de email através da mensagem enviada pelo Supabase e tente iniciar sessão novamente.');
      } else {
        setMensagemLogin(erroServidor || 'Falha no início de sessão. Verifique o email e a palavra-passe.');
      }
      return;
    }

    const tipoConta = String(dados.user?.user_metadata?.tipo_conta || '').trim().toLowerCase();
    if (tipoConta && tipoConta !== 'candidato') {
      // A autenticação foi válida, mas a conta pertence explicitamente a outro perfil.
      // Tentamos terminar esta sessão recém-criada antes de mostrar a orientação.
      try {
        await fetch(`${SUPABASE_URL}/auth/v1/logout`, {
          method: 'POST',
          headers: {
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${dados.access_token}`,
          },
        });
      } catch (_) {}
      setSenhaCandidato('');
      setMensagemLogin('Esta conta está registada como empresa ou outro tipo de utilizador. Entre pela área correspondente à sua conta.');
      return;
    }

    // Para contas antigas sem tipo_conta nos metadados, tentamos confirmar
    // a existência do perfil de candidato antes de aceitar a área de candidato.
    if (!tipoConta) {
      try {
        const respostaPerfil = await fetch(
          `${SUPABASE_URL}/rest/v1/candidatos?select=id&id=eq.${encodeURIComponent(dados.user.id)}&limit=1`,
          {
            method: 'GET',
            headers: {
              apikey: SUPABASE_KEY,
              Authorization: `Bearer ${dados.access_token}`,
              Accept: 'application/json',
              'Accept-Profile': 'public',
            },
          }
        );
        if (respostaPerfil.ok) {
          const perfis = await respostaPerfil.json().catch(() => []);
          if (Array.isArray(perfis) && perfis.length === 0) {
            try {
              await fetch(`${SUPABASE_URL}/auth/v1/logout`, {
                method: 'POST',
                headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${dados.access_token}` },
              });
            } catch (_) {}
            setMensagemLogin('Não encontrámos um perfil de candidato associado a esta conta. Entre pela área correta ou contacte o suporte da RNO.');
            return;
          }
        }
      } catch (_) {
        // Se a verificação de compatibilidade falhar por rede, não inventamos
        // um resultado; a autorização dos dados continua protegida pelas políticas RLS.
      }
    }

    // Preenche os campos de candidatura com dados já confirmados no perfil,
    // quando disponíveis. Se a consulta falhar, o login continua funcional.
    const metadadosCandidato = dados.user?.user_metadata || {};
    let dadosPerfilCandidato = {
      nome_completo: String(metadadosCandidato.nome_completo || ''),
      telefone: String(metadadosCandidato.telefone || ''),
      email: String(dados.user?.email || email),
    };
    try {
      const respostaPerfilCompleto = await fetch(
        `${SUPABASE_URL}/rest/v1/candidatos?select=nome_completo,telefone,email&id=eq.${encodeURIComponent(dados.user.id)}&limit=1`,
        {
          method: 'GET',
          headers: {
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${dados.access_token}`,
            Accept: 'application/json',
            'Accept-Profile': 'public',
          },
        }
      );
      if (respostaPerfilCompleto.ok) {
        const perfisCandidato = await respostaPerfilCompleto.json().catch(() => []);
        if (Array.isArray(perfisCandidato) && perfisCandidato[0]) {
          dadosPerfilCandidato = {
            nome_completo: String(perfisCandidato[0].nome_completo || dadosPerfilCandidato.nome_completo),
            telefone: String(perfisCandidato[0].telefone || dadosPerfilCandidato.telefone),
            email: String(perfisCandidato[0].email || dadosPerfilCandidato.email),
          };
        }
      }
    } catch (_) {
      // O preenchimento automático é opcional; não deve impedir o início de sessão.
    }

    setNomeCandidato(dadosPerfilCandidato.nome_completo);
    setTelefoneCandidato(dadosPerfilCandidato.telefone);
    setEmailCandidato(dadosPerfilCandidato.email);
    setSessaoCandidato(dados);
    setSenhaCandidato('');
    setMensagemLogin('Início de sessão realizado com sucesso!');
    if (vagaSelecionada?.id) {
      setEstadoEnvioCandidatura('');
      setPagina('candidatura');
    } else {
      setPagina('servico');
      setServicoSelecionado('Emprego');
    }
  } catch (_) {
    setMensagemLogin('Erro de ligação. Verifique a internet e tente novamente.');
  } finally {
    setAEntrarCandidato(false);
  }
}

async function solicitarRecuperacaoSenha() {
  const email = emailRecuperacaoSenha.trim().toLowerCase();

  if (!email) {
    setMensagemRecuperacaoSenha('Introduza o email associado à sua conta RNO.');
    return;
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    setMensagemRecuperacaoSenha('Introduza um endereço de email válido.');
    return;
  }

  if (aEnviarRecuperacaoSenha) return;

  setAEnviarRecuperacaoSenha(true);
  setMensagemRecuperacaoSenha('A solicitar o email de recuperação...');

  try {
    const destino = encodeURIComponent(URL_RECUPERACAO_SENHA);
    const resposta = await fetch(
      `${SUPABASE_URL}/auth/v1/recover?redirect_to=${destino}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: SUPABASE_KEY,
        },
        body: JSON.stringify({ email }),
      }
    );

    const dados = await resposta.json().catch(() => ({}));
    if (!resposta.ok) {
      if (resposta.status === 429) {
        setMensagemRecuperacaoSenha('Foram pedidos demasiados emails de recuperação. Aguarde um pouco antes de tentar novamente.');
      } else {
        const detalhe = String(
          dados.msg || dados.message || dados.error_description || dados.error || ''
        );
        setMensagemRecuperacaoSenha(
          detalhe
            ? `Não foi possível enviar o pedido de recuperação. ${detalhe}`
            : 'Não foi possível enviar o pedido. Verifique a ligação à internet e tente novamente.'
        );
      }
      return;
    }

    // A mensagem é deliberadamente genérica para não revelar se o email existe.
    setMensagemRecuperacaoSenha(
      'Se existir uma conta associada a este email, receberá uma mensagem com instruções. Abra o email, incluindo a pasta de spam, e siga o link para definir uma nova palavra-passe na página segura da RNO. Depois volte ao aplicativo e inicie sessão com a nova palavra-passe.'
    );
  } catch (_) {
    setMensagemRecuperacaoSenha('Não foi possível contactar o Supabase. Verifique a internet e tente novamente.');
  } finally {
    setAEnviarRecuperacaoSenha(false);
  }
}

async function cadastrarCandidato() {
  const nome = nomeCadastroCandidato.trim();
  const telefone = telefoneCadastroCandidato.trim();
  const provincia = provinciaCadastroCandidato.trim();
  const areaProfissional = areaCadastroCandidato.trim();
  const email = emailCadastroCandidato.trim().toLowerCase();

  if (!nome || !telefone || !provincia || !areaProfissional || !email || !senhaCadastroCandidato || !confirmarSenhaCadastroCandidato) {
    setMensagemCadastroCandidato('Preencha todos os campos obrigatórios.');
    return;
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    setMensagemCadastroCandidato('Introduza um endereço de email válido.');
    return;
  }

  if (senhaCadastroCandidato.length < 6) {
    setMensagemCadastroCandidato('A palavra-passe deve ter pelo menos 6 caracteres.');
    return;
  }

  if (senhaCadastroCandidato !== confirmarSenhaCadastroCandidato) {
    setMensagemCadastroCandidato('As palavras-passe não coincidem.');
    return;
  }

  setACadastrarCandidato(true);
  setMensagemCadastroCandidato('A criar a sua conta...');

  try {
    const resposta = await fetch(`${SUPABASE_URL}/auth/v1/signup`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        apikey: SUPABASE_KEY,
      },
      body: JSON.stringify({
        email,
        password: senhaCadastroCandidato,
        data: {
          tipo_conta: 'candidato',
          nome_completo: nome,
          telefone,
          provincia,
          area_profissional: areaProfissional,
          experiencia: experienciaCadastroCandidato.trim(),
        },
      }),
    });

    const dados = await resposta.json().catch(() => ({}));
    if (!resposta.ok) {
      throw new Error(
        dados.msg || dados.message || dados.error_description ||
        'Não foi possível criar a conta. Verifique os dados e tente novamente.'
      );
    }

    const utilizador = dados.user || (dados.id ? dados : null);
    if (!utilizador?.id) {
      throw new Error('O Supabase não devolveu o identificador da conta. Verifique o estado no Supabase antes de tentar novamente.');
    }

    setEmailCandidato(email);
    setSenhaCandidato('');
    setSenhaCadastroCandidato('');
    setConfirmarSenhaCadastroCandidato('');

    if (dados.access_token && dados.user?.id) {
      // O trigger existente no Supabase deve criar o perfil a partir dos metadados.
      // Não inserimos diretamente na tabela candidatos para evitar duplicação.
      const metadadosCandidato = dados.user?.user_metadata || {};
      setNomeCandidato(String(metadadosCandidato.nome_completo || nome));
      setTelefoneCandidato(String(metadadosCandidato.telefone || telefone));
      setEmailCandidato(email);
      setSessaoCandidato(dados);
      setMensagemCadastroCandidato('Conta criada com sucesso.');
      if (vagaSelecionada?.id) {
        setEstadoEnvioCandidatura('');
        setPagina('candidatura');
      } else {
        setPagina('servico');
        setServicoSelecionado('Emprego');
      }
    } else {
      setMensagemCadastroCandidato(
        'Conta criada. Verifique o seu email e confirme a conta antes de iniciar sessão. O perfil de candidato deve ser criado pelo trigger existente do Supabase.'
      );
    }
  } catch (erro) {
    setMensagemCadastroCandidato(
      erro?.message || 'Ocorreu um erro ao criar a conta. Tente novamente.'
    );
  } finally {
    setACadastrarCandidato(false);
  }
}

async function entrarAdmin() {
  if (!emailAdmin.trim() || !senhaAdmin) {
    setMensagemAdmin('Preencha o email e a palavra-passe.');
    return;
  }

  setMensagemAdmin('A verificar o acesso administrativo...');

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/auth/v1/token?grant_type=password`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: SUPABASE_KEY,
        },
        body: JSON.stringify({
          email: emailAdmin.trim(),
          password: senhaAdmin,
        }),
      }
    );

    const dados = await resposta.json();

    if (!resposta.ok || !dados.access_token || !dados.user?.id) {
      setMensagemAdmin(
        dados.msg ||
          dados.message ||
          dados.error_description ||
          'Não foi possível iniciar sessão.'
      );
      return;
    }

    const respostaAdmin = await fetch(
      `${SUPABASE_URL}/rest/v1/rpc/admin_verificar_acesso`,
      {
        method: 'POST',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${dados.access_token}`,
          'Content-Type': 'application/json',
          'Accept-Profile': 'public',
          'Content-Profile': 'public',
        },
        body: JSON.stringify({}),
      }
    );

    if (!respostaAdmin.ok) {
      setMensagemAdmin(
        'Não foi possível verificar a autorização administrativa.'
      );
      return;
    }

    const autorizado = await respostaAdmin.json();

    if (autorizado !== true) {
      setMensagemAdmin(
        'Esta conta não tem autorização de administração.'
      );
      return;
    }

    setSessaoAdmin(dados);
    setMensagemAdmin('Acesso administrativo autorizado.');
    setSenhaAdmin('');
    setPagina('painelAdmin');

    // Usa a sessão recém-autenticada, sem depender do tempo de atualização do estado.
    await carregarEntregadoresAdmin(dados);
  } catch (erro) {
    console.error('Erro no acesso administrativo:', erro);
    setMensagemAdmin(
      'Erro de ligação. Verifique a internet e tente novamente.'
    );
  }
}
function prepararCompletarPerfilEmpresa(sessao, mensagem) {
  const metadados = sessao?.user?.user_metadata || {};
  setSessaoEmpresaPendentePerfil(sessao || null);
  setACompletarPerfilEmpresa(true);
  setEmailEmpresa(String(sessao?.user?.email || emailEmpresa).trim().toLowerCase());
  setNomeEmpresaCadastro(String(metadados.nome_empresa || ''));
  setResponsavelEmpresaCadastro(String(metadados.responsavel || ''));
  setTelefoneEmpresaCadastro(String(metadados.telefone || ''));
  setProvinciaEmpresaCadastro(String(metadados.provincia || ''));
  setAreaEmpresaCadastro(String(metadados.area_atuacao || ''));
  setDescricaoEmpresaCadastro(String(metadados.descricao || ''));
  setSenhaEmpresa('');
  setMensagemEmpresa('');
  setMensagemCadastroEmpresa(mensagem || 'Complete os dados da empresa para continuar.');
}

async function cancelarCompletarPerfilEmpresa() {
  const sessao = sessaoEmpresaPendentePerfil;
  if (sessao?.access_token) {
    try {
      await fetch(`${SUPABASE_URL}/auth/v1/logout`, {
        method: 'POST',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessao.access_token}`,
        },
      });
    } catch (_) {
      // A sessão local será limpa mesmo que o pedido de logout falhe.
    }
  }
  setSessaoEmpresaPendentePerfil(null);
  setACompletarPerfilEmpresa(false);
  setSenhaEmpresa('');
  setMensagemCadastroEmpresa('');
  setMensagemEmpresa('Sessão terminada. Pode voltar a iniciar sessão.');
}

async function guardarPerfilEmpresaPendente() {
  const sessao = sessaoEmpresaPendentePerfil;
  const userId = sessao?.user?.id;
  const email = String(sessao?.user?.email || emailEmpresa).trim().toLowerCase();

  if (!sessao?.access_token || !userId) {
    setMensagemCadastroEmpresa('A sessão expirou. Inicie sessão novamente para completar o perfil.');
    setACompletarPerfilEmpresa(false);
    setSessaoEmpresaPendentePerfil(null);
    return;
  }

  if (
    !nomeEmpresaCadastro.trim() ||
    !responsavelEmpresaCadastro.trim() ||
    !telefoneEmpresaCadastro.trim() ||
    !provinciaEmpresaCadastro.trim() ||
    !areaEmpresaCadastro.trim() ||
    !email
  ) {
    setMensagemCadastroEmpresa('Preencha todos os campos obrigatórios do perfil da empresa.');
    return;
  }

  setACadastrarEmpresa(true);
  setMensagemCadastroEmpresa('A guardar o perfil da empresa...');

  try {
    const respostaPerfil = await fetch(`${SUPABASE_URL}/rest/v1/empresas`, {
      method: 'POST',
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${sessao.access_token}`,
        'Content-Type': 'application/json',
        'Content-Profile': 'public',
        'Accept-Profile': 'public',
        Prefer: 'return=representation',
      },
      body: JSON.stringify({
        id: userId,
        nome_empresa: nomeEmpresaCadastro.trim(),
        responsavel: responsavelEmpresaCadastro.trim(),
        telefone: telefoneEmpresaCadastro.trim(),
        email,
        provincia: provinciaEmpresaCadastro.trim(),
        area_atuacao: areaEmpresaCadastro.trim(),
        descricao: descricaoEmpresaCadastro.trim(),
      }),
    });

    if (!respostaPerfil.ok) {
      const detalhe = await respostaPerfil.text();
      // Não fazemos upsert automático: isso poderia atualizar um perfil existente.
      // Se outro processo criou o perfil em simultâneo, verificamos antes de falhar.
      const consultaExistente = await fetch(
        `${SUPABASE_URL}/rest/v1/empresas?id=eq.${encodeURIComponent(userId)}&select=id,nome_empresa`,
        {
          method: 'GET',
          headers: {
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${sessao.access_token}`,
            Accept: 'application/json',
            'Accept-Profile': 'public',
          },
        }
      );
      const existentes = consultaExistente.ok
        ? await consultaExistente.json().catch(() => [])
        : [];
      if (!Array.isArray(existentes) || existentes.length === 0) {
        throw new Error(
          'Não foi possível guardar o perfil da empresa. Verifique as permissões de INSERT da tabela empresas no Supabase. Detalhes: ' + detalhe
        );
      }
    }

    setSessaoEmpresa(sessao);
    setSessaoEmpresaPendentePerfil(null);
    setACompletarPerfilEmpresa(false);
    setSenhaEmpresa('');
    setConfirmarSenhaEmpresaCadastro('');
    setMensagemCadastroEmpresa('Perfil da empresa concluído com sucesso.');
    setMensagemEmpresa(`Bem-vindo, ${nomeEmpresaCadastro.trim()}!`);
    setPagina('painelVendedor');
  } catch (erro) {
    setMensagemCadastroEmpresa(
      erro?.message || 'Não foi possível guardar o perfil. Tente novamente.'
    );
  } finally {
    setACadastrarEmpresa(false);
  }
}

async function entrarEmpresa() {
  const email = emailEmpresa.trim().toLowerCase();
  if (!email || !senhaEmpresa) {
    setMensagemEmpresa('Preencha o email e a palavra-passe.');
    return;
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    setMensagemEmpresa('Introduza um endereço de email válido.');
    return;
  }

  setMensagemEmpresa('A verificar os dados da empresa...');

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/auth/v1/token?grant_type=password`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: SUPABASE_KEY,
        },
        body: JSON.stringify({ email, password: senhaEmpresa }),
      }
    );

    const dados = await resposta.json().catch(() => ({}));
    if (!resposta.ok || !dados.access_token || !dados.user?.id) {
      setMensagemEmpresa(
        dados.msg || dados.message || dados.error_description ||
        'Não foi possível iniciar sessão. Verifique o email, a palavra-passe e a confirmação do email.'
      );
      return;
    }

    const userId = dados.user.id;
    const tipoConta = String(dados.user?.user_metadata?.tipo_conta || '').trim().toLowerCase();
    if (tipoConta && tipoConta !== 'empresa') {
      setMensagemEmpresa(
        'Esta conta não está registada como empresa. Utilize a área correspondente ao tipo de conta ou contacte o suporte da RNO.'
      );
      return;
    }

    const urlPerfil = `${SUPABASE_URL}/rest/v1/empresas?id=eq.${encodeURIComponent(userId)}&select=id,nome_empresa`;
    const respostaEmpresa = await fetch(urlPerfil, {
      method: 'GET',
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${dados.access_token}`,
        Accept: 'application/json',
        'Accept-Profile': 'public',
      },
    });

    if (!respostaEmpresa.ok) {
      const detalhe = await respostaEmpresa.text();
      setMensagemEmpresa(
        `A conta foi autenticada, mas não foi possível consultar o perfil da empresa (HTTP ${respostaEmpresa.status}). Verifique as permissões de leitura da tabela empresas. ${detalhe}`
      );
      return;
    }

    let empresas = await respostaEmpresa.json().catch(() => []);
    let perfilCriadoAgora = false;

    if (!Array.isArray(empresas) || empresas.length === 0) {
      const metadados = dados.user?.user_metadata || {};
      const perfilMetadados = {
        id: userId,
        nome_empresa: String(metadados.nome_empresa || '').trim(),
        responsavel: String(metadados.responsavel || '').trim(),
        telefone: String(metadados.telefone || '').trim(),
        email,
        provincia: String(metadados.provincia || '').trim(),
        area_atuacao: String(metadados.area_atuacao || '').trim(),
        descricao: String(metadados.descricao || '').trim(),
      };
      const metadadosCompletos = Boolean(
        perfilMetadados.nome_empresa && perfilMetadados.responsavel &&
        perfilMetadados.telefone && perfilMetadados.provincia && perfilMetadados.area_atuacao
      );

      if (metadadosCompletos) {
        const respostaCriacao = await fetch(`${SUPABASE_URL}/rest/v1/empresas`, {
          method: 'POST',
          headers: {
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${dados.access_token}`,
            'Content-Type': 'application/json',
            'Content-Profile': 'public',
            'Accept-Profile': 'public',
            Prefer: 'return=representation',
          },
          body: JSON.stringify(perfilMetadados),
        });

        if (respostaCriacao.ok) {
          const novosPerfis = await respostaCriacao.json().catch(() => []);
          empresas = Array.isArray(novosPerfis) && novosPerfis.length
            ? novosPerfis
            : [{ id: userId, nome_empresa: perfilMetadados.nome_empresa }];
          perfilCriadoAgora = true;
        } else {
          // Confirma se um trigger ou pedido concorrente criou o perfil entretanto.
          const verificarNovamente = await fetch(urlPerfil, {
            method: 'GET',
            headers: {
              apikey: SUPABASE_KEY,
              Authorization: `Bearer ${dados.access_token}`,
              Accept: 'application/json',
              'Accept-Profile': 'public',
            },
          });
          const perfisExistentes = verificarNovamente.ok
            ? await verificarNovamente.json().catch(() => [])
            : [];
          if (Array.isArray(perfisExistentes) && perfisExistentes.length) {
            empresas = perfisExistentes;
          } else {
            prepararCompletarPerfilEmpresa(
              dados,
              'A conta foi autenticada, mas o perfil ainda não existe ou não pôde ser criado automaticamente. Confirme os dados abaixo e escolha “Guardar perfil e continuar”. Detalhe: ' + await respostaCriacao.text()
            );
            return;
          }
        }
      } else {
        prepararCompletarPerfilEmpresa(
          dados,
          'A conta foi autenticada, mas o perfil da empresa não foi encontrado. Confirme os dados abaixo e escolha “Guardar perfil e continuar”.'
        );
        return;
      }
    }

    setSessaoEmpresa(dados);
    setSessaoEmpresaPendentePerfil(null);
    setACompletarPerfilEmpresa(false);
    setSenhaEmpresa('');
    setMensagemEmpresa(
      `${perfilCriadoAgora ? 'Perfil criado. ' : ''}Bem-vindo, ${empresas[0].nome_empresa || 'empresa'}!`
    );
    setPagina('painelVendedor');
  } catch (erro) {
    setMensagemEmpresa(
      erro?.message || 'Erro de ligação. Verifique a internet e tente novamente.'
    );
  }
}

async function cadastrarEmpresa() {
  const email = emailEmpresa.trim().toLowerCase();

  if (
    !nomeEmpresaCadastro.trim() ||
    !responsavelEmpresaCadastro.trim() ||
    !telefoneEmpresaCadastro.trim() ||
    !provinciaEmpresaCadastro.trim() ||
    !areaEmpresaCadastro.trim() ||
    !email ||
    !senhaEmpresa ||
    !confirmarSenhaEmpresaCadastro
  ) {
    setMensagemCadastroEmpresa('Preencha todos os campos obrigatórios, incluindo a confirmação da palavra-passe.');
    return;
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    setMensagemCadastroEmpresa('Introduza um endereço de email válido.');
    return;
  }

  if (senhaEmpresa.length < 6) {
    setMensagemCadastroEmpresa('A palavra-passe deve ter pelo menos 6 caracteres.');
    return;
  }

  if (senhaEmpresa !== confirmarSenhaEmpresaCadastro) {
    setMensagemCadastroEmpresa('As palavras-passe não coincidem.');
    return;
  }

  setACadastrarEmpresa(true);
  setMensagemCadastroEmpresa('A criar a conta da empresa...');

  try {
    const respostaCadastro = await fetch(`${SUPABASE_URL}/auth/v1/signup`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        apikey: SUPABASE_KEY,
      },
      body: JSON.stringify({
        email,
        password: senhaEmpresa,
        data: {
          tipo_conta: 'empresa',
          nome_empresa: nomeEmpresaCadastro.trim(),
          responsavel: responsavelEmpresaCadastro.trim(),
          telefone: telefoneEmpresaCadastro.trim(),
          provincia: provinciaEmpresaCadastro.trim(),
          area_atuacao: areaEmpresaCadastro.trim(),
          descricao: descricaoEmpresaCadastro.trim(),
        },
      }),
    });

    const dados = await respostaCadastro.json().catch(() => ({}));
    if (!respostaCadastro.ok) {
      throw new Error(
        dados.msg || dados.message || dados.error_description ||
        'Não foi possível criar a conta. Se já iniciou um registo com este email, tente iniciar sessão em vez de criar outra conta.'
      );
    }

    const userId = dados.user?.id || dados.id;
    if (!userId) {
      throw new Error('O Supabase não devolveu o identificador da conta. Verifique o estado do registo antes de tentar novamente.');
    }

    setEmailEmpresa(email);
    setSenhaEmpresa('');
    setConfirmarSenhaEmpresaCadastro('');

    // Com confirmação de email ativa, o signup não devolve access_token.
    // Não tentamos inserir sem autenticação e não pedimos para repetir o signup.
    if (!dados.access_token || !dados.user?.id) {
      setMensagemCadastroEmpresa(
        'Conta criada. Abra o email de confirmação e confirme o endereço. Depois volte aqui e inicie sessão como empresa. Se o perfil ainda não existir, a aplicação irá ajudá-lo a completá-lo após o login. Não volte a criar a mesma conta.'
      );
      return;
    }

    const urlPerfil = `${SUPABASE_URL}/rest/v1/empresas?id=eq.${encodeURIComponent(userId)}&select=id,nome_empresa`;
    const consultaPerfil = await fetch(urlPerfil, {
      method: 'GET',
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${dados.access_token}`,
        Accept: 'application/json',
        'Accept-Profile': 'public',
      },
    });

    if (!consultaPerfil.ok) {
      const detalhe = await consultaPerfil.text();
      throw new Error(
        `A conta foi criada, mas não foi possível verificar se o perfil já existe (HTTP ${consultaPerfil.status}). Não tente registar a conta novamente. Detalhes: ${detalhe}`
      );
    }

    let perfis = await consultaPerfil.json().catch(() => []);
    if (!Array.isArray(perfis) || perfis.length === 0) {
      const respostaPerfil = await fetch(`${SUPABASE_URL}/rest/v1/empresas`, {
        method: 'POST',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${dados.access_token}`,
          'Content-Type': 'application/json',
          'Content-Profile': 'public',
          'Accept-Profile': 'public',
          Prefer: 'return=representation',
        },
        body: JSON.stringify({
          id: userId,
          nome_empresa: nomeEmpresaCadastro.trim(),
          responsavel: responsavelEmpresaCadastro.trim(),
          telefone: telefoneEmpresaCadastro.trim(),
          email,
          provincia: provinciaEmpresaCadastro.trim(),
          area_atuacao: areaEmpresaCadastro.trim(),
          descricao: descricaoEmpresaCadastro.trim(),
        }),
      });

      if (!respostaPerfil.ok) {
        const detalhe = await respostaPerfil.text();
        const verificarNovamente = await fetch(urlPerfil, {
          method: 'GET',
          headers: {
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${dados.access_token}`,
            Accept: 'application/json',
            'Accept-Profile': 'public',
          },
        });
        const perfisDepois = verificarNovamente.ok
          ? await verificarNovamente.json().catch(() => [])
          : [];
        if (!Array.isArray(perfisDepois) || perfisDepois.length === 0) {
          throw new Error(
            'A conta foi criada, mas o perfil da empresa não foi gravado. Não tente registar a mesma conta novamente. Verifique as permissões de INSERT da tabela empresas no Supabase. Detalhes: ' + detalhe
          );
        }
      }
    }

    setMensagemCadastroEmpresa('Conta e perfil da empresa criados. Já pode iniciar sessão.');
    setSenhaEmpresa('');
    setConfirmarSenhaEmpresaCadastro('');
    setNomeEmpresaCadastro('');
    setResponsavelEmpresaCadastro('');
    setTelefoneEmpresaCadastro('');
    setProvinciaEmpresaCadastro('');
    setAreaEmpresaCadastro('');
    setDescricaoEmpresaCadastro('');
  } catch (erro) {
    setMensagemCadastroEmpresa(
      erro?.message || 'Erro ao registar a empresa.'
    );
  } finally {
    setACadastrarEmpresa(false);
  }
}

async function enviarCandidatura() {
  if (!sessaoCandidato?.access_token || !sessaoCandidato?.user?.id) {
    setEstadoEnvioCandidatura('Inicie sessão para enviar a candidatura.');
    setPagina('login');
    return;
  }

  if (!vagaSelecionada?.id) {
    setEstadoEnvioCandidatura('Não foi possível identificar a vaga.');
    return;
  }

  if (!nomeCandidato.trim() || !telefoneCandidato.trim()) {
    setEstadoEnvioCandidatura(
      'Preencha o nome completo e o telefone.'
    );
    return;
  }

  setEnviandoCandidatura(true);
  setEstadoEnvioCandidatura('A verificar se já existe uma candidatura para esta vaga...');

  try {
    // Evita candidaturas repetidas por duplo clique ou nova tentativa.
    // É uma proteção de interface; a prevenção de concorrência também exige
    // uma restrição única no backend, que não é alterada por este pacote.
    const respostaCandidaturaExistente = await fetch(
      `${SUPABASE_URL}/rest/v1/candidaturas?select=id,status&candidato_id=eq.${encodeURIComponent(sessaoCandidato.user.id)}&vaga_id=eq.${encodeURIComponent(vagaSelecionada.id)}&limit=1`,
      {
        method: 'GET',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessaoCandidato.access_token}`,
          Accept: 'application/json',
          'Accept-Profile': 'public',
        },
      }
    );

    const textoCandidaturaExistente = await respostaCandidaturaExistente.text();
    let candidaturasExistentes = [];
    try {
      candidaturasExistentes = textoCandidaturaExistente
        ? JSON.parse(textoCandidaturaExistente)
        : [];
    } catch (_) {
      throw new Error('O servidor devolveu uma resposta inválida ao verificar candidaturas existentes.');
    }

    if (!respostaCandidaturaExistente.ok) {
      throw new Error(
        'Não foi possível verificar se já se candidatou (HTTP ' +
        respostaCandidaturaExistente.status + '). Verifique as permissões de leitura da tabela candidaturas antes de tentar novamente.'
      );
    }

    if (Array.isArray(candidaturasExistentes) && candidaturasExistentes.length > 0) {
      const estadoExistente = candidaturasExistentes[0].status;
      setEstadoEnvioCandidatura(
        'Já enviou uma candidatura para esta vaga' +
        (estadoExistente ? '. Estado atual: ' + estadoExistente + '.' : '.')
      );
      return;
    }

    setEstadoEnvioCandidatura('A enviar candidatura...');
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/candidaturas`,
      {
        method: 'POST',
headers: {
  apikey: SUPABASE_KEY,
  Authorization: `Bearer ${sessaoCandidato.access_token}`,
  'Content-Type': 'application/json',
  'Content-Profile': 'public',
  'Accept-Profile': 'public',
  Prefer: 'return=minimal',
},        body: JSON.stringify({
          vaga: vagaSelecionada.titulo,
          vaga_id: vagaSelecionada.id,
          candidato_id: sessaoCandidato.user.id,
          nome_completo: nomeCandidato.trim(),
          telefone: telefoneCandidato.trim(),
          email: emailCandidato.trim() || sessaoCandidato.user.email || null,
          mensagem: mensagemCandidatura.trim(),
          status: 'Em análise',
        }),
      }
    );

    const texto = await resposta.text();
    let dados = null;

    try {
      dados = texto ? JSON.parse(texto) : null;
    } catch {
      dados = null;
    }

    if (!resposta.ok) {
      setEstadoEnvioCandidatura(
        dados?.message ||
        dados?.hint ||
        texto ||
        'Não foi possível gravar a candidatura.'
      );
      return;
    }

    setEstadoEnvioCandidatura(
      'Candidatura enviada com sucesso!'
    );
  } catch (erro) {
    setEstadoEnvioCandidatura(
      'Erro de ligação. Verifique a internet e tente novamente.'
    );
  } finally {
    setEnviandoCandidatura(false);
  }
}

async function carregarVagasEmpresa() {
  if (!sessaoEmpresa?.access_token || !sessaoEmpresa?.user?.id) {
    setErroVagasEmpresa('Inicie sessão como empresa para consultar as suas vagas.');
    setVagasEmpresa([]);
    return;
  }

  setCarregandoVagasEmpresa(true);
  setErroVagasEmpresa('');

  try {
    const userId = sessaoEmpresa.user.id;
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/vagas?select=id,titulo,empresa,empresa_id,localizacao,tipo,descricao,requisitos,salario,contacto,created_at&empresa_id=eq.${encodeURIComponent(userId)}&order=created_at.desc`,
      {
        method: 'GET',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessaoEmpresa.access_token}`,
          Accept: 'application/json',
          'Accept-Profile': 'public',
        },
      }
    );

    const detalhe = await resposta.text();
    let dados = [];
    try { dados = detalhe ? JSON.parse(detalhe) : []; } catch { dados = []; }

    if (!resposta.ok) {
      throw new Error(`Não foi possível consultar as vagas (HTTP ${resposta.status}). ${dados?.message || detalhe}`);
    }

    setVagasEmpresa(Array.isArray(dados) ? dados : []);
    setVagasEmpresaCarregada(true);
  } catch (erro) {
    setErroVagasEmpresa(erro?.message || 'Erro ao carregar as vagas da empresa.');
  } finally {
    setCarregandoVagasEmpresa(false);
  }
}

async function publicarVagaEmpresa() {
  if (!sessaoEmpresa?.access_token || !sessaoEmpresa?.user?.id) {
    setMensagemPublicarVaga('Inicie sessão como empresa antes de publicar uma vaga.');
    return;
  }

  const titulo = tituloNovaVaga.trim();
  const localizacao = localizacaoNovaVaga.trim();
  const tipo = tipoNovaVaga.trim();
  const descricao = descricaoNovaVaga.trim();
  const requisitos = requisitosNovaVaga.trim();
  const salario = salarioNovaVaga.trim();
  const contactoInformado = contactoNovaVaga.trim();

  if (!titulo || !localizacao || !tipo || !descricao) {
    setMensagemPublicarVaga('Preencha o título, a localização, o tipo de emprego e a descrição da vaga.');
    return;
  }

  if (titulo.length < 3 || descricao.length < 15) {
    setMensagemPublicarVaga('Use um título com pelo menos 3 caracteres e uma descrição com pelo menos 15 caracteres.');
    return;
  }

  setAPublicarVaga(true);
  setMensagemPublicarVaga('A verificar o perfil da empresa...');

  try {
    const userId = sessaoEmpresa.user.id;
    const token = sessaoEmpresa.access_token;

    // Lê o perfil autenticado para não confiar num nome enviado pelo formulário.
    const respostaPerfil = await fetch(
      `${SUPABASE_URL}/rest/v1/empresas?id=eq.${encodeURIComponent(userId)}&select=id,nome_empresa,telefone&limit=1`,
      {
        method: 'GET',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${token}`,
          Accept: 'application/json',
          'Accept-Profile': 'public',
        },
      }
    );

    const perfilTexto = await respostaPerfil.text();
    let perfis = [];
    try { perfis = perfilTexto ? JSON.parse(perfilTexto) : []; } catch { perfis = []; }

    if (!respostaPerfil.ok) {
      throw new Error(`Não foi possível verificar o perfil da empresa (HTTP ${respostaPerfil.status}). ${perfis?.message || perfilTexto}`);
    }

    const perfil = Array.isArray(perfis) ? perfis[0] : null;
    if (!perfil?.id || String(perfil.id) !== String(userId) || !String(perfil.nome_empresa || '').trim()) {
      throw new Error('O perfil da empresa não foi encontrado ou não tem nome registado. Conclua primeiro o perfil da empresa.');
    }

    const contacto = contactoInformado || String(perfil.telefone || '').trim();
    if (!contacto) {
      throw new Error('Informe um contacto para a vaga ou registe o telefone no perfil da empresa.');
    }

    setMensagemPublicarVaga('A publicar a vaga...');
    const resposta = await fetch(`${SUPABASE_URL}/rest/v1/vagas`, {
      method: 'POST',
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
        'Content-Profile': 'public',
        'Accept-Profile': 'public',
        Prefer: 'return=representation',
      },
      body: JSON.stringify({
        titulo,
        empresa: String(perfil.nome_empresa).trim(),
        empresa_id: userId,
        localizacao,
        tipo,
        descricao,
        requisitos: requisitos || null,
        salario: salario || null,
        contacto,
      }),
    });

    const respostaTexto = await resposta.text();
    let novasVagas = [];
    try { novasVagas = respostaTexto ? JSON.parse(respostaTexto) : []; } catch { novasVagas = []; }

    if (!resposta.ok) {
      throw new Error(`Não foi possível publicar a vaga (HTTP ${resposta.status}). ${novasVagas?.message || respostaTexto || 'Verifique a política de INSERT da tabela vagas.'}`);
    }

    setTituloNovaVaga('');
    setLocalizacaoNovaVaga('');
    setTipoNovaVaga('');
    setDescricaoNovaVaga('');
    setRequisitosNovaVaga('');
    setSalarioNovaVaga('');
    setContactoNovaVaga('');
    setMensagemPublicarVaga('Vaga enviada ao Supabase com sucesso. A carregar a lista atualizada...');
    await carregarVagasEmpresa();
    setMensagemPublicarVaga('Vaga publicada com sucesso. Se não aparecer ao público, verifique as políticas de leitura e a listagem pública já existente.');
  } catch (erro) {
    setMensagemPublicarVaga(erro?.message || 'Não foi possível publicar a vaga.');
  } finally {
    setAPublicarVaga(false);
  }
}

async function carregarCandidaturasEmpresa() {
  if (!sessaoEmpresa?.access_token || !sessaoEmpresa?.user?.id) {
    setErroCandidaturasEmpresa('Inicie sessão como empresa.');
    return;
  }

  setCarregandoCandidaturasEmpresa(true);
  setErroCandidaturasEmpresa('');

  try {
    const userId = sessaoEmpresa.user.id;
    const accessToken = sessaoEmpresa.access_token;

    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/candidaturas?select=id,vaga,vaga_id,nome_completo,email,telefone,mensagem,status,created_at,vagas!inner(titulo,empresa_id)&vagas.empresa_id=eq.${encodeURIComponent(userId)}&order=created_at.desc`,
      {
        method: 'GET',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${accessToken}`,
          Accept: 'application/json',
          'Accept-Profile': 'public',
        },
      }
    );

    if (!resposta.ok) {
      const detalhe = await resposta.text();
      throw new Error(
        'Erro ao consultar candidaturas: ' +
        resposta.status + ' ' + detalhe
      );
    }

    const dados = await resposta.json();
    setCandidaturasEmpresa(dados);
  } catch (erro) {
    setErroCandidaturasEmpresa(
      erro.message || 'Não foi possível carregar as candidaturas.'
    );
  } finally {
    setCarregandoCandidaturasEmpresa(false);
  }
}

async function atualizarEstadoCandidatura(item, novoEstado) {
  if (!sessaoEmpresa?.access_token || !sessaoEmpresa?.user?.id) {
    Alert.alert('Sessão expirada', 'Entre novamente como empresa.');
    return;
  }

  const estadosPermitidos = ['Em análise', 'Pré-selecionado', 'Aprovado', 'Rejeitado'];
  if (!estadosPermitidos.includes(novoEstado)) {
    Alert.alert('Estado inválido', 'Selecione um dos estados disponíveis.');
    return;
  }

  const vagaRelacionada = Array.isArray(item?.vagas) ? item.vagas[0] : item?.vagas;
  if (
    !item?.id || !item?.vaga_id ||
    !vagaRelacionada?.empresa_id ||
    String(vagaRelacionada.empresa_id) !== String(sessaoEmpresa.user.id)
  ) {
    setErroCandidaturasEmpresa('Não foi possível confirmar que esta candidatura pertence a uma vaga da sua empresa. Atualize a lista e tente novamente.');
    return;
  }

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/candidaturas?id=eq.${encodeURIComponent(item.id)}&vaga_id=eq.${encodeURIComponent(item.vaga_id)}`,
      {
        method: 'PATCH',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessaoEmpresa.access_token}`,
          'Content-Type': 'application/json',
          'Content-Profile': 'public',
          'Accept-Profile': 'public',
          Prefer: 'return=representation',
        },
        body: JSON.stringify({ status: novoEstado }),
      }
    );

    const texto = await resposta.text();
    let atualizadas = [];
    try { atualizadas = texto ? JSON.parse(texto) : []; } catch { atualizadas = []; }

    if (!resposta.ok) {
      throw new Error(texto || `Erro ${resposta.status}`);
    }
    if (!Array.isArray(atualizadas) || atualizadas.length === 0) {
      throw new Error('O Supabase não confirmou a atualização. Verifique as permissões RLS da tabela candidaturas para a empresa autenticada.');
    }

    setCandidaturasEmpresa((lista) =>
      lista.map((candidatura) =>
        candidatura.id === item.id
          ? { ...candidatura, status: novoEstado }
          : candidatura
      )
    );
    setMensagemEstadoCandidatura(`Estado atualizado com sucesso: ${novoEstado}`);
    Alert.alert('Atualização concluída', `Estado da candidatura: ${novoEstado}`);
  } catch (erro) {
    Alert.alert(
      'Não foi possível atualizar',
      erro?.message || 'Verifique a ligação e as permissões da empresa.'
    );
  }
}

async function carregarCandidaturasCandidato() {
  if (!sessaoCandidato?.access_token || !sessaoCandidato?.user?.id) {
    setErroCandidaturasCandidato('Inicie sessão como candidato.');
    setCandidaturasCandidato([]);
    return;
  }

  setCarregandoCandidaturasCandidato(true);
  setErroCandidaturasCandidato('');

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/candidaturas?select=*&candidato_id=eq.${encodeURIComponent(sessaoCandidato.user.id)}&order=created_at.desc`,
      {
        method: 'GET',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessaoCandidato.access_token}`,
          Accept: 'application/json',
          'Accept-Profile': 'public',
        },
      }
    );

    const texto = await resposta.text();
    let dados = [];

    try {
      dados = texto ? JSON.parse(texto) : [];
    } catch {
      throw new Error('O servidor devolveu uma resposta inválida.');
    }

    if (!resposta.ok) {
      throw new Error(
        dados?.message || dados?.hint || texto ||
        'Não foi possível carregar as candidaturas.'
      );
    }

    setCandidaturasCandidato(Array.isArray(dados) ? dados : []);
  } catch (erro) {
    setErroCandidaturasCandidato(
      erro.message || 'Erro ao carregar as candidaturas.'
    );
    setCandidaturasCandidato([]);
  } finally {
    setCarregandoCandidaturasCandidato(false);
  }
}

async function carregarPerfilCandidato() {
  if (!sessaoCandidato?.access_token || !sessaoCandidato?.user?.id) {
    setErroPerfil('Inicie sessão como candidato.');
    return;
  }

  setCarregandoPerfil(true);
  setErroPerfil('');
  setMensagemPerfil('');

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/candidatos?select=id,nome_completo,telefone,email,provincia,area_profissional,experiencia&id=eq.${encodeURIComponent(sessaoCandidato.user.id)}`,
      {
        method: 'GET',
       headers: {
  apikey: SUPABASE_KEY,
  Authorization: `Bearer ${sessaoCandidato.access_token}`,
  Accept: 'application/json',
  'Accept-Profile': 'public',
},
      }
    );

    const texto = await resposta.text();
    const dados = texto ? JSON.parse(texto) : [];

    if (!resposta.ok) {
      throw new Error(
        dados?.message || 'Não foi possível carregar o perfil.'
      );
    }

    if (!Array.isArray(dados) || dados.length === 0) {
      throw new Error('Perfil do candidato não encontrado.');
    }

    const perfil = dados[0];

    setPerfilCandidato(perfil);
    setNomePerfil(perfil.nome_completo || '');
    setTelefonePerfil(perfil.telefone || '');
    setEmailPerfil(perfil.email || '');
    setProvinciaPerfil(perfil.provincia || '');
    setAreaPerfil(perfil.area_profissional || '');
    setExperienciaPerfil(perfil.experiencia || '');
  } catch (erro) {
    setErroPerfil(
      erro.message || 'Erro ao carregar o perfil do candidato.'
    );
  } finally {
    setCarregandoPerfil(false);
  }
}

async function guardarPerfilCandidato() {
  if (!sessaoCandidato?.access_token || !sessaoCandidato?.user?.id) {
    setErroPerfil('Inicie sessão como candidato.');
    return;
  }

  setCarregandoPerfil(true);
  setErroPerfil('');
  setMensagemPerfil('');

  try {
    const resposta = await fetch(
      `${SUPABASE_URL}/rest/v1/candidatos?id=eq.${encodeURIComponent(sessaoCandidato.user.id)}`,
      {
        method: 'PATCH',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${sessaoCandidato.access_token}`,
          'Content-Type': 'application/json',
          'Accept-Profile': 'public',
          'Content-Profile': 'public',
          Prefer: 'return=minimal',
        },
        body: JSON.stringify({
          nome_completo: nomePerfil.trim(),
          telefone: telefonePerfil.trim(),
          email: emailPerfil.trim(),
          provincia: provinciaPerfil.trim(),
          area_profissional: areaPerfil.trim(),
          experiencia: experienciaPerfil.trim(),
        }),
      }
    );

    if (!resposta.ok) {
      const texto = await resposta.text();
      let detalhe = texto;

      try {
        const dados = JSON.parse(texto);
        detalhe = dados.message || dados.details || texto;
      } catch {}

      throw new Error(detalhe || 'Não foi possível guardar o perfil.');
    }

    setPerfilCandidato({
      ...perfilCandidato,
      nome_completo: nomePerfil.trim(),
      telefone: telefonePerfil.trim(),
      email: emailPerfil.trim(),
      provincia: provinciaPerfil.trim(),
      area_profissional: areaPerfil.trim(),
      experiencia: experienciaPerfil.trim(),
    });

    setEditarPerfil(false);
    setMensagemPerfil('Perfil actualizado com sucesso!');
  } catch (erro) {
    setErroPerfil(erro.message || 'Erro ao guardar o perfil.');
  } finally {
    setCarregandoPerfil(false);
  }
}

const vagasFiltradas = vagas.filter((vaga) => {
  const texto = pesquisaVagas.trim().toLowerCase();

  const correspondeTexto =
    !texto ||
    (vaga.titulo || '').toLowerCase().includes(texto) ||
    (vaga.empresa || '').toLowerCase().includes(texto) ||
    (vaga.descricao || '').toLowerCase().includes(texto);

  const correspondeProvincia =
    provinciaFiltro === 'Todas' ||
    (vaga.localizacao || '').toLowerCase() ===
      provinciaFiltro.toLowerCase();

  const correspondeTipo =
    tipoEmpregoFiltro === 'Todos' ||
    (vaga.tipo || '').toLowerCase() ===
      tipoEmpregoFiltro.toLowerCase();

  return correspondeTexto && correspondeProvincia && correspondeTipo;
});

  return (
    <SafeAreaView style={estilos.fundo}>
      <StatusBar barStyle="light-content" backgroundColor="#123B8B" />

      <View style={estilos.cabecalho}>
        <Text style={estilos.logo}>RNO</Text>
        <Text style={estilos.subtitulo}>
          REDE NACIONAL DE OPORTUNIDADES
        </Text>
      </View>

      <ScrollView ref={scrollVagasRef} contentContainerStyle={estilos.conteudo}>
      {pagina === 'servico' && (
  <View style={{ padding: 20 }}>
    <Pressable onPress={() => setPagina('inicio')}>
      <Text style={{ color: '#123B8B', fontSize: 16 }}>
        ← Voltar ao início
      </Text>
    </Pressable>

    <Text style={{ fontSize: 26, fontWeight: 'bold', marginTop: 25 }}>
      {servicoSelecionado}
    </Text>

{servicoSelecionado === 'Emprego' && !sessaoCandidato && (
  <Pressable
    onPress={() => {
      setMensagemLogin('');
      setPagina('login');
    }}
    style={{
      backgroundColor: '#123B8B',
      padding: 14,
      borderRadius: 10,
      marginTop: 16,
      marginBottom: 12,
      alignItems: 'center',
    }}
  >
    <Text style={{ color: '#FFFFFF', fontSize: 16, fontWeight: 'bold' }}>
      🔐 Iniciar sessão como candidato
    </Text>
  </Pressable>
)}

    {servicoSelecionado === 'Emprego' ? (
  <View style={{ marginTop: 25 }}>
    <Text style={{ fontSize: 19, fontWeight: 'bold', marginBottom: 15 }}>
      O que deseja fazer?
    </Text>

    <Pressable
      style={estilos.cartao}
      onPress={() => {
        setPesquisaVagas('');
        setProvinciaFiltro('Todas');
        setTipoEmpregoFiltro('Todos');
        setVagaSelecionada(null);
        scrollVagasRef.current?.scrollTo({
          y: Math.max(offsetVagasRef.current - 16, 0),
          animated: true,
        });
      }}
    >
      <Text style={estilos.tituloCartao}>🔎 Procurar vagas</Text>
      <Text style={estilos.descricaoCartao}>
        Encontre oportunidades de emprego.
      </Text>
    </Pressable>

<Pressable
  style={estilos.cartao}
  onPress={() => {
    if (!sessaoCandidato?.access_token || !sessaoCandidato?.user?.id) {
      setMensagemLogin('Inicie sessão como candidato para consultar as suas candidaturas.');
      setPagina('login');
      return;
    }
    setPagina('minhasCandidaturas');
    carregarCandidaturasCandidato();
  }}
>
  <Text style={estilos.tituloCartao}>📄 Minhas candidaturas</Text>
  <Text style={estilos.descricaoCartao}>
    Acompanhe as oportunidades a que se candidatou.
  </Text>
</Pressable>
<Pressable
  style={estilos.cartao}
  onPress={() => {
    if (!sessaoCandidato?.access_token || !sessaoCandidato?.user?.id) {
      setMensagemLogin('Inicie sessão como candidato para consultar o seu perfil.');
      setPagina('login');
      return;
    }
    setPagina('perfilCandidato');
    carregarPerfilCandidato();
    setEditarPerfil(false);
  }}
>
  <Text style={estilos.tituloCartao}>👤 Meu perfil</Text>
  <Text style={estilos.descricaoCartao}>
    Consulte e actualize os seus dados pessoais e profissionais.
  </Text>
</Pressable>
  <View
  onLayout={(event) => { offsetVagasRef.current = event.nativeEvent.layout.y; }}
  style={{
    backgroundColor: '#EAF1FC',
    padding: 18,
    borderRadius: 16,
    marginTop: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#D5E3F7',
  }}
>
  <Text
    style={{
      fontSize: 20,
      fontWeight: 'bold',
      color: '#07152E',
    }}
  >
    Vagas disponíveis
  </Text>

  <Text
    style={{
      color: '#123B70',
      fontSize: 16,
      fontWeight: 'bold',
      marginTop: 8,
    }}
  >
    {vagasFiltradas.length === 1
      ? '1 vaga encontrada'
      : `${vagasFiltradas.length} vagas encontradas`}
  </Text>
</View>

  <View style={{ marginTop: 24, marginBottom: 16 }}>
  <Text
  style={{
    fontSize: 23,
    fontWeight: 'bold',
    color: '#07152E',
    marginBottom: 8,
    letterSpacing: 0.2,
  }}
>
  🔎 Procurar oportunidades
</Text>

  <TextInput
    value={pesquisaVagas}
    onChangeText={setPesquisaVagas}
    placeholder="Pesquisar profissão, vaga ou empresa..."
    placeholderTextColor="#65738B"
   style={{
  backgroundColor: '#FFFFFF',
  borderWidth: 1.5,
  borderColor: '#C9D8ED',
  borderRadius: 16,
  paddingVertical: 17,
  paddingHorizontal: 18,
  fontSize: 16,
  color: '#07152E',
  shadowColor: '#07152E',
  shadowOffset: { width: 0, height: 4 },
  shadowOpacity: 0.08,
  shadowRadius: 8,
  elevation: 3,
}}
  />

 <Text
  style={{
    color: '#07152E',
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10,
  }}
>
  📍 Província
</Text>
<View
  style={{
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  }}
>
  {[
    'Todas',
    'Maputo',
    'Maputo Cidade',
    'Gaza',
    'Inhambane',
    'Sofala',
    'Manica',
    'Tete',
    'Zambézia',
    'Nampula',
    'Niassa',
    'Cabo Delgado',
  ].map((provincia) => (
    <Pressable
      key={provincia}
      onPress={() => setProvinciaFiltro(provincia)}
      style={{
        paddingVertical: 10,
        paddingHorizontal: 14,
        borderRadius: 20,
        backgroundColor:
          provinciaFiltro === provincia ? '#123B70' : '#FFFFFF',
        borderWidth: 1,
        borderColor: '#123B70',
      }}
    >
      <Text
        style={{
          color:
            provinciaFiltro === provincia ? '#FFFFFF' : '#123B70',
          fontWeight: '600',
        }}
      >
        {provincia === 'Todas' ? 'Todas as províncias' : provincia}
      </Text>
    </Pressable>
  ))}
  </View>

 <Text
  style={{
    color: '#07152E',
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10,
  }}
>
  💼 Tipo de emprego
</Text>

  <View style={{
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  }}>
    {['Todos', 'Tempo inteiro', 'Tempo parcial', 'Estágio'].map((tipo) => (
      <Pressable
        key={tipo}
        onPress={() => setTipoEmpregoFiltro(tipo)}
       style={{
  paddingVertical: 11,
  paddingHorizontal: 16,
  borderRadius: 24,
  backgroundColor:
    tipoEmpregoFiltro === tipo ? '#07152E' : '#FFFFFF',
  borderWidth: 1,
  borderColor:
    tipoEmpregoFiltro === tipo ? '#07152E' : '#C9D8ED',
  shadowColor: '#07152E',
  shadowOffset: { width: 0, height: 2 },
  shadowOpacity: tipoEmpregoFiltro === tipo ? 0.12 : 0,
  shadowRadius: 4,
  elevation: tipoEmpregoFiltro === tipo ? 2 : 0,
}}
      >
        <Text style={{
          color: tipoEmpregoFiltro === tipo ? '#FFFFFF' : '#123B70',
          fontWeight: '600',
        }}>
          {tipo}
        </Text>
      </Pressable>
    ))}
  </View>

  <Text style={{
    color: '#65738B',
    marginTop: 8,
    fontSize: 13,
  }}>
    Escreva o nome da vaga ou uma palavra relacionada.
  </Text>
</View>

{vagaSelecionada !== null && (
  <View
    style={{
      backgroundColor: '#FFFFFF',
      padding: 18,
      borderRadius: 12,
      marginBottom: 18,
      borderWidth: 1,
      borderColor: '#D6E2F0',
    }}
  >
    <Text style={{ fontSize: 22, fontWeight: 'bold', color: '#123B70' }}>
      {vagaSelecionada.titulo}
    </Text>

    <Text style={{ marginTop: 12, color: '#65738B' }}>
      Empresa: {vagaSelecionada.empresa || 'Não indicada'}
    </Text>

    <Text style={{ marginTop: 8, color: '#65738B' }}>
      Localização: {vagaSelecionada.localizacao || 'Não indicada'}
    </Text>

    <Text style={{ marginTop: 16, fontWeight: 'bold', color: '#172B4D' }}>
      Descrição da vaga
    </Text>

    <Text style={{ marginTop: 6, color: '#172B4D' }}>
      {vagaSelecionada.descricao || 'Sem descrição disponível.'}
    </Text>

    <Pressable
      onPress={() => setVagaSelecionada(null)}
      style={{
        backgroundColor: '#E8EEF7',
        padding: 12,
        borderRadius: 8,
        marginTop: 16,
        alignItems: 'center',
      }}
    >
      <Text style={{ color: '#123B70', fontWeight: 'bold' }}>
        Fechar detalhes
      </Text>
    </Pressable>
  </View>
)}

{carregandoVagas && (
  <View
    style={{
      backgroundColor: '#EAF1FC',
      padding: 18,
      borderRadius: 14,
      borderWidth: 1,
      borderColor: '#D5E3F7',
      alignItems: 'center',
      marginBottom: 16,
    }}
  >
    <Text style={{ fontSize: 24, marginBottom: 8 }}>
      ⏳
    </Text>

    <Text
      style={{
        color: '#123B70',
        fontSize: 15,
        fontWeight: '600',
        textAlign: 'center',
      }}
    >
      A carregar vagas...
    </Text>
  </View>
)}

{erroVagas !== '' && (
  <View
    style={{
      backgroundColor: '#FFF1F0',
      padding: 16,
      borderRadius: 14,
      borderWidth: 1,
      borderColor: '#F5C2BE',
      marginBottom: 16,
    }}
  >
    <Text
      style={{
        color: '#B42318',
        fontSize: 15,
        fontWeight: 'bold',
        marginBottom: 5,
      }}
    >
      ⚠️ Não foi possível carregar as vagas
    </Text>

    <Text
      style={{
        color: '#8F2119',
        fontSize: 14,
        lineHeight: 21,
      }}
    >
      {erroVagas}
    </Text>
  </View>
)}

{!carregandoVagas && erroVagas === '' && vagas.length === 0 && (
  <View
    style={{
      backgroundColor: '#F1F6FC',
      padding: 20,
      borderRadius: 14,
      borderWidth: 1,
      borderColor: '#D6E2F0',
      alignItems: 'center',
      marginBottom: 16,
    }}
  >
    <Text style={{ fontSize: 28, marginBottom: 8 }}>
      💼
    </Text>

    <Text
      style={{
        color: '#07152E',
        fontSize: 16,
        fontWeight: 'bold',
        textAlign: 'center',
      }}
    >
      Ainda não existem vagas publicadas
    </Text>

    <Text
      style={{
        color: '#65738B',
        fontSize: 14,
        lineHeight: 21,
        textAlign: 'center',
        marginTop: 8,
      }}
    >
      Volta mais tarde para descobrir novas oportunidades.
    </Text>
  </View>
)}

{!carregandoVagas && erroVagas === '' && vagasFiltradas.length === 0 && (
  <View
    style={{
      backgroundColor: '#F1F6FC',
      padding: 22,
      borderRadius: 12,
      borderWidth: 1,
      borderColor: '#D6E2F0',
      alignItems: 'center',
      marginBottom: 16,
    }}
  >
    <Text style={{ fontSize: 30, marginBottom: 10 }}>
      🔎
    </Text>

    <Text
  style={{
    fontSize: 18,
    fontWeight: 'bold',
    color: '#07152E',
    textAlign: 'center',
  }}
>
  Não encontrámos vagas
</Text>

<Text
  style={{
    color: '#65738B',
    textAlign: 'center',
    marginTop: 8,
    lineHeight: 22,
    fontSize: 14,
  }}
>
  Experimenta pesquisar outra profissão ou alterar os filtros para descobrir novas oportunidades.
</Text>

    <Text
      style={{
        color: '#65738B',
        textAlign: 'center',
        marginTop: 8,
        lineHeight: 21,
      }}
    >
      Experimente seleccionar outra província ou tipo de emprego.
    </Text>

    <Pressable
      onPress={() => {
        setPesquisaVagas('');
        setProvinciaFiltro('Todas');
        setTipoEmpregoFiltro('Todos');
      }}
     style={{
  backgroundColor: '#123B70',
  paddingVertical: 15,
  paddingHorizontal: 26,
  borderRadius: 14,
  marginTop: 20,
  alignItems: 'center',
  justifyContent: 'center',
  borderWidth: 1,
  borderColor: '#2D5A91',
  shadowColor: '#07152E',
  shadowOffset: { width: 0, height: 4 },
  shadowOpacity: 0.18,
  shadowRadius: 7,
  elevation: 4,
}}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        Limpar filtros
      </Text>
    </Pressable>
  </View>
)}

{vagasFiltradas.map((vaga) => (
 <View
  key={vaga.id}
  style={{
    backgroundColor: '#FFFFFF',
    padding: 20,
    marginBottom: 18,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: '#DCE6F5',
    shadowColor: '#07152E',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 10,
    elevation: 4,
  }}
>
   <Text
  style={{
    fontSize: 20,
    fontWeight: 'bold',
    color: '#07152E',
    lineHeight: 27,
    marginBottom: 4,
  }}
>
  {vaga.titulo}
</Text>

    <View style={{ marginTop: 8 }}>
  <Text
    style={{
  color: '#123B70',
  fontSize: 15,
  fontWeight: '600',
  marginBottom: 8,
}}
  >
    🏢 {vaga.empresa || 'Empresa não indicada'}
  </Text>

  <Text
    style={{
  color: '#435572',
  fontSize: 14,
  lineHeight: 21,
  marginTop: 2,
}}style={{
  color: '#435572',
  fontSize: 14,
  lineHeight: 21,
  marginTop: 2,
}}
  >
    📍 {vaga.localizacao || 'Localização não indicada'}
  </Text>
</View>

{vaga.tipo ? (
  <View
 style={{
  alignSelf: 'flex-start',
  backgroundColor: '#EAF1FC',
  paddingVertical: 8,
  paddingHorizontal: 14,
  borderRadius: 20,
  marginTop: 14,
  borderWidth: 1,
  borderColor: '#C9D8ED',
}}
  >
   <Text
  style={{
    color: '#123B70',
    fontWeight: 'bold',
    fontSize: 13,
  }}
>
  {vaga.tipo}
</Text>
  </View>
) : null}


{vaga.salario ? (
  <View
    style={{
  flexDirection: 'row',
  alignItems: 'center',
  backgroundColor: '#E6F7ED',
  paddingVertical: 10,
  paddingHorizontal: 14,
  borderRadius: 12,
  marginTop: 12,
  alignSelf: 'flex-start',
  borderWidth: 1,
  borderColor: '#BFE8CF',
}}
  >
    <Text style={{ fontSize: 16, marginRight: 6 }}>
      💰
    </Text>

    <Text
      style={{
        color: '#16804A',
        fontWeight: 'bold',
        fontSize: 14,
      }}
    >
      {vaga.salario.trim().toLowerCase() === 'a combinar'
        ? 'Salário: A combinar'
        : `Salário: ${vaga.salario}`}
    </Text>
  </View>
) : null}


    <Text
  style={{
  color: '#435572',
  fontSize: 15,
  lineHeight: 24,
  marginTop: 16,
  marginBottom: 6,
}}
>
  {vaga.descricao || 'Sem descrição disponível.'}
</Text>
    <Pressable
      onPress={() => {
        setVagaSelecionada(vaga);
        if (sessaoCandidato) {
          setPagina('candidatura');
        } else {
          setMensagemLogin('');
          setPagina('login');
        }
      }}
      style={{
  backgroundColor: '#16804A',
  paddingVertical: 15,
  paddingHorizontal: 18,
  borderRadius: 12,
  marginTop: 16,
  alignItems: 'center',
  justifyContent: 'center',
  borderWidth: 1,
  borderColor: '#10713F',
  shadowColor: '#0B5D35',
  shadowOffset: { width: 0, height: 3 },
  shadowOpacity: 0.16,
  shadowRadius: 5,
  elevation: 3,
}}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        Candidatar-me
      </Text>
    </Pressable>

    <Pressable
      onPress={() => setVagaSelecionada(vaga)}
     style={{
  backgroundColor: '#123B70',
  paddingVertical: 15,
  paddingHorizontal: 18,
  borderRadius: 12,
  marginTop: 10,
  alignItems: 'center',
  justifyContent: 'center',
  borderWidth: 1,
  borderColor: '#244F87',
  shadowColor: '#07152E',
  shadowOffset: { width: 0, height: 3 },
  shadowOpacity: 0.12,
  shadowRadius: 5,
  elevation: 3,
}}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        Ver detalhes
      </Text>
    </Pressable>
  </View>
))}

  </View>

) : servicoSelecionado === 'Loja Online' ? (
  <View style={{ marginTop: 25 }}>
    <Text style={{ fontSize: 19, fontWeight: 'bold', marginBottom: 15 }}>
      Loja Online
    </Text>

    <Text style={{ color: '#65738B', marginBottom: 15 }}>
      Descubra produtos, consulte preços e prepare as suas compras.
    </Text>

    <Pressable
      onPress={() => {
        setMensagemLogin('');
        setPagina('login');
      }}
      style={{
        backgroundColor: '#123B70',
        padding: 14,
        borderRadius: 8,
        marginBottom: 18,
        alignItems: 'center',
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        🔐 Iniciar sessão
      </Text>
    </Pressable>

<View
  style={{
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 16,
    marginTop: 12,
    borderWidth: 1,
    borderColor: '#E3EAF4',
  }}
>
  <Text
    style={{
      fontSize: 21,
      fontWeight: 'bold',
      color: '#07152E',
      marginBottom: 6,
    }}
  >
    🛍️ Descubra os nossos produtos
  </Text>

  <Text style={{ color: '#65738B', marginBottom: 12 }}>
    Produtos de vendedores da Rede Nacional de Oportunidades.
  </Text>

  <TextInput
    style={{
      backgroundColor: '#F4F7FC',
      borderWidth: 1,
      borderColor: '#DCE6F2',
      borderRadius: 12,
      paddingHorizontal: 14,
      paddingVertical: 12,
      fontSize: 15,
      marginBottom: 12,
      color: '#07152E',
    }}
    placeholder="🔍 Pesquisar produtos..."
    placeholderTextColor="#7B8BA3"
    value={pesquisaProduto}
    onChangeText={setPesquisaProduto}
    autoCapitalize="none"
  />

  <ScrollView
    horizontal
    showsHorizontalScrollIndicator={false}
    style={{ marginBottom: 12 }}
    contentContainerStyle={{ paddingVertical: 4 }}
  >
    {[
      'Todas',
      ...new Set(
        produtos
          .map((produto) => produto.categoria)
          .filter(Boolean)
      ),
    ].map((categoria) => {
      const selecionada = categoriaFiltroProduto === categoria;

      return (
        <Pressable
          key={categoria}
          onPress={() => setCategoriaFiltroProduto(categoria)}
          style={{
            backgroundColor: selecionada ? '#1769FF' : '#F0F4FA',
            paddingHorizontal: 16,
            paddingVertical: 10,
            borderRadius: 22,
            marginRight: 8,
          }}
        >
          <Text
            style={{
              color: selecionada ? '#FFFFFF' : '#334761',
              fontWeight: '600',
            }}
          >
            {categoria}
          </Text>
        </Pressable>
      );
    })}

  </ScrollView>

  <View style={{ marginBottom: 12 }}>
    <Text
      style={{
        color: '#334761',
        fontWeight: '600',
        marginBottom: 7,
      }}
    >
      Ordenar produtos por:
    </Text>

    <View style={{ flexDirection: 'row', gap: 8 }}>
      {[
        { label: 'Recomendados', valor: 'recomendados' },
        { label: 'Menor preço', valor: 'menor' },
        { label: 'Maior preço', valor: 'maior' },
      ].map((opcao) => {
        const selecionada = ordenacaoProduto === opcao.valor;

        return (
          <Pressable
            key={opcao.valor}
            onPress={() => setOrdenacaoProduto(opcao.valor)}
            style={{
              backgroundColor: selecionada ? '#1769FF' : '#F0F4FA',
              paddingHorizontal: 10,
              paddingVertical: 10,
              borderRadius: 10,
              flex: 1,
              alignItems: 'center',
            }}
          >
            <Text
              style={{
                color: selecionada ? '#FFFFFF' : '#334761',
                fontWeight: '600',
                fontSize: 12,
              }}
            >
              {opcao.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  </View>

  {produtoSelecionado && (
    <View
      style={{
        backgroundColor: '#FFFFFF',
        borderRadius: 16,
        borderWidth: 1,
        borderColor: '#DCE6F2',
        padding: 16,
        marginBottom: 16,
      }}
    >
      <Text
        style={{
          fontSize: 21,
          fontWeight: 'bold',
          color: '#07152E',
          marginBottom: 12,
        }}
      >
        Detalhes do produto
      </Text>

      {produtoSelecionado.imagem_url ? (
        <Image
          source={{ uri: produtoSelecionado.imagem_url }}
          style={{
            width: '100%',
            height: 260,
            borderRadius: 12,
            marginBottom: 14,
            backgroundColor: '#EAF1FA',
          }}
          resizeMode="cover"
        />
      ) : (
        <Text style={{ color: '#65738B', marginBottom: 12 }}>
          Fotografia não disponível
        </Text>
      )}

      <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#07152E' }}>
        {produtoSelecionado.nome}
      </Text>

      <Text style={{ color: '#65738B', marginTop: 8 }}>
        Vendedor: {produtoSelecionado.nome_vendedor || 'Não identificado'}
      </Text>

      <Text style={{ color: '#65738B', marginTop: 6 }}>
        Categoria: {produtoSelecionado.categoria || 'Não indicada'}
      </Text>

      <Text
        style={{
          color: '#1769FF',
          fontSize: 25,
          fontWeight: 'bold',
          marginTop: 12,
        }}
      >
        {Number(produtoSelecionado.preco || 0).toLocaleString('pt-PT')} MT
      </Text>

      <Text style={{ color: '#53647C', marginTop: 10, lineHeight: 21 }}>
        {produtoSelecionado.descricao || 'Sem descrição disponível.'}
      </Text>

      <Text style={{ color: '#0B7A53', marginTop: 10 }}>
        Stock disponível: {Number(produtoSelecionado.stock || 0)}
      </Text>

      <Pressable
        onPress={() => {
          adicionarAoCarrinho(produtoSelecionado);
          setProdutoSelecionado(null);
        }}
        disabled={Number(produtoSelecionado.stock || 0) <= 0}
        style={{
          backgroundColor:
            Number(produtoSelecionado.stock || 0) > 0 ? '#1769FF' : '#A8B4C5',
          padding: 14,
          borderRadius: 10,
          marginTop: 16,
          alignItems: 'center',
        }}
      >
        <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
          🛒 Adicionar ao carrinho
        </Text>
      </Pressable>

      <Pressable
        onPress={() => setProdutoSelecionado(null)}
        style={{
          padding: 12,
          marginTop: 6,
          alignItems: 'center',
        }}
      >
        <Text style={{ color: '#1769FF', fontWeight: '600' }}>
          Voltar aos produtos
        </Text>
      </Pressable>
    </View>
  )}

  {mensagemCarrinho !== '' && (
    <Text
      style={{
        color: '#0B7A53',
        marginTop: 10,
        marginBottom: 10,
        fontWeight: '600',
      }}
    >
      {mensagemCarrinho}
    </Text>
  )}

  {erroProdutos !== '' && (
    <Text style={{ color: '#D32F2F', marginBottom: 10 }}>
      Erro ao carregar produtos: {erroProdutos}
    </Text>
  )}

  {!carregandoProdutos && (
    <Text
      style={{
        color: '#65738B',
        fontSize: 13,
        marginBottom: 8,
        fontWeight: '500',
      }}
    >
      {(() => {
        const termo = pesquisaProduto.trim().toLowerCase();

        const quantidade = produtos.filter((produto) => {
          const correspondeCategoria =
            categoriaFiltroProduto === 'Todas' ||
            (produto.categoria || '') === categoriaFiltroProduto;

          const correspondePesquisa =
            !termo ||
            (produto.nome || '').toLowerCase().includes(termo) ||
            (produto.categoria || '').toLowerCase().includes(termo) ||
            (produto.descricao || '').toLowerCase().includes(termo) ||
            (produto.nome_vendedor || '').toLowerCase().includes(termo);

          return correspondeCategoria && correspondePesquisa;
        }).length;

        return `${quantidade} ${
          quantidade === 1 ? 'produto encontrado' : 'produtos encontrados'
        }`;
      })()}
    </Text>
  )}

  {carregandoProdutos ? (
    <Text style={estilos.descricaoCartao}>
      A carregar produtos...
    </Text>
  ) : produtos.length === 0 ? (
    <Text style={estilos.descricaoCartao}>
      Ainda não existem produtos publicados. Volte mais tarde.
    </Text>
  ) : (
  
    produtos
      .filter((produto) => {
        const termo = pesquisaProduto.trim().toLowerCase();

        const correspondeCategoria =
          categoriaFiltroProduto === 'Todas' ||
          (produto.categoria || '') === categoriaFiltroProduto;

        const correspondePesquisa =
          !termo ||
          (produto.nome || '').toLowerCase().includes(termo) ||
          (produto.categoria || '').toLowerCase().includes(termo) ||
          (produto.descricao || '').toLowerCase().includes(termo) ||
          (produto.nome_vendedor || '').toLowerCase().includes(termo);

      
return correspondeCategoria && correspondePesquisa;
})
.sort((a, b) => {
  if (ordenacaoProduto === 'menor') {
    return Number(a.preco || 0) - Number(b.preco || 0);
  }

  if (ordenacaoProduto === 'maior') {
    return Number(b.preco || 0) - Number(a.preco || 0);
  }

  return 0;
})
.map((produto) => (

        <View
          key={produto.id}
          style={{
            backgroundColor: '#FFFFFF',
            borderWidth: 1,
            borderColor: '#E5ECF5',
            borderRadius: 16,
            padding: 12,
            marginTop: 14,
            overflow: 'hidden',
          }}
        >

        {produto.imagem_url ? (
          <Image
            source={{ uri: produto.imagem_url }}
            style={{
              width: '100%',
              height: 210,
              borderRadius: 12,
              marginBottom: 12,
              backgroundColor: '#EAF1FA',
            }}
            resizeMode="cover"
          />
        ) : (
          <View
            style={{
              width: '100%',
              height: 190,
              borderRadius: 12,
              marginBottom: 12,
              backgroundColor: '#EAF1FA',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Text style={{ fontSize: 44 }}>🛍️</Text>
            <Text style={{ color: '#65738B', marginTop: 8 }}>
              Fotografia não disponível
            </Text>
          </View>
        )}

        {produto.categoria ? (
          <View
            style={{
              alignSelf: 'flex-start',
              backgroundColor: '#EAF2FF',
              paddingHorizontal: 10,
              paddingVertical: 5,
              borderRadius: 20,
              marginBottom: 8,
            }}
          >
            <Text
              style={{
                color: '#1769FF',
                fontSize: 12,
                fontWeight: 'bold',
              }}
            >
              {produto.categoria}
            </Text>
          </View>
        ) : null}

       
        <Pressable
          onPress={() => setProdutoSelecionado(produto)}
          style={{ marginBottom: 5 }}
        >
          <Text
            style={{
              fontSize: 18,
              fontWeight: 'bold',
              color: '#07152E',
            }}
          >
            {produto.nome}
          </Text>
          <Text style={{ color: '#1769FF', fontSize: 12, marginTop: 4 }}>
            Ver detalhes do produto →
          </Text>
        </Pressable>


        <Text
          style={{
            color: '#65738B',
            fontSize: 13,
            marginBottom: 6,
          }}
        >
          Vendedor: {produto.nome_vendedor || 'não identificado'}
        </Text>

        {produto.descricao ? (
          <Text
            style={{
              color: '#53647C',
              fontSize: 14,
              lineHeight: 20,
              marginBottom: 10,
            }}
          >
            {produto.descricao}
          </Text>
        ) : null}

        <Text
          style={{
            color: '#1769FF',
            fontSize: 23,
            fontWeight: 'bold',
            marginTop: 4,
          }}
        >
          {Number(produto.preco).toLocaleString('pt-PT')} MT
        </Text>

        <Text
          style={{
            color: Number(produto.stock ?? 0) > 0 ? '#0B7A53' : '#D32F2F',
            fontSize: 13,
            fontWeight: '600',
            marginTop: 5,
          }}
        >
          {Number(produto.stock ?? 0) > 0
            ? `✓ ${produto.stock} unidade(s) disponível(is)`
            : 'Stock esgotado'}
        </Text>

        <Pressable
          onPress={() => adicionarAoCarrinho(produto)}
          disabled={Number(produto.stock ?? 0) <= 0}
          style={{
            backgroundColor:
              Number(produto.stock ?? 0) > 0 ? '#1769FF' : '#A8B4C5',
            padding: 14,
            borderRadius: 10,
            marginTop: 14,
            alignItems: 'center',
          }}
        >
          <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
            {Number(produto.stock ?? 0) > 0
              ? '🛒 Adicionar ao carrinho'
              : 'Produto indisponível'}
          </Text>
        </Pressable>
      </View>
    ))
  )}
</View>


<View style={estilos.cartao}>
  <Text style={estilos.tituloCartao}>
    🛒 Meu carrinho ({carrinho.reduce((total, item) => total + item.quantidade, 0)})
  </Text>

  {carrinho.length === 0 ? (
    <Text style={estilos.descricaoCartao}>
      Ainda não adicionou produtos ao carrinho.
    </Text>
  ) : (
    <>
      {carrinho.map((item) => (
        <View key={item.id} style={{ marginTop: 12 }}>
          <Text style={estilos.tituloCartao}>
            {item.nome}
          </Text>

          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              marginTop: 8,
              marginBottom: 4,
              flexWrap: 'wrap',
            }}
          >
            <Text style={[estilos.descricaoCartao, { marginRight: 10 }]}>
              Quantidade:
            </Text>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={`Diminuir quantidade de ${item.nome}`}
              onPress={() => atualizarQuantidadeCarrinho(item.id, item.quantidade - 1)}
              style={{
                backgroundColor: '#E8EEF7',
                width: 34,
                height: 34,
                borderRadius: 8,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Text style={{ color: '#123B70', fontWeight: 'bold', fontSize: 18 }}>−</Text>
            </Pressable>
            <Text style={{ color: '#123B70', fontWeight: 'bold', minWidth: 34, textAlign: 'center' }}>
              {item.quantidade}
            </Text>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={`Aumentar quantidade de ${item.nome}`}
              disabled={item.quantidade >= Number(item.stock ?? 0)}
              onPress={() => atualizarQuantidadeCarrinho(item.id, item.quantidade + 1)}
              style={{
                backgroundColor: item.quantidade >= Number(item.stock ?? 0) ? '#D5DDE8' : '#E8EEF7',
                width: 34,
                height: 34,
                borderRadius: 8,
                alignItems: 'center',
                justifyContent: 'center',
                opacity: item.quantidade >= Number(item.stock ?? 0) ? 0.55 : 1,
              }}
            >
              <Text style={{ color: '#123B70', fontWeight: 'bold', fontSize: 18 }}>+</Text>
            </Pressable>
            <Text style={{ color: '#65738B', fontSize: 12, marginLeft: 10 }}>
              Stock: {Number(item.stock ?? 0)}
            </Text>
          </View>

          <Text style={estilos.descricaoCartao}>
            Subtotal: {(Number(item.preco) * item.quantidade).toLocaleString('pt-PT')} MT
          </Text>

          <Pressable
            onPress={() => {
              setCarrinho(carrinho.filter((produto) => produto.id !== item.id));
              setMensagemCarrinho('');
            }}
            style={{
              backgroundColor: '#FCE8E6',
              padding: 8,
              borderRadius: 6,
              marginTop: 6,
              alignSelf: 'flex-start',
            }}
          >
            <Text style={{ color: '#B42318', fontWeight: 'bold' }}>
              Remover
            </Text>
          </Pressable>
        </View>
      ))}
<Text style={{ fontWeight: 'bold', marginTop: 16, color: '#123B70' }}>
  📍 Endereço de entrega
</Text>

<TextInput
  value={enderecoEntregaCliente}
  onChangeText={setEnderecoEntregaCliente}
  placeholder="Bairro, rua e número da casa"
  style={estilos.input}
/>

<Text style={{ fontWeight: 'bold', marginTop: 12, color: '#123B70' }}>
  📞 Telefone para entrega
</Text>

<TextInput
  value={telefoneEntregaCliente}
  onChangeText={setTelefoneEntregaCliente}
  placeholder="Contacto do destinatário"
  keyboardType="phone-pad"
  style={estilos.input}
/>

<Text style={{ fontWeight: 'bold', marginTop: 12, color: '#123B70' }}>
  📝 Observações (opcional)
</Text>

<TextInput
  value={observacoesEntregaCliente}
  onChangeText={setObservacoesEntregaCliente}
  placeholder="Referências para encontrar a morada"
  multiline
  style={[estilos.input, { minHeight: 70, textAlignVertical: 'top' }]}
/>
      <Text style={{ fontSize: 18, fontWeight: 'bold', marginTop: 16, color: '#0B7A53' }}>
        Total: {carrinho.reduce((total, item) => total + Number(item.preco) * item.quantidade, 0).toLocaleString('pt-PT')} MT
      </Text>

<Pressable
  disabled={processandoEncomenda || carrinho.length === 0}
  onPress={finalizarEncomenda}
  style={{
    backgroundColor:
      processandoEncomenda || carrinho.length === 0
        ? '#8AA0B8'
        : '#16804A',
    padding: 14,
    borderRadius: 8,
    marginTop: 16,
    alignItems: 'center',
  }}
>
  <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
    {processandoEncomenda
      ? 'A processar encomenda...'
      : 'Finalizar encomenda'}
  </Text>
</Pressable>

{mensagemEncomenda !== '' && (
  <Text style={{ marginTop: 12, color: '#123B70' }}>
    {mensagemEncomenda}
  </Text>
)}

    </>
  )}
</View>

<Pressable
  style={estilos.cartao}
  onPress={() => setPagina('painelVendedor')}
>
  <Text style={estilos.tituloCartao}>
    🏪 Painel do vendedor
  </Text>

  <Text style={estilos.descricaoCartao}>
    Gerir produtos, consultar encomendas recebidas e acompanhar vendas.
  </Text>
</Pressable>

    <Pressable
    style={estilos.cartao}
    onPress={() => setPagina('minhasEncomendas')}
  >
    <Text style={estilos.tituloCartao}>
      🧾 Minhas encomendas
    </Text>

    <Text style={estilos.descricaoCartao}>
      Consulte as suas compras e acompanhe o estado das encomendas.
    </Text>
 
  </Pressable>
  </View>
  
) : servicoSelecionado === 'Entregas' ? (
  <View style={{ marginTop: 25 }}>
    <Text style={{ fontSize: 19, fontWeight: 'bold', marginBottom: 10 }}>
      🚚 Serviço de Entregas
    </Text>

    <Text style={{ color: '#65738B', marginBottom: 18, lineHeight: 22 }}>
      Registe-se como entregador, consulte o estado do seu registo ou acompanhe as entregas atribuídas.
    </Text>

    {!sessaoCandidato ? (
      <Pressable
        onPress={() => {
          setMensagemLogin('');
          setPagina('login');
        }}
        style={{
          backgroundColor: '#123B70',
          padding: 14,
          borderRadius: 10,
          marginBottom: 16,
          alignItems: 'center',
        }}
      >
        <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
          🔐 Iniciar sessão
        </Text>
      </Pressable>
    ) : (
      <>
        <Pressable
          style={estilos.cartao}
          onPress={() => setPagina('registoEntregador')}
        >
          <Text style={estilos.tituloCartao}>
            📝 Registar-me como entregador
          </Text>
          <Text style={estilos.descricaoCartao}>
            Envie os seus dados para análise e aprovação.
          </Text>
        </Pressable>

        <Pressable
          style={estilos.cartao}
          onPress={async () => {
            await carregarEstadoEntregador();
            setPagina('estadoEntregador');
          }}
        >
          <Text style={estilos.tituloCartao}>
            📋 Estado do meu registo
          </Text>
          <Text style={estilos.descricaoCartao}>
            Consulte se o seu registo foi aprovado.
          </Text>
        </Pressable>

        <Pressable
          style={estilos.cartao}
          onPress={async () => {
            await carregarEntregasDoEntregador();
            setPagina('entregasEntregador');
          }}
        >
          <Text style={estilos.tituloCartao}>
            📦 Entregas atribuídas
          </Text>
          <Text style={estilos.descricaoCartao}>
            Consulte as entregas que lhe foram atribuídas.
          </Text>
        </Pressable>

        <Pressable
          style={estilos.cartao}
          onPress={async () => {
            await carregarEntregasCliente();
            setPagina('minhasEntregas');
          }}
        >
          <Text style={estilos.tituloCartao}>
            🛍️ Minhas entregas
          </Text>
          <Text style={estilos.descricaoCartao}>
            Acompanhe as entregas das suas encomendas.
          </Text>
        </Pressable>
      </>
    )}
  </View>

) : servicoSelecionado === 'Empresas' ? (
  <View style={{ marginTop: 25 }}>
    <Text style={{ fontSize: 19, fontWeight: 'bold', marginBottom: 15 }}>
      Empresas registadas na RNO
    </Text>

    <Text style={{ color: '#65738B', marginBottom: 15 }}>
      Conheça empresas e negócios disponíveis na plataforma.
    </Text>

    {carregandoEmpresasPublicas ? (
      <Text style={estilos.descricaoCartao}>
        A carregar empresas...
      </Text>
    ) : erroEmpresasPublicas ? (
      <Text style={{ color: '#B42318', marginBottom: 10 }}>
        Erro ao carregar empresas: {erroEmpresasPublicas}
      </Text>
    ) : empresasPublicas.length === 0 ? (
      <Text style={estilos.descricaoCartao}>
        Ainda não existem empresas para apresentar.
      </Text>
    ) : (
      empresasPublicas.map((empresa) => (
        <View key={empresa.id} style={estilos.cartao}>
          <Text style={estilos.tituloCartao}>
            {empresa.nome_empresa}
          </Text>

          {!!empresa.provincia && (
            <Text style={estilos.descricaoCartao}>
              📍 Província: {empresa.provincia}
            </Text>
          )}

          {!!empresa.area_atuacao && (
            <Text style={estilos.descricaoCartao}>
              Área de atuação: {empresa.area_atuacao}
            </Text>
          )}

          {!!empresa.descricao && (
            <Text style={estilos.descricaoCartao}>
              {empresa.descricao}
            </Text>
          )}
        </View>
      ))
    )}
  </View>
) : servicoSelecionado === 'Estudos' ? (
  <View style={{ marginTop: 20 }}>
    <Text style={estilos.descricaoCartao}>Cursos, bolsas, explicações e formação profissional.</Text>
    <TextInput value={pesquisaEstudos} onChangeText={setPesquisaEstudos} placeholder="Pesquisar cursos ou bolsas" style={estilos.input} />
    <View style={{ backgroundColor: '#FFF4D6', borderRadius: 10, padding: 12, marginTop: 12, marginBottom: 12 }}>
      <Text style={{ color: '#7A4B00', fontSize: 12 }}>Conteúdo demonstrativo: estas categorias não são ofertas reais nem estão ligadas ainda à base de dados.</Text>
    </View>
    {exemplosEstudo.filter((item) => `${item.titulo} ${item.categoria} ${item.descricao}`.toLowerCase().includes(pesquisaEstudos.trim().toLowerCase())).map((item) => (
      <View key={item.id} style={estilos.cartao}>
        <Text style={estilos.tituloCartao}>🎓 {item.titulo}</Text>
        <Text style={estilos.descricaoCartao}>{item.descricao}</Text>
        <Pressable onPress={() => Alert.alert(item.titulo, 'Esta área está preparada visualmente. As oportunidades reais serão ligadas a uma tabela de estudos no Supabase após validarmos a estrutura dos dados.')} style={{ backgroundColor: '#1769FF', padding: 11, borderRadius: 8, marginTop: 12, alignItems: 'center' }}>
          <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>Ver oportunidades</Text>
        </Pressable>
      </View>
    ))}
  </View>
) : servicoSelecionado === 'Serviços' ? (
  <View style={{ marginTop: 20 }}>
    <Text style={estilos.descricaoCartao}>Encontre profissionais e serviços para o dia a dia.</Text>
    <TextInput value={pesquisaProfissional} onChangeText={setPesquisaProfissional} placeholder="Pesquisar profissionais ou categorias" style={estilos.input} />
    <View style={{ backgroundColor: '#FFF4D6', borderRadius: 10, padding: 12, marginTop: 12, marginBottom: 12 }}>
      <Text style={{ color: '#7A4B00', fontSize: 12 }}>Categorias de demonstração. Os profissionais reais terão de ser registados e moderados.</Text>
    </View>
    {exemplosServicos.filter((item) => `${item.nome} ${item.categoria} ${item.descricao}`.toLowerCase().includes(pesquisaProfissional.trim().toLowerCase())).map((item) => (
      <View key={item.id} style={estilos.cartao}>
        <Text style={estilos.tituloCartao}>🧰 {item.nome}</Text>
        <Text style={estilos.descricaoCartao}>{item.descricao}</Text>
        <Pressable onPress={() => Alert.alert('Pedido de contacto', 'A categoria está disponível como demonstração. O pedido não foi enviado a nenhum profissional.')} style={{ backgroundColor: '#1769FF', padding: 11, borderRadius: 8, marginTop: 12, alignItems: 'center' }}>
          <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>Pedir contacto</Text>
        </Pressable>
      </View>
    ))}
  </View>
) : servicoSelecionado === 'Táxi' ? (
  <View style={{ marginTop: 20 }}>
    <Text style={estilos.descricaoCartao}>Prepare um pedido de viagem. O despacho de motoristas ainda não está ligado.</Text>
    <Text style={{ fontWeight: 'bold', marginTop: 14 }}>Local de partida</Text>
    <TextInput value={origemTaxi} onChangeText={setOrigemTaxi} placeholder="Ex.: Bairro, rua ou ponto de referência" style={estilos.input} />
    <Text style={{ fontWeight: 'bold', marginTop: 12 }}>Destino</Text>
    <TextInput value={destinoTaxi} onChangeText={setDestinoTaxi} placeholder="Para onde pretende ir?" style={estilos.input} />
    <Text style={{ fontWeight: 'bold', marginTop: 12 }}>Telefone de contacto</Text>
    <TextInput value={telefoneTaxi} onChangeText={setTelefoneTaxi} placeholder="+258 ..." keyboardType="phone-pad" style={estilos.input} />
    <Pressable onPress={prepararPedidoTaxi} style={{ backgroundColor: '#1769FF', padding: 14, borderRadius: 10, marginTop: 16, alignItems: 'center' }}>
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>Preparar pedido</Text>
    </Pressable>
    {pedidoTaxiPreparado && <View style={estilos.cartao}><Text style={estilos.tituloCartao}>Último pedido nesta sessão</Text><Text style={estilos.descricaoCartao}>Partida: {pedidoTaxiPreparado.origem}{'\n'}Destino: {pedidoTaxiPreparado.destino}{'\n'}Telefone: {pedidoTaxiPreparado.telefone}{'\n'}Criado: {pedidoTaxiPreparado.criadoEm}</Text><Text style={{ color: '#9A6700', marginTop: 8 }}>Ainda não enviado a um motorista.</Text></View>}
  </View>
) : servicoSelecionado === 'Pagamentos' ? (
  <View style={{ marginTop: 20 }}>
    <View style={{ backgroundColor: '#EAF2FF', borderRadius: 12, padding: 16 }}>
      <Text style={estilos.tituloCartao}>💳 Pagamentos digitais</Text>
      <Text style={estilos.descricaoCartao}>Esta secção vai permitir pagar produtos, entregas, viagens e serviços depois de integrarmos um fornecedor de pagamentos compatível com Moçambique.</Text>
    </View>
    {['M-Pesa', 'e-Mola', 'Cartão bancário', 'Transferência bancária'].map((metodo) => (
      <View key={metodo} style={[estilos.cartao, { width: '100%', minHeight: 0, marginTop: 8 }]}><Text style={estilos.tituloCartao}>{metodo}</Text><Text style={estilos.descricaoCartao}>Integração por validar. Nenhum pagamento pode ser efetuado nesta versão.</Text></View>
    ))}
    <Text style={{ color: '#7A4B00', marginTop: 10, fontSize: 12 }}>Não introduza PIN, senha bancária ou códigos secretos neste ecrã.</Text>
  </View>
) : servicoSelecionado === 'Comunicação' ? (
  <View style={{ marginTop: 20 }}>
    <Text style={estilos.descricaoCartao}>Área inicial para organizar mensagens e contactos. As mensagens abaixo ficam apenas na memória desta sessão.</Text>
    <Text style={{ fontWeight: 'bold', marginTop: 14 }}>Destinatário</Text>
    <TextInput value={destinatarioMensagem} onChangeText={setDestinatarioMensagem} placeholder="Nome ou contacto" style={estilos.input} />
    <Text style={{ fontWeight: 'bold', marginTop: 12 }}>Mensagem</Text>
    <TextInput value={textoMensagem} onChangeText={setTextoMensagem} placeholder="Escreva a sua mensagem" multiline style={[estilos.input, { minHeight: 90, textAlignVertical: 'top' }]} />
    <Pressable onPress={enviarMensagemLocal} style={{ backgroundColor: '#1769FF', padding: 14, borderRadius: 10, marginTop: 12, alignItems: 'center' }}><Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>Guardar rascunho</Text></Pressable>
    <Text style={[estilos.tituloServicos, { marginTop: 20 }]}>Rascunhos desta sessão ({mensagensLocais.length})</Text>
    {mensagensLocais.length === 0 ? <Text style={estilos.descricaoCartao}>Ainda não guardou mensagens.</Text> : mensagensLocais.map((item) => <View key={item.id} style={estilos.cartao}><Text style={estilos.tituloCartao}>Para: {item.destinatario}</Text><Text style={estilos.descricaoCartao}>{item.texto}</Text><Text style={{ color: '#65738B', fontSize: 11, marginTop: 8 }}>{item.data}</Text></View>)}
  </View>
) : servicoSelecionado === 'Publicidade' ? (
  <View style={{ marginTop: 20 }}>
    <Text style={estilos.descricaoCartao}>Prepare um pedido de divulgação para a sua empresa. A publicação de anúncios pagos ainda não está ativada.</Text>
    {['Produto', 'Vaga de emprego', 'Serviço', 'Empresa'].map((tipo) => <Pressable key={tipo} onPress={() => setTipoAnuncio(tipo)} style={{ padding: 13, borderRadius: 10, borderWidth: 1, borderColor: tipoAnuncio === tipo ? '#1769FF' : '#D6E2F0', backgroundColor: tipoAnuncio === tipo ? '#EAF2FF' : '#FFFFFF', marginTop: 9 }}><Text style={{ color: '#17345F', fontWeight: 'bold' }}>{tipoAnuncio === tipo ? '✓ ' : ''}{tipo}</Text></Pressable>)}
    <TextInput value={descricaoAnuncio} onChangeText={setDescricaoAnuncio} placeholder="Descreva o que pretende divulgar" multiline style={[estilos.input, { minHeight: 85, textAlignVertical: 'top', marginTop: 14 }]} />
    <Pressable onPress={() => { if (!descricaoAnuncio.trim()) { Alert.alert('Descrição necessária', 'Escreva o que pretende divulgar.'); return; } setEstadoPedidoPublicidade(`Pedido preparado para ${tipoAnuncio.toLowerCase()}: ${descricaoAnuncio.trim()}`); }} style={{ backgroundColor: '#1769FF', padding: 14, borderRadius: 10, marginTop: 12, alignItems: 'center' }}><Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>Preparar pedido de divulgação</Text></Pressable>
    {!!estadoPedidoPublicidade && <View style={[estilos.cartao, { width: '100%', minHeight: 0, marginTop: 12 }]}><Text style={estilos.tituloCartao}>Pedido desta sessão</Text><Text style={estilos.descricaoCartao}>{estadoPedidoPublicidade}</Text><Text style={{ color: '#7A4B00', fontSize: 12, marginTop: 8 }}>Não foi enviado nem publicado.</Text></View>}
  </View>
) : servicoSelecionado === 'Finanças' ? (
  <View style={{ marginTop: 20 }}>
    <View style={{ backgroundColor: '#EAF2FF', borderRadius: 12, padding: 16, marginBottom: 12 }}>
      <Text style={estilos.tituloCartao}>Resumo do orçamento (desta sessão)</Text>
      <Text style={{ color: '#0B7A53', fontSize: 18, fontWeight: 'bold', marginTop: 8 }}>Receitas: {movimentosFinanceiros.filter((m) => m.tipo === 'Receita').reduce((soma, m) => soma + m.valor, 0).toLocaleString('pt-PT')} MT</Text>
      <Text style={{ color: '#B42318', fontSize: 18, fontWeight: 'bold', marginTop: 5 }}>Despesas: {movimentosFinanceiros.filter((m) => m.tipo === 'Despesa').reduce((soma, m) => soma + m.valor, 0).toLocaleString('pt-PT')} MT</Text>
      <Text style={{ color: '#17345F', fontSize: 18, fontWeight: 'bold', marginTop: 5 }}>Saldo: {(movimentosFinanceiros.filter((m) => m.tipo === 'Receita').reduce((soma, m) => soma + m.valor, 0) - movimentosFinanceiros.filter((m) => m.tipo === 'Despesa').reduce((soma, m) => soma + m.valor, 0)).toLocaleString('pt-PT')} MT</Text>
    </View>
    <Text style={{ fontWeight: 'bold' }}>Tipo de movimento</Text>
    <View style={{ flexDirection: 'row', gap: 10, marginTop: 8 }}>
      {['Receita', 'Despesa'].map((tipo) => <Pressable key={tipo} onPress={() => setTipoMovimentoFinanceiro(tipo)} style={{ flex: 1, padding: 12, borderRadius: 8, backgroundColor: tipoMovimentoFinanceiro === tipo ? '#17345F' : '#E5EAF3', alignItems: 'center' }}><Text style={{ color: tipoMovimentoFinanceiro === tipo ? '#FFFFFF' : '#17345F', fontWeight: 'bold' }}>{tipo}</Text></Pressable>)}
    </View>
    <TextInput value={descricaoMovimentoFinanceiro} onChangeText={setDescricaoMovimentoFinanceiro} placeholder="Descrição (ex.: transporte)" style={estilos.input} />
    <TextInput value={valorMovimentoFinanceiro} onChangeText={setValorMovimentoFinanceiro} placeholder="Valor em MT" keyboardType="decimal-pad" style={estilos.input} />
    <Pressable onPress={adicionarMovimentoFinanceiro} style={{ backgroundColor: '#1769FF', padding: 14, borderRadius: 10, marginTop: 12, alignItems: 'center' }}><Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>Adicionar movimento</Text></Pressable>
    <Text style={[estilos.tituloServicos, { marginTop: 20 }]}>Movimentos ({movimentosFinanceiros.length})</Text>
    {movimentosFinanceiros.length === 0 ? <Text style={estilos.descricaoCartao}>Ainda não adicionou receitas ou despesas.</Text> : movimentosFinanceiros.map((item) => <View key={item.id} style={[estilos.cartao, { width: '100%', minHeight: 0 }]}><Text style={estilos.tituloCartao}>{item.tipo}: {item.descricao}</Text><Text style={estilos.descricaoCartao}>{item.valor.toLocaleString('pt-PT')} MT • {item.data}</Text></View>)}
    <Text style={{ color: '#7A4B00', fontSize: 12, marginTop: 8 }}>Os dados são temporários e desaparecem ao fechar/reiniciar a aplicação. Não é uma carteira nem um serviço bancário.</Text>
  </View>
) : (
  <Text style={{ marginTop: 20 }}>
    Serviço disponível em breve.
  </Text>
)}
  </View>
)}
{pagina === 'minhasEntregas' && (
  <View style={{ marginTop: 20 }}>
    <Pressable onPress={() => setPagina('servico')}><Text style={{ color: '#1769FF', fontSize: 16 }}>← Voltar aos serviços</Text></Pressable>
    <Text style={[estilos.tituloPrincipal, { marginBottom: 12 }]}>Minhas entregas</Text>
    {carregandoEntregas ? <Text style={estilos.descricaoCartao}>A carregar entregas...</Text> : erroEntregas ? <Text style={{ color: '#B42318', marginBottom: 12 }}>{erroEntregas}</Text> : entregasCliente.length === 0 ? <View style={estilos.cartao}><Text style={estilos.tituloCartao}>Ainda sem entregas</Text><Text style={estilos.descricaoCartao}>As entregas associadas às suas encomendas aparecerão aqui depois de serem registadas.</Text></View> : entregasCliente.map((entrega, index) => <View key={entrega.id || `${entrega.encomenda_id || 'entrega'}-${index}`} style={estilos.cartao}><Text style={estilos.tituloCartao}>Entrega {entrega.numero || entrega.id || index + 1}</Text><Text style={estilos.descricaoCartao}>Estado: {entrega.estado || entrega.status || 'Por confirmar'}</Text>{!!entrega.endereco_recolha && <Text style={estilos.descricaoCartao}>Recolha: {entrega.endereco_recolha}</Text>}{!!entrega.endereco_entrega && <Text style={estilos.descricaoCartao}>Destino: {entrega.endereco_entrega}</Text>}{!!entrega.telefone_destinatario && <Text style={estilos.descricaoCartao}>Contacto: {entrega.telefone_destinatario}</Text>}</View>)}
  </View>
)}

{pagina === 'loginAdmin' && (
  <View style={{ marginTop: 20 }}>
    <Pressable onPress={() => setPagina('inicio')}>
      <Text style={{ color: '#1769FF', fontSize: 16 }}>
        ← Voltar ao início
      </Text>
    </Pressable>

    <Text
      style={{
        fontSize: 26,
        fontWeight: 'bold',
        color: '#07152E',
        marginTop: 24,
      }}
    >
      Área Administrativa
    </Text>

    <Text
      style={{
        color: '#65738B',
        marginTop: 8,
        marginBottom: 24,
      }}
    >
      Acesso reservado à administração da RNO.
    </Text>

    <Text style={{ fontWeight: 'bold', color: '#172B4D' }}>
      Email do administrador
    </Text>

    <TextInput
      value={emailAdmin}
      onChangeText={setEmailAdmin}
      placeholder="Digite o email administrativo"
      keyboardType="email-address"
      autoCapitalize="none"
      style={estilos.input}
    />

    <Text
      style={{
        fontWeight: 'bold',
        color: '#172B4D',
        marginTop: 16,
      }}
    >
      Palavra-passe
    </Text>

    <TextInput
      value={senhaAdmin}
      onChangeText={setSenhaAdmin}
      placeholder="Digite a palavra-passe"
      secureTextEntry
      style={estilos.input}
    />

    {mensagemAdmin !== '' && (
      <Text
        style={{
          color: '#123B70',
          marginTop: 16,
          lineHeight: 21,
        }}
      >
        {mensagemAdmin}
      </Text>
    )}

    <Pressable
      onPress={entrarAdmin}
      style={{
        backgroundColor: '#1769FF',
        padding: 16,
        borderRadius: 12,
        marginTop: 24,
        alignItems: 'center',
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold', fontSize: 16 }}>
        Entrar como administrador
      </Text>
    </Pressable>

    <Pressable
      onPress={() => {
        setEmailRecuperacaoSenha(emailAdmin);
        setMensagemRecuperacaoSenha('');
        setPaginaAnteriorRecuperacaoSenha('loginAdmin');
        setPagina('recuperarSenha');
      }}
      style={{ padding: 12, alignItems: 'center', marginTop: 6 }}
    >
      <Text style={{ color: '#1769FF', fontWeight: '600' }}>Esqueci-me da palavra-passe</Text>
    </Pressable>
  </View>
)}

{pagina === 'painelAdmin' && (
  <View style={{ marginTop: 20, marginBottom: 30 }}>
    <Text
      style={{
        fontSize: 26,
        fontWeight: 'bold',
        color: '#07152E',
        marginBottom: 8,
      }}
    >
      Painel Administrativo RNO
    </Text>

    <Text style={{ color: '#65738B', marginBottom: 20 }}>
      Gestão e aprovação de entregadores.
    </Text>

    <Pressable
      onPress={carregarEntregadoresAdmin}
      style={{
        backgroundColor: '#1769FF',
        padding: 14,
        borderRadius: 10,
        alignItems: 'center',
        marginBottom: 20,
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        Atualizar lista de entregadores
      </Text>
    </Pressable>

    {carregandoEntregadoresAdmin && (
      <Text style={{ color: '#435572', marginBottom: 12 }}>
        A carregar entregadores...
      </Text>
    )}

    {erroEntregadoresAdmin !== '' && (
      <Text style={{ color: '#C62828', marginBottom: 12 }}>
        {erroEntregadoresAdmin}
      </Text>
    )}

    {mensagemAdmin !== '' && (
      <Text style={{ color: '#123B70', marginBottom: 12 }}>
        {mensagemAdmin}
      </Text>
    )}

    {!carregandoEntregadoresAdmin &&
      erroEntregadoresAdmin === '' &&
      entregadoresAdmin.length === 0 && (
        <Text style={{ color: '#65738B', marginTop: 8 }}>
          Ainda não existem entregadores para apresentar.
        </Text>
      )}

    {entregadoresAdmin.map((entregador) => (
      <View
        key={entregador.id}
        style={{
          backgroundColor: '#FFFFFF',
          borderWidth: 1,
          borderColor: '#DCE5F2',
          borderRadius: 12,
          padding: 16,
          marginBottom: 14,
        }}
      >
        <Text
          style={{
            fontSize: 17,
            fontWeight: 'bold',
            color: '#07152E',
            marginBottom: 8,
          }}
        >
          {entregador.nome_completo}
        </Text>

        <Text style={{ color: '#435572', marginBottom: 4 }}>
          Telefone: {entregador.telefone || 'Não informado'}
        </Text>

        <Text style={{ color: '#435572', marginBottom: 8 }}>
          Província: {entregador.provincia || 'Não informada'}
        </Text>

        <Text
          style={{
            color: entregador.ativo ? '#16803D' : '#B26A00',
            fontWeight: 'bold',
            marginBottom: 14,
          }}
        >
          Estado: {entregador.ativo ? 'Aprovado' : 'Pendente'}
        </Text>

        <Pressable
          onPress={() =>
            alterarEstadoEntregadorAdmin(entregador.id, !entregador.ativo)
          }
          style={{
            backgroundColor: entregador.ativo ? '#B42318' : '#16803D',
            padding: 12,
            borderRadius: 8,
            alignItems: 'center',
          }}
        >
          <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
            {entregador.ativo ? 'Desativar entregador' : 'Aprovar entregador'}
          </Text>
        </Pressable>
      </View>
    ))}

    <Pressable
      onPress={() => terminarSessao('admin')}
      style={{
        borderWidth: 1,
        borderColor: '#1769FF',
        padding: 14,
        borderRadius: 10,
        alignItems: 'center',
        marginTop: 8,
      }}
    >
      <Text style={{ color: '#1769FF', fontWeight: 'bold' }}>
        Sair da área administrativa
      </Text>
    </Pressable>
  </View>
)}

{pagina === 'registoCandidato' && (
  <View style={{ marginTop: 20, paddingBottom: 24 }}>
    <Pressable onPress={() => setPagina('login')} style={{ marginBottom: 18 }}>
      <Text style={{ color: '#1769FF', fontSize: 16 }}>← Voltar ao início de sessão</Text>
    </Pressable>

    <Text style={{ fontSize: 25, fontWeight: 'bold', color: '#07152E' }}>
      Criar conta de candidato
    </Text>
    <Text style={{ color: '#65738B', marginTop: 8, marginBottom: 18, lineHeight: 21 }}>
      Registe os seus dados para procurar oportunidades e acompanhar as suas candidaturas.
    </Text>

    <TextInput value={nomeCadastroCandidato} onChangeText={setNomeCadastroCandidato} placeholder="Nome completo *" autoCapitalize="words" style={estilos.input} />
    <TextInput value={telefoneCadastroCandidato} onChangeText={setTelefoneCadastroCandidato} placeholder="Telefone *" keyboardType="phone-pad" style={estilos.input} />
    <TextInput value={provinciaCadastroCandidato} onChangeText={setProvinciaCadastroCandidato} placeholder="Província *" autoCapitalize="words" style={estilos.input} />
    <TextInput value={areaCadastroCandidato} onChangeText={setAreaCadastroCandidato} placeholder="Área profissional *" autoCapitalize="sentences" style={estilos.input} />
    <TextInput value={experienciaCadastroCandidato} onChangeText={setExperienciaCadastroCandidato} placeholder="Experiência profissional (opcional)" multiline style={[estilos.input, { minHeight: 76, textAlignVertical: 'top' }]} />
    <TextInput value={emailCadastroCandidato} onChangeText={setEmailCadastroCandidato} placeholder="Email *" keyboardType="email-address" autoCapitalize="none" autoCorrect={false} style={estilos.input} />
    <TextInput value={senhaCadastroCandidato} onChangeText={setSenhaCadastroCandidato} placeholder="Palavra-passe (mínimo 6 caracteres) *" secureTextEntry autoCapitalize="none" style={estilos.input} />
    <TextInput value={confirmarSenhaCadastroCandidato} onChangeText={setConfirmarSenhaCadastroCandidato} placeholder="Confirmar palavra-passe *" secureTextEntry autoCapitalize="none" style={estilos.input} />

    {!!mensagemCadastroCandidato && (
      <Text style={{ color: /criada|sucesso|confirme/i.test(mensagemCadastroCandidato) ? '#18794E' : '#B42318', marginTop: 6, marginBottom: 12, lineHeight: 21 }}>
        {mensagemCadastroCandidato}
      </Text>
    )}

    <Pressable onPress={cadastrarCandidato} disabled={aCadastrarCandidato} style={{ backgroundColor: aCadastrarCandidato ? '#8AA0B8' : '#1769FF', padding: 15, borderRadius: 10, marginTop: 8, alignItems: 'center', opacity: aCadastrarCandidato ? 0.7 : 1 }}>
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>{aCadastrarCandidato ? 'A criar conta...' : 'Criar conta de candidato'}</Text>
    </Pressable>
  </View>
)}

{pagina === 'recuperarSenha' && (
  <View style={{ marginTop: 20, paddingBottom: 28 }}>
    <Pressable
      onPress={() => {
        setMensagemRecuperacaoSenha('');
        setPagina(paginaAnteriorRecuperacaoSenha || 'login');
      }}
      style={{ marginBottom: 18 }}
    >
      <Text style={{ color: '#1769FF', fontSize: 16 }}>← Voltar ao início de sessão</Text>
    </Pressable>

    <Text style={{ fontSize: 25, fontWeight: 'bold', color: '#07152E' }}>
      Recuperar palavra-passe
    </Text>
    <Text style={{ color: '#65738B', marginTop: 8, marginBottom: 20, lineHeight: 22 }}>
      Introduza o email usado na sua conta RNO. Enviaremos instruções para definir uma nova palavra-passe.
    </Text>

    <Text style={{ fontWeight: 'bold', color: '#172B4D', marginBottom: 6 }}>Email</Text>
    <TextInput
      value={emailRecuperacaoSenha}
      onChangeText={setEmailRecuperacaoSenha}
      placeholder="Digite o email da sua conta"
      keyboardType="email-address"
      autoCapitalize="none"
      autoCorrect={false}
      style={estilos.input}
      editable={!aEnviarRecuperacaoSenha}
    />

    {!!mensagemRecuperacaoSenha && (
      <Text
        style={{
          color: aEnviarRecuperacaoSenha
            ? '#123B70'
            : (/Se existir uma conta associada/i.test(mensagemRecuperacaoSenha) ? '#18794E' : '#B42318'),
          marginTop: 8,
          marginBottom: 12,
          lineHeight: 22,
        }}
      >
        {mensagemRecuperacaoSenha}
      </Text>
    )}

    <Pressable
      onPress={solicitarRecuperacaoSenha}
      disabled={aEnviarRecuperacaoSenha}
      style={{
        backgroundColor: aEnviarRecuperacaoSenha ? '#8AA0B8' : '#123B70',
        padding: 15,
        borderRadius: 10,
        alignItems: 'center',
        marginTop: 8,
        opacity: aEnviarRecuperacaoSenha ? 0.7 : 1,
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        {aEnviarRecuperacaoSenha ? 'A enviar pedido...' : 'Enviar instruções de recuperação'}
      </Text>
    </Pressable>

    <Text style={{ color: '#65738B', fontSize: 13, lineHeight: 19, marginTop: 14 }}>
      Depois de alterar a palavra-passe na página da RNO aberta pelo email, volte a este aplicativo e entre com a nova palavra-passe.
    </Text>
  </View>
)}

{pagina === 'login' && (
  <View style={{ marginTop: 20, paddingBottom: 24 }}>
    <Pressable onPress={() => setPagina('inicio')} style={{ marginBottom: 18 }}>
      <Text style={{ color: '#1769FF', fontSize: 16 }}>← Voltar ao início</Text>
    </Pressable>

    <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#123B70' }}>
      Iniciar sessão
    </Text>
    <Text style={{ color: '#65738B', marginTop: 8, marginBottom: 20 }}>
      Entre na sua conta RNO para se candidatar às vagas.
    </Text>

    <Text style={{ fontWeight: 'bold', color: '#172B4D', marginBottom: 6 }}>Email</Text>
    <TextInput
      value={emailCandidato}
      onChangeText={setEmailCandidato}
      placeholder="Digite o seu email"
      keyboardType="email-address"
      autoCapitalize="none"
      autoCorrect={false}
      style={estilos.input}
    />

    <Text style={{ fontWeight: 'bold', color: '#172B4D', marginBottom: 6, marginTop: 4 }}>Palavra-passe</Text>
    <TextInput
      value={senhaCandidato}
      onChangeText={setSenhaCandidato}
      placeholder="Digite a sua palavra-passe"
      secureTextEntry
      autoCapitalize="none"
      style={estilos.input}
    />

    {!!mensagemLogin && (
      <Text style={{ color: /sucesso|bem-vindo/i.test(mensagemLogin) ? '#18794E' : '#B42318', marginBottom: 12, lineHeight: 21 }}>
        {mensagemLogin}
      </Text>
    )}

    <Pressable
      onPress={entrarCandidato}
      disabled={aEntrarCandidato}
      style={{
        backgroundColor: aEntrarCandidato ? '#8AA0B8' : '#123B70',
        padding: 14,
        borderRadius: 8,
        alignItems: 'center',
        marginTop: 8,
        opacity: aEntrarCandidato ? 0.75 : 1,
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        {aEntrarCandidato ? 'A verificar os dados...' : 'Entrar'}
      </Text>
    </Pressable>

    <Pressable
      onPress={() => {
        setEmailRecuperacaoSenha(emailCandidato);
        setMensagemRecuperacaoSenha('');
        setPaginaAnteriorRecuperacaoSenha('login');
        setPagina('recuperarSenha');
      }}
      style={{ padding: 12, alignItems: 'center', marginTop: 6 }}
    >
      <Text style={{ color: '#1769FF', fontWeight: '600' }}>Esqueci-me da palavra-passe</Text>
    </Pressable>

    <Pressable
      onPress={() => { setMensagemCadastroCandidato(''); setPagina('registoCandidato'); }}
      style={{ borderWidth: 1, borderColor: '#1769FF', padding: 14, borderRadius: 8, alignItems: 'center', marginTop: 12 }}
    >
      <Text style={{ color: '#1769FF', fontWeight: 'bold' }}>Criar conta de candidato</Text>
    </Pressable>

    <Pressable onPress={() => setPagina('empresa')} style={{ padding: 12, alignItems: 'center', marginTop: 8 }}>
      <Text style={{ color: '#123B70' }}>Entrar ou registar uma empresa</Text>
    </Pressable>
  </View>
)}

{pagina === 'empresa' && (
  <View style={{ marginTop: 20, paddingBottom: 20 }}>
    <Text style={{
      fontSize: 24,
      fontWeight: 'bold',
      color: '#123B70'
    }}>
      Painel da Empresa
    </Text>

    {aCompletarPerfilEmpresa ? (
      <>
        <Text style={{ color: '#65738B', marginTop: 8, marginBottom: 14, lineHeight: 21 }}>
          A conta foi autenticada, mas o perfil da empresa ainda precisa de ser guardado. Confirme os dados abaixo. O perfil será criado apenas depois de iniciar sessão.
        </Text>
        <Text style={{ color: '#123B70', marginBottom: 12, fontWeight: '600' }}>
          Email autenticado: {sessaoEmpresaPendentePerfil?.user?.email || emailEmpresa}
        </Text>
        <TextInput placeholder="Nome da empresa *" value={nomeEmpresaCadastro} onChangeText={setNomeEmpresaCadastro} style={estilos.input} />
        <TextInput placeholder="Nome do responsável *" value={responsavelEmpresaCadastro} onChangeText={setResponsavelEmpresaCadastro} style={estilos.input} />
        <TextInput placeholder="Telefone *" value={telefoneEmpresaCadastro} onChangeText={setTelefoneEmpresaCadastro} keyboardType="phone-pad" style={estilos.input} />
        <TextInput placeholder="Província *" value={provinciaEmpresaCadastro} onChangeText={setProvinciaEmpresaCadastro} style={estilos.input} />
        <TextInput placeholder="Área de atuação *" value={areaEmpresaCadastro} onChangeText={setAreaEmpresaCadastro} style={estilos.input} />
        <TextInput placeholder="Descrição da empresa (opcional)" value={descricaoEmpresaCadastro} onChangeText={setDescricaoEmpresaCadastro} multiline style={[estilos.input, { minHeight: 76, textAlignVertical: 'top' }]} />
        {!!mensagemCadastroEmpresa && (
          <Text style={{ color: /sucesso|guardado/i.test(mensagemCadastroEmpresa) ? '#18794E' : '#B42318', marginTop: 6, marginBottom: 12, lineHeight: 21 }}>
            {mensagemCadastroEmpresa}
          </Text>
        )}
        <Pressable onPress={guardarPerfilEmpresaPendente} disabled={aCadastrarEmpresa} style={{ backgroundColor: aCadastrarEmpresa ? '#8AA0B8' : '#1769FF', padding: 14, borderRadius: 10, alignItems: 'center', opacity: aCadastrarEmpresa ? 0.6 : 1 }}>
          <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>{aCadastrarEmpresa ? 'A guardar perfil...' : 'Guardar perfil e continuar'}</Text>
        </Pressable>
        <Pressable onPress={cancelarCompletarPerfilEmpresa} style={{ borderWidth: 1, borderColor: '#D5DCE5', padding: 12, borderRadius: 10, alignItems: 'center', marginTop: 10 }}>
          <Text style={{ color: '#65738B', fontWeight: '600' }}>Terminar sessão e voltar</Text>
        </Pressable>
      </>
    ) : !sessaoEmpresa ? (
      <>
        <Text style={{ color: '#65738B', marginTop: 8, marginBottom: 16 }}>
          Entre com a conta da empresa que já utiliza no site da RNO.
        </Text>

        <TextInput
          placeholder="Email da empresa"
          value={emailEmpresa}
          onChangeText={setEmailEmpresa}
          keyboardType="email-address"
          autoCapitalize="none"
          style={{
            borderWidth: 1,
            borderColor: '#D5DCE5',
            borderRadius: 8,
            padding: 12,
            marginBottom: 12
          }}
        />

        <TextInput
          placeholder="Palavra-passe"
          value={senhaEmpresa}
          onChangeText={setSenhaEmpresa}
          secureTextEntry
          style={{
            borderWidth: 1,
            borderColor: '#D5DCE5',
            borderRadius: 8,
            padding: 12,
            marginBottom: 12
          }}
        />

        <Pressable
          onPress={entrarEmpresa}
          style={{
            backgroundColor: '#123B70',
            padding: 14,
            borderRadius: 8,
            alignItems: 'center'
          }}
        >
          <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
            Entrar como empresa
          </Text>
        </Pressable>

        <Pressable
          onPress={() => {
            setEmailRecuperacaoSenha(emailEmpresa);
            setMensagemRecuperacaoSenha('');
            setPaginaAnteriorRecuperacaoSenha('empresa');
            setPagina('recuperarSenha');
          }}
          style={{ padding: 12, alignItems: 'center', marginTop: 4 }}
        >
          <Text style={{ color: '#1769FF', fontWeight: '600' }}>Esqueci-me da palavra-passe</Text>
        </Pressable>

        {!!mensagemEmpresa && (
          <Text style={{ color: '#C0392B', marginTop: 12 }}>
            {mensagemEmpresa}
          </Text>
        )}
                <View
          style={{
            marginTop: 30,
            padding: 16,
            backgroundColor: '#F0F5FC',
            borderRadius: 12,
            borderWidth: 1,
            borderColor: '#D5E3F7',
          }}
        >
          <Text
            style={{
              fontSize: 21,
              fontWeight: 'bold',
              color: '#123B70',
              marginBottom: 8,
            }}
          >
            Criar conta de empresa
          </Text>

          <Text style={{ color: '#65738B', marginBottom: 16 }}>
            Preencha os dados para registar a sua empresa na RNO.
          </Text>

          <TextInput
            placeholder="Nome da empresa"
            value={nomeEmpresaCadastro}
            onChangeText={setNomeEmpresaCadastro}
            style={{
              backgroundColor: '#FFFFFF',
              borderWidth: 1,
              borderColor: '#D5DCE5',
              borderRadius: 8,
              padding: 12,
              marginBottom: 12,
            }}
          />

          <TextInput
            placeholder="Nome do responsável"
            value={responsavelEmpresaCadastro}
            onChangeText={setResponsavelEmpresaCadastro}
            style={{
              backgroundColor: '#FFFFFF',
              borderWidth: 1,
              borderColor: '#D5DCE5',
              borderRadius: 8,
              padding: 12,
              marginBottom: 12,
            }}
          />

          <TextInput
            placeholder="Telefone"
            value={telefoneEmpresaCadastro}
            onChangeText={setTelefoneEmpresaCadastro}
            keyboardType="phone-pad"
            style={{
              backgroundColor: '#FFFFFF',
              borderWidth: 1,
              borderColor: '#D5DCE5',
              borderRadius: 8,
              padding: 12,
              marginBottom: 12,
            }}
          />

          <TextInput
            placeholder="Província"
            value={provinciaEmpresaCadastro}
            onChangeText={setProvinciaEmpresaCadastro}
            style={{
              backgroundColor: '#FFFFFF',
              borderWidth: 1,
              borderColor: '#D5DCE5',
              borderRadius: 8,
              padding: 12,
              marginBottom: 12,
            }}
          />

          <TextInput
            placeholder="Área de atuação"
            value={areaEmpresaCadastro}
            onChangeText={setAreaEmpresaCadastro}
            style={{
              backgroundColor: '#FFFFFF',
              borderWidth: 1,
              borderColor: '#D5DCE5',
              borderRadius: 8,
              padding: 12,
              marginBottom: 12,
            }}
          />

          <TextInput
            placeholder="Descrição da empresa (opcional)"
            value={descricaoEmpresaCadastro}
            onChangeText={setDescricaoEmpresaCadastro}
            multiline
            numberOfLines={3}
            style={{
              backgroundColor: '#FFFFFF',
              borderWidth: 1,
              borderColor: '#D5DCE5',
              borderRadius: 8,
              padding: 12,
              marginBottom: 12,
              minHeight: 80,
              textAlignVertical: 'top',
            }}
          />

          <TextInput
            placeholder="Confirmar palavra-passe para criar conta *"
            value={confirmarSenhaEmpresaCadastro}
            onChangeText={setConfirmarSenhaEmpresaCadastro}
            secureTextEntry
            autoCapitalize="none"
            style={{
              backgroundColor: '#FFFFFF',
              borderWidth: 1,
              borderColor: '#D5DCE5',
              borderRadius: 8,
              padding: 12,
              marginBottom: 12,
            }}
          />

          <Text style={{ color: '#123B70', marginBottom: 8 }}>
            O email e a palavra-passe acima serão usados para criar a conta. Confirme a palavra-passe antes de registar a empresa.
          </Text>

          <Pressable
            onPress={cadastrarEmpresa}
            disabled={aCadastrarEmpresa}
            style={{
              backgroundColor: '#1769FF',
              padding: 14,
              borderRadius: 8,
              alignItems: 'center',
              opacity: aCadastrarEmpresa ? 0.6 : 1,
            }}
          >
            <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
              {aCadastrarEmpresa
                ? 'A criar conta...'
                : 'Criar conta de empresa'}
            </Text>
          </Pressable>

          {!!mensagemCadastroEmpresa && (
            <Text
              style={{
                color: mensagemCadastroEmpresa.includes('sucesso')
                  ? '#18794E'
                  : '#C0392B',
                marginTop: 12,
                lineHeight: 21,
              }}
            >
              {mensagemCadastroEmpresa}
            </Text>
          )}
        </View>
      </>
    ) : (
      <>
        <Text style={{ color: '#28C76F', marginTop: 10 }}>
          Sessão da empresa iniciada.
        </Text>

        <Text style={{
          fontSize: 18,
          fontWeight: 'bold',
          color: '#123B70',
          marginTop: 22
        }}>
          Candidaturas recebidas: {candidaturasEmpresa.length}
        </Text>

        <Pressable
          onPress={carregarCandidaturasEmpresa}
          disabled={carregandoCandidaturasEmpresa}
          style={{
            backgroundColor: '#123B70',
            padding: 14,
            borderRadius: 8,
            marginTop: 14,
            alignItems: 'center',
            opacity: carregandoCandidaturasEmpresa ? 0.6 : 1
          }}
        >
          <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
            {carregandoCandidaturasEmpresa
              ? 'A carregar candidaturas...'
              : 'Consultar candidaturas'}
          </Text>
        </Pressable>

        {!!erroCandidaturasEmpresa && (
          <Text style={{ color: '#C0392B', marginTop: 12 }}>
            {erroCandidaturasEmpresa}
          </Text>
        )}

{!!mensagemEstadoCandidatura && (
  <View
    style={{
      backgroundColor: '#E8F8EF',
      borderWidth: 1,
      borderColor: '#28C76F',
      borderRadius: 8,
      padding: 12,
      marginTop: 12,
    }}
  >
    <Text style={{ color: '#18794E', fontWeight: 'bold' }}>
      ✓ {mensagemEstadoCandidatura}
    </Text>
  </View>
)}

        {candidaturasEmpresa.length === 0 &&
          !carregandoCandidaturasEmpresa &&
          !erroCandidaturasEmpresa && (
            <Text style={{ color: '#65738B', marginTop: 14 }}>
              Clique em “Consultar candidaturas” para carregar os dados.
            </Text>
          )}

        {candidaturasEmpresa.map((item, index) => (
          <View
            key={item.id || index}
            style={{
              backgroundColor: '#FFFFFF',
              borderWidth: 1,
              borderColor: '#D5DCE5',
              borderRadius: 10,
              padding: 14,
              marginTop: 12
            }}
          >
            <Text style={{
              fontSize: 17,
              fontWeight: 'bold',
              color: '#123B70'
            }}>
              {item.nome_completo || 'Candidato sem nome'}
            </Text>

            <Text style={{ color: '#65738B', marginTop: 8 }}>
              Vaga: {item.vagas?.titulo || item.vaga || 'Não indicada'}
            </Text>

            <Text style={{ color: '#65738B', marginTop: 6 }}>
              Email: {item.email || 'Não indicado'}
            </Text>

            <Text style={{ color: '#65738B', marginTop: 6 }}>
              Telefone: {item.telefone || 'Não indicado'}
            </Text>

            
<Text style={{ color: '#65738B', marginTop: 6 }}>
  Estado atual: {item.status || 'Em análise'}
</Text>

<View style={{ marginTop: 10 }}>
  {['Em análise', 'Pré-selecionado', 'Aprovado', 'Rejeitado'].map((estado) => (
    <Pressable
      key={estado}
      onPress={() => atualizarEstadoCandidatura(item, estado)}
      style={{
        backgroundColor:
          item.status === estado ? '#28C76F' : '#E8EEF7',
        padding: 10,
        borderRadius: 8,
        alignItems: 'center',
        marginBottom: 6,
      }}
    >
      <Text
        style={{
          color: item.status === estado ? '#FFFFFF' : '#123B70',
          fontWeight: 'bold',
        }}
      >
        {estado}
      </Text>
    </Pressable>
  ))}
</View>


{!!item.mensagem && (
  <Text style={{ color: '#172B4D', marginTop: 8 }}>
    Mensagem: {item.mensagem}
  </Text>
)}
          </View>
        ))}

      </>
    )}

    <Pressable
      onPress={() => {
        if (aCompletarPerfilEmpresa) {
          cancelarCompletarPerfilEmpresa();
          return;
        }
        setPagina(sessaoEmpresa?.access_token ? 'painelVendedor' : 'inicio');
      }}
      style={{
        backgroundColor: '#65738B',
        padding: 14,
        borderRadius: 8,
        marginTop: 20,
        alignItems: 'center'
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        {sessaoEmpresa?.access_token && !aCompletarPerfilEmpresa ? 'Voltar ao painel da empresa' : 'Voltar ao início'}
      </Text>
    </Pressable>
  </View>
)}


    
{pagina === 'registoEntregador' && (
  <View style={{ padding: 20 }}>
    <Pressable onPress={() => setPagina('servico')}>
      <Text style={{ color: '#123B8B', fontSize: 16 }}>
        ← Voltar aos serviços
      </Text>
    </Pressable>

    <Text style={{ fontSize: 25, fontWeight: 'bold', marginTop: 25, color: '#07152E' }}>
      Registo de entregador
    </Text>

    <Text style={{ color: '#65738B', marginTop: 8, marginBottom: 20, lineHeight: 22 }}>
      Preencha os seus dados. O registo ficará pendente até ser aprovado.
    </Text>

    <Text style={{ fontWeight: '600', marginBottom: 6 }}>
      Nome completo
    </Text>
    <TextInput
      value={nomeEntregador}
      onChangeText={setNomeEntregador}
      placeholder="Introduza o seu nome completo"
      style={{
        borderWidth: 1,
        borderColor: '#C9D8ED',
        borderRadius: 10,
        padding: 13,
        marginBottom: 15,
        backgroundColor: '#FFFFFF',
      }}
    />

    <Text style={{ fontWeight: '600', marginBottom: 6 }}>
      Número de telefone
    </Text>
    <TextInput
      value={telefoneEntregador}
      onChangeText={setTelefoneEntregador}
      placeholder="Introduza o seu telefone"
      keyboardType="phone-pad"
      style={{
        borderWidth: 1,
        borderColor: '#C9D8ED',
        borderRadius: 10,
        padding: 13,
        marginBottom: 15,
        backgroundColor: '#FFFFFF',
      }}
    />

    <Text style={{ fontWeight: '600', marginBottom: 6 }}>
      Província
    </Text>
    <TextInput
      value={provinciaEntregador}
      onChangeText={setProvinciaEntregador}
      placeholder="Ex.: Maputo Cidade"
      style={{
        borderWidth: 1,
        borderColor: '#C9D8ED',
        borderRadius: 10,
        padding: 13,
        marginBottom: 18,
        backgroundColor: '#FFFFFF',
      }}
    />

    {mensagemEntregador !== '' && (
      <Text style={{ color: '#B42318', marginBottom: 12 }}>
        {mensagemEntregador}
      </Text>
    )}

    <Pressable
      disabled={aRegistarEntregador}
      onPress={registarEntregador}
      style={{
        backgroundColor: aRegistarEntregador ? '#8AA6CC' : '#1769FF',
        padding: 15,
        borderRadius: 10,
        alignItems: 'center',
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        {aRegistarEntregador ? 'A enviar...' : 'Enviar registo'}
      </Text>
    </Pressable>
  </View>
)}

{pagina === 'entregasEntregador' && (
  <View style={{ marginTop: 20, padding: 20 }}>
    <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#123B70' }}>
      📦 Entregas atribuídas
    </Text>

    <Text style={{ color: '#65738B', marginTop: 10, lineHeight: 22 }}>
      Consulte as entregas atribuídas a si e acompanhe o estado de cada uma.
    </Text>

    {carregandoEntregas && (
      <Text style={{ marginTop: 18, color: '#65738B' }}>
        A carregar entregas...
      </Text>
    )}

    {!!erroEntregas && (
      <Text style={{ color: '#C62828', marginTop: 18 }}>
        {erroEntregas}
      </Text>
    )}

    {!carregandoEntregas &&
      !erroEntregas &&
      entregasDoEntregador.length === 0 && (
        <View style={{
          backgroundColor: '#F0F4FA',
          padding: 16,
          borderRadius: 10,
          marginTop: 18,
        }}>
          <Text style={{ color: '#123B70', fontWeight: 'bold' }}>
            Ainda não tem entregas atribuídas.
          </Text>
          <Text style={{ color: '#65738B', marginTop: 8 }}>
            Quando uma entrega lhe for atribuída, aparecerá aqui.
          </Text>
        </View>
      )}

    {entregasDoEntregador.map((entrega, indice) => (
      <View
        key={entrega.entrega_id || entrega.id || indice}
        style={{
          backgroundColor: '#F0F4FA',
          padding: 16,
          borderRadius: 10,
          marginTop: 14,
        }}
      >
        <Text style={{ fontSize: 17, fontWeight: 'bold', color: '#123B70' }}>
          Entrega {indice + 1}
        </Text>

        <Text style={{ marginTop: 10 }}>
          Recolha: {entrega.endereco_recolha || 'Não indicado'}
        </Text>

        <Text style={{ marginTop: 8 }}>
          Destino: {entrega.endereco_entrega || 'Não indicado'}
        </Text>

        <Text style={{ marginTop: 8 }}>
          Telefone: {entrega.telefone_destinatario || 'Não indicado'}
        </Text>

        <Text style={{ marginTop: 8, fontWeight: '600' }}>
          Estado: {entrega.estado || 'Por confirmar'}
        </Text>

        {entrega.estado === 'Aguardando recolha' && (
          <Pressable
            disabled={Boolean(entregaEmAtualizacaoId)}
            onPress={() => atualizarEstadoEntregaEntregador(entrega.entrega_id || entrega.id, 'Recolhida')}
            style={{ backgroundColor: entregaEmAtualizacaoId ? '#8AA6CC' : '#1769FF', padding: 12, borderRadius: 8, marginTop: 12, alignItems: 'center', opacity: entregaEmAtualizacaoId ? 0.65 : 1 }}
          >
            <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
              {String(entregaEmAtualizacaoId) === String(entrega.entrega_id || entrega.id) ? 'A actualizar...' : 'Confirmar recolha'}
            </Text>
          </Pressable>
        )}

        {entrega.estado === 'Recolhida' && (
          <Pressable
            disabled={Boolean(entregaEmAtualizacaoId)}
            onPress={() => atualizarEstadoEntregaEntregador(entrega.entrega_id || entrega.id, 'Em trânsito')}
            style={{ backgroundColor: entregaEmAtualizacaoId ? '#8AA6CC' : '#1769FF', padding: 12, borderRadius: 8, marginTop: 12, alignItems: 'center', opacity: entregaEmAtualizacaoId ? 0.65 : 1 }}
          >
            <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
              {String(entregaEmAtualizacaoId) === String(entrega.entrega_id || entrega.id) ? 'A actualizar...' : 'Iniciar trânsito'}
            </Text>
          </Pressable>
        )}

        {entrega.estado === 'Em trânsito' && (
          <View style={{ marginTop: 12 }}>
            <Pressable
              disabled={Boolean(entregaEmAtualizacaoId)}
              onPress={() => atualizarEstadoEntregaEntregador(entrega.entrega_id || entrega.id, 'Entregue')}
              style={{ backgroundColor: entregaEmAtualizacaoId ? '#8AA6CC' : '#16803C', padding: 12, borderRadius: 8, marginBottom: 8, alignItems: 'center', opacity: entregaEmAtualizacaoId ? 0.65 : 1 }}
            >
              <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
                {String(entregaEmAtualizacaoId) === String(entrega.entrega_id || entrega.id) ? 'A actualizar...' : 'Confirmar entrega concluída'}
              </Text>
            </Pressable>
            <Pressable
              disabled={Boolean(entregaEmAtualizacaoId)}
              onPress={() => atualizarEstadoEntregaEntregador(entrega.entrega_id || entrega.id, 'Entrega falhada')}
              style={{ backgroundColor: entregaEmAtualizacaoId ? '#8AA6CC' : '#B42318', padding: 12, borderRadius: 8, alignItems: 'center', opacity: entregaEmAtualizacaoId ? 0.65 : 1 }}
            >
              <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
                Registar entrega falhada
              </Text>
            </Pressable>
          </View>
        )}
      </View>
    ))}

    <Pressable
      onPress={carregarEntregasDoEntregador}
      style={{
        backgroundColor: '#1769FF',
        padding: 14,
        borderRadius: 8,
        marginTop: 20,
        alignItems: 'center',
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        🔄 Actualizar entregas
      </Text>
    </Pressable>

    <Pressable
      onPress={() => setPagina('servico')}
      style={{
        backgroundColor: '#65738B',
        padding: 14,
        borderRadius: 8,
        marginTop: 12,
        alignItems: 'center',
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        ← Voltar aos serviços
      </Text>
    </Pressable>
  </View>
)}

{pagina === 'estadoEntregador' && (
  <View style={{ marginTop: 20, padding: 20 }}>
    <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#123B70' }}>
      📋 Estado do meu registo
    </Text>

    <Text style={{ color: '#65738B', marginTop: 10, lineHeight: 22 }}>
      Consulte o estado da sua inscrição como entregador.
    </Text>

    {!!mensagemEntregador && (
      <Text
        style={{
          color: mensagemEntregador.toLowerCase().includes('erro')
            ? '#C62828'
            : '#19703A',
          marginTop: 18,
          fontSize: 16,
        }}
      >
        {mensagemEntregador}
      </Text>
    )}

    {estadoEntregador && (
      <View style={{
        backgroundColor: '#F0F4FA',
        padding: 15,
        borderRadius: 10,
        marginTop: 15,
      }}>
        <Text style={{ fontWeight: 'bold', marginBottom: 8 }}>
          Nome: {estadoEntregador.nome_completo || 'Não indicado'}
        </Text>

        <Text style={{ marginBottom: 8 }}>
          Telefone: {estadoEntregador.telefone || 'Não indicado'}
        </Text>

        <Text>
          Estado: {estadoEntregador.ativo ? 'Aprovado' : 'Pendente de aprovação'}
        </Text>
      </View>
    )}

    <Pressable
      onPress={async () => {
        await carregarEstadoEntregador();
      }}
      style={{
        backgroundColor: '#1769FF',
        padding: 14,
        borderRadius: 8,
        marginTop: 20,
        alignItems: 'center',
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        🔄 Actualizar estado
      </Text>
    </Pressable>

    <Pressable
      onPress={() => setPagina('servico')}
      style={{
        backgroundColor: '#65738B',
        padding: 14,
        borderRadius: 8,
        marginTop: 12,
        alignItems: 'center',
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        ← Voltar aos serviços
      </Text>
    </Pressable>
  </View>
)}
{pagina === 'perfilCandidato' && (
  <View style={{ marginTop: 20, padding: 20 }}>
    <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#123B70' }}>
      Perfil do Candidato
    </Text>

    {carregandoPerfil && (
      <Text style={{ marginTop: 12 }}>A carregar o perfil...</Text>
    )}

    {!!erroPerfil && (
      <Text style={{ color: '#C62828', marginTop: 12 }}>
        {erroPerfil}
      </Text>
    )}

    {!!mensagemPerfil && (
      <Text style={{ color: '#19703A', marginTop: 12 }}>
        {mensagemPerfil}
      </Text>
    )}

    <Text style={{ marginTop: 16, fontWeight: 'bold' }}>Nome completo</Text>
    <TextInput
      value={nomePerfil}
      onChangeText={setNomePerfil}
      editable={editarPerfil && !carregandoPerfil}
      placeholder="Nome completo"
      style={estilos.input}
    />

    <Text style={{ marginTop: 12, fontWeight: 'bold' }}>Telefone</Text>
    <TextInput
      value={telefonePerfil}
      onChangeText={setTelefonePerfil}
      editable={editarPerfil && !carregandoPerfil}
      keyboardType="phone-pad"
      placeholder="Telefone"
      style={estilos.input}
    />

    <Text style={{ marginTop: 12, fontWeight: 'bold' }}>Email</Text>
    <TextInput
      value={emailPerfil}
      onChangeText={setEmailPerfil}
      editable={editarPerfil && !carregandoPerfil}
      keyboardType="email-address"
      autoCapitalize="none"
      placeholder="Email"
      style={estilos.input}
    />

    <Text style={{ marginTop: 12, fontWeight: 'bold' }}>Província</Text>
    <TextInput
      value={provinciaPerfil}
      onChangeText={setProvinciaPerfil}
      editable={editarPerfil && !carregandoPerfil}
      placeholder="Província"
      style={estilos.input}
    />

    <Text style={{ marginTop: 12, fontWeight: 'bold' }}>Área profissional</Text>
    <TextInput
      value={areaPerfil}
      onChangeText={setAreaPerfil}
      editable={editarPerfil && !carregandoPerfil}
      placeholder="Área profissional"
      style={estilos.input}
    />

    <Text style={{ marginTop: 12, fontWeight: 'bold' }}>Experiência profissional</Text>
    <TextInput
      value={experienciaPerfil}
      onChangeText={setExperienciaPerfil}
      editable={editarPerfil && !carregandoPerfil}
      multiline
      placeholder="Descreva a sua experiência"
      style={[estilos.input, { minHeight: 100, textAlignVertical: 'top' }]}
    />

    <Pressable
      disabled={carregandoPerfil}
      onPress={() => {
        if (editarPerfil) {
          guardarPerfilCandidato();
        } else {
          setEditarPerfil(true);
          setMensagemPerfil('');
          setErroPerfil('');
        }
      }}
      style={{
        backgroundColor: '#123B70',
        padding: 14,
        borderRadius: 8,
        marginTop: 20,
        alignItems: 'center',
        opacity: carregandoPerfil ? 0.6 : 1,
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        {carregandoPerfil
          ? 'Aguarde...'
          : editarPerfil
            ? 'Guardar alterações'
            : 'Editar perfil'}
      </Text>
    </Pressable>

    <Pressable
      onPress={() => {
        setEditarPerfil(false);
        setPagina('servico');
      }}
      style={{
        backgroundColor: '#65738B',
        padding: 14,
        borderRadius: 8,
        marginTop: 12,
        alignItems: 'center',
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        Voltar
      </Text>
    </Pressable>
  </View>
)}

{pagina === 'minhasCandidaturas' && (
  <View style={{ marginTop: 20, padding: 20 }}>
    <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#123B70' }}>
      Minhas Candidaturas
    </Text>

    <Pressable
      onPress={carregarCandidaturasCandidato}
      disabled={carregandoCandidaturasCandidato}
      style={{
        backgroundColor: '#123B70',
        padding: 14,
        borderRadius: 8,
        marginTop: 16,
        alignItems: 'center',
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        {carregandoCandidaturasCandidato
          ? 'A carregar...'
          : 'Consultar minhas candidaturas'}
      </Text>
    </Pressable>

    {!!erroCandidaturasCandidato && (
      <Text style={{ color: '#C62828', marginTop: 12 }}>
        {erroCandidaturasCandidato}
      </Text>
    )}

    {!carregandoCandidaturasCandidato &&
      !erroCandidaturasCandidato &&
      candidaturasCandidato.length === 0 && (
        <Text style={{ color: '#65738B', marginTop: 16 }}>
          Clique no botão para consultar as suas candidaturas.
        </Text>
      )}

    {candidaturasCandidato.map((item) => (
      <View
        key={item.id}
        style={{
          backgroundColor: '#FFFFFF',
          padding: 15,
          borderRadius: 10,
          marginTop: 14,
          borderWidth: 1,
          borderColor: '#D6E2F0',
        }}
      >
       <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#123B70' }}>
  {item.vaga || 'Vaga sem título'}
</Text>

{!!item.nome_completo && (
  <Text style={{ marginTop: 6, color: '#172B4D' }}>
    Candidato: {item.nome_completo}
  </Text>
)}

<View
  style={{
    marginTop: 10,
    padding: 10,
    borderRadius: 8,
    backgroundColor:
      item.status === 'Pré-selecionado'
        ? '#E2F5E9'
        : item.status === 'Aprovado'
        ? '#DCEBFF'
        : item.status === 'Rejeitado'
        ? '#FCE4E4'
        : '#FFF3D6',
  }}
>
  <Text
    style={{
      fontWeight: 'bold',
      color:
        item.status === 'Pré-selecionado'
          ? '#19703A'
          : item.status === 'Aprovado'
          ? '#174EA6'
          : item.status === 'Rejeitado'
          ? '#B71C1C'
          : '#805600',
    }}
  >
    Estado: {item.status || 'Em análise'}
  </Text>
</View>

        <Text style={{ marginTop: 6, color: '#65738B' }}>
          Data: {item.created_at
            ? new Date(item.created_at).toLocaleDateString()
            : 'Não disponível'}
        </Text>

        {!!item.mensagem && (
          <Text style={{ marginTop: 8, color: '#172B4D' }}>
            Mensagem: {item.mensagem}
          </Text>
        )}
      </View>
    ))}

    <Pressable
      onPress={() => setPagina('servico')}
      style={{
        backgroundColor: '#65738B',
        padding: 14,
        borderRadius: 8,
        marginTop: 20,
        alignItems: 'center',
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        Voltar às vagas
      </Text>
    </Pressable>
  </View>
)}

{pagina === 'minhasEncomendas' && (
  <View style={{ marginTop: 20, padding: 20 }}>
    <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#123B70' }}>
      🧾 Minhas encomendas
    </Text>

    <Pressable
      onPress={carregarEncomendasCandidato}
      disabled={carregandoEncomendas}
      style={{
        backgroundColor: '#123B70',
        padding: 14,
        borderRadius: 8,
        marginTop: 16,
        alignItems: 'center',
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        {carregandoEncomendas
          ? 'A carregar...'
          : 'Consultar minhas encomendas'}
      </Text>
    </Pressable>

    {!!erroEncomendas && (
      <Text style={{ color: '#C62828', marginTop: 12 }}>
        {erroEncomendas}
      </Text>
    )}

    {!carregandoEncomendas &&
      !erroEncomendas &&
      encomendasCandidato.length === 0 && (
        <Text style={{ color: '#65738B', marginTop: 16 }}>
          Clique no botão para consultar as suas encomendas.
        </Text>
      )}

    {encomendasCandidato.map((item) => (
      <View
        key={item.id}
        style={{
          backgroundColor: '#FFFFFF',
          padding: 15,
          borderRadius: 10,
          marginTop: 14,
          borderWidth: 1,
          borderColor: '#D6E2F0',
        }}
      >
        <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#123B70' }}>
          Encomenda: {item.id}
        </Text>

        {item.itens && item.itens.length > 0 && (
          <View style={{ marginTop: 12 }}>
            {item.itens.map((artigo, indice) => (
              <View
                key={`${item.id}-${artigo.produto_id || indice}`}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginBottom: 12,
                  padding: 8,
                  backgroundColor: '#F4F8FC',
                  borderRadius: 8,
                }}
              >
                {artigo.imagem_url ? (
                  <Image
                    source={{ uri: artigo.imagem_url }}
                    style={{
                      width: 70,
                      height: 70,
                      borderRadius: 8,
                      marginRight: 12,
                    }}
                    resizeMode="cover"
                  />
                ) : (
                  <View
                    style={{
                      width: 70,
                      height: 70,
                      borderRadius: 8,
                      marginRight: 12,
                      backgroundColor: '#D6E2F0',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    <Text style={{ fontSize: 11, color: '#65738B' }}>
                      Sem imagem
                    </Text>
                  </View>
                )}

                <View style={{ flex: 1 }}>
                  <Text style={{ fontWeight: 'bold', color: '#123B70' }}>
                    {artigo.nome_produto || 'Produto'}
                  </Text>
                  <Text style={{ marginTop: 4, color: '#172B4D' }}>
                    Quantidade: {artigo.quantidade}
                  </Text>
                  <Text style={{ marginTop: 4, color: '#172B4D' }}>
                    Preço: {Number(artigo.preco_unitario || 0).toLocaleString('pt-PT')} MT
                  </Text>
                </View>
              </View>
            ))}
          </View>
        )}

        <Text style={{ marginTop: 8, color: '#172B4D' }}>
          Valor: {Number(item.total || 0).toLocaleString('pt-PT')} MT
        </Text>

        <Text style={{ marginTop: 6, color: '#172B4D' }}>
          Estado: {item.estado || 'Pendente'}
        </Text>

        <Text style={{ marginTop: 6, color: '#65738B' }}>
          Data: {item.created_at
            ? new Date(item.created_at).toLocaleDateString('pt-PT')
            : 'Não disponível'}
        </Text>
      </View>
    ))}

    <Pressable
      onPress={() => setPagina('servico')}
      style={{
        backgroundColor: '#65738B',
        padding: 14,
        borderRadius: 8,
        marginTop: 20,
        alignItems: 'center',
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        Voltar à loja
      </Text>
    </Pressable>
  </View>
)}

{pagina === 'painelVendedor' && (
  <View style={{ marginTop: 20, padding: 20 }}>
    <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#123B70' }}>
      🏪 Painel do Vendedor
    </Text>

    <Text style={{ color: '#65738B', marginTop: 10, marginBottom: 20 }}>
      Bem-vindo à área de gestão da sua empresa na RNO. Aqui pode gerir vagas de emprego, candidaturas, produtos e encomendas.
    </Text>

    <View style={estilos.cartao}>
      <Text style={estilos.tituloCartao}>💼 Publicar uma vaga de emprego</Text>
      <Text style={estilos.descricaoCartao}>
        A vaga será associada à sua empresa autenticada e guardada na tabela vagas existente. Não são criadas tabelas novas.
      </Text>

      <TextInput style={estilos.input} placeholder="Título da vaga *" value={tituloNovaVaga} onChangeText={setTituloNovaVaga} maxLength={120} />
      <TextInput style={estilos.input} placeholder="Localização / província *" value={localizacaoNovaVaga} onChangeText={setLocalizacaoNovaVaga} maxLength={100} />
      <TextInput style={estilos.input} placeholder="Tipo de emprego (ex.: Tempo inteiro) *" value={tipoNovaVaga} onChangeText={setTipoNovaVaga} maxLength={80} />
      <TextInput style={[estilos.input, { minHeight: 100, textAlignVertical: 'top' }]} placeholder="Descrição da vaga *" value={descricaoNovaVaga} onChangeText={setDescricaoNovaVaga} multiline maxLength={5000} />
      <TextInput style={[estilos.input, { minHeight: 80, textAlignVertical: 'top' }]} placeholder="Requisitos (opcional)" value={requisitosNovaVaga} onChangeText={setRequisitosNovaVaga} multiline maxLength={3000} />
      <TextInput style={estilos.input} placeholder="Salário (opcional; ex.: 15.000 MT)" value={salarioNovaVaga} onChangeText={setSalarioNovaVaga} maxLength={100} />
      <TextInput style={estilos.input} placeholder="Contacto da vaga (opcional se houver telefone no perfil)" value={contactoNovaVaga} onChangeText={setContactoNovaVaga} keyboardType="phone-pad" maxLength={40} />

      <Pressable
        onPress={publicarVagaEmpresa}
        disabled={aPublicarVaga}
        style={{ backgroundColor: aPublicarVaga ? '#8AA0B8' : '#1769FF', padding: 14, borderRadius: 10, marginTop: 4, alignItems: 'center', opacity: aPublicarVaga ? 0.7 : 1 }}
      >
        <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
          {aPublicarVaga ? 'A publicar vaga...' : 'Publicar vaga'}
        </Text>
      </Pressable>

      {!!mensagemPublicarVaga && (
        <Text style={{ color: /sucesso|enviada/i.test(mensagemPublicarVaga) ? '#18794E' : '#B42318', marginTop: 12, lineHeight: 21 }}>
          {mensagemPublicarVaga}
        </Text>
      )}
    </View>

    <View style={estilos.cartao}>
      <Text style={estilos.tituloCartao}>📋 As minhas vagas</Text>
      <Pressable
        onPress={carregarVagasEmpresa}
        disabled={carregandoVagasEmpresa}
        style={{ backgroundColor: '#123B70', padding: 12, borderRadius: 8, marginTop: 10, alignItems: 'center', opacity: carregandoVagasEmpresa ? 0.6 : 1 }}
      >
        <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
          {carregandoVagasEmpresa ? 'A carregar vagas...' : 'Consultar as minhas vagas'}
        </Text>
      </Pressable>

      {!!erroVagasEmpresa && <Text style={{ color: '#B42318', marginTop: 10 }}>{erroVagasEmpresa}</Text>}
      {vagasEmpresa.length === 0 && !carregandoVagasEmpresa && !erroVagasEmpresa && (
        <Text style={estilos.descricaoCartao}>
          {vagasEmpresaCarregada ? 'Esta empresa ainda não tem vagas publicadas.' : 'Carregue a lista para consultar as vagas associadas à sua empresa.'}
        </Text>
      )}
      {vagasEmpresa.map((vaga) => (
        <View key={vaga.id} style={{ borderTopWidth: 1, borderTopColor: '#E2E8F0', paddingTop: 12, marginTop: 12 }}>
          <Text style={{ color: '#123B70', fontWeight: 'bold', fontSize: 16 }}>{vaga.titulo}</Text>
          <Text style={estilos.descricaoCartao}>Localização: {vaga.localizacao || 'Não indicada'}</Text>
          <Text style={estilos.descricaoCartao}>Tipo: {vaga.tipo || 'Não indicado'}</Text>
          {!!vaga.salario && <Text style={estilos.descricaoCartao}>Salário: {vaga.salario}</Text>}
          {!!vaga.descricao && <Text style={[estilos.descricaoCartao, { marginTop: 6 }]}>{vaga.descricao}</Text>}
        </View>
      ))}
    </View>

    <View style={estilos.cartao}>
      <Text style={estilos.tituloCartao}>📨 Candidaturas recebidas</Text>
      <Text style={estilos.descricaoCartao}>Consulte os candidatos às vagas da sua empresa e atualize o estado das candidaturas.</Text>
      <Pressable
        onPress={() => {
          setPagina('empresa');
          carregarCandidaturasEmpresa();
        }}
        style={{ backgroundColor: '#123B70', padding: 14, borderRadius: 8, marginTop: 10, alignItems: 'center' }}
      >
        <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>Gerir candidaturas recebidas</Text>
      </Pressable>
    </View>

    
<View style={estilos.cartao}>
  <Text style={estilos.tituloCartao}>
    ➕ Adicionar produto
  </Text>

  <TextInput
    style={estilos.input}
    placeholder="Nome do produto *"
    value={nomeNovoProduto}
    onChangeText={setNomeNovoProduto}
  />

  <TextInput
    style={estilos.input}
    placeholder="Descrição do produto"
    value={descricaoNovoProduto}
    onChangeText={setDescricaoNovoProduto}
    multiline
  />

  <TextInput
    style={estilos.input}
    placeholder="Preço em MT *"
    value={precoNovoProduto}
    onChangeText={setPrecoNovoProduto}
    keyboardType="decimal-pad"
  />

  <TextInput
    style={estilos.input}
    placeholder="Quantidade em stock *"
    value={stockNovoProduto}
    onChangeText={setStockNovoProduto}
    keyboardType="number-pad"
  />

  <TextInput
    style={estilos.input}
    placeholder="Categoria (ex.: roupa)"
    value={categoriaNovoProduto}
    onChangeText={setCategoriaNovoProduto}
  />

  <TextInput
    style={estilos.input}
    placeholder="URL da imagem (opcional)"
    value={imagemNovoProduto}
    onChangeText={setImagemNovoProduto}
    autoCapitalize="none"
  />

  <Pressable
    onPress={escolherFotografiaProduto}
    style={{
      backgroundColor: '#1769FF',
      padding: 14,
      borderRadius: 8,
      marginTop: 4,
      alignItems: 'center',
    }}
  >
    <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
      📷 Escolher fotografia
    </Text>
  </Pressable>

  {fotografiaProduto && (
    <View style={{ marginTop: 12, alignItems: 'center' }}>
      <Image
        source={{ uri: fotografiaProduto.uri }}
        style={{
          width: 160,
          height: 160,
          borderRadius: 12,
        }}
        resizeMode="cover"
      />
      <Text style={{ marginTop: 6, color: '#123B70' }}>
        Fotografia selecionada
      </Text>
    </View>
  )}

  <Pressable
    onPress={adicionarProduto}
    disabled={aGuardarProduto}
    style={{
      backgroundColor: aGuardarProduto ? '#7890AA' : '#123B70',
      padding: 14,
      borderRadius: 8,
      marginTop: 12,
      alignItems: 'center',
    }}
  >
    <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
      {aGuardarProduto ? 'A guardar produto...' : 'Guardar produto'}
    </Text>
  </Pressable>

  {mensagemNovoProduto !== '' && (
    <Text style={{ marginTop: 12, color: '#123B70' }}>
      {mensagemNovoProduto}
    </Text>
  )}
</View>
    <View style={estilos.cartao}>
      <Text style={estilos.tituloCartao}>
        📦 Meus Produtos
      </Text>

      {carregandoProdutosVendedor ? (
        <Text style={estilos.descricaoCartao}>
          A carregar os teus produtos...
        </Text>
      ) : erroProdutosVendedor ? (
        <Text style={{ color: '#B42318', marginTop: 10 }}>
          {erroProdutosVendedor}
        </Text>
      ) : produtosVendedor.length === 0 ? (
        <Text style={estilos.descricaoCartao}>
          Ainda não tens produtos registados.
        </Text>
      ) : (
        produtosVendedor.map((produto) => (
          <View
            key={produto.id}
            style={{
              paddingVertical: 14,
              borderBottomWidth: 1,
              borderBottomColor: '#E2E8F0',
            }}
          >
            <Text style={{ fontSize: 17, fontWeight: 'bold', color: '#123B70' }}>
              {produto.nome}
            </Text>

            {produto.imagem_url ? (
              <Image
                source={{ uri: produto.imagem_url }}
                style={{
                  width: '100%',
                  height: 180,
                  borderRadius: 10,
                  marginTop: 10,
                  marginBottom: 10,
                  backgroundColor: '#EAF1FA',
                }}
                resizeMode="cover"
              />
            ) : (
              <View
                style={{
                  width: '100%',
                  height: 100,
                  borderRadius: 10,
                  marginTop: 10,
                  marginBottom: 10,
                  backgroundColor: '#EAF1FA',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Text style={{ color: '#65738B' }}>
                  Fotografia não disponível
                </Text>
              </View>
            )}

            <Text style={{ marginTop: 5, color: '#65738B' }}>
              Preço: {Number(produto.preco).toLocaleString('pt-MZ')} MT
            </Text>

            <Text style={{ marginTop: 4, color: '#65738B' }}>
              Stock: {produto.stock}
            </Text>

            <Text
              style={{
                marginTop: 6,
                color: produto.publicado ? '#15803D' : '#B45309',
                fontWeight: 'bold',
              }}
            >
              {produto.publicado ? 'Publicado' : 'Não publicado'}
            </Text>

            {produto.descricao ? (
              <Text style={{ marginTop: 5, color: '#65738B' }}>
                {produto.descricao}
              </Text>
            ) : null}

{!produto.publicado ? (
  <Pressable
    onPress={() => publicarProduto(produto)}
    style={{
      backgroundColor: '#15803D',
      padding: 12,
      borderRadius: 8,
      marginTop: 12,
      alignItems: 'center',
    }}
  >
    <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
      Publicar produto
    </Text>
  </Pressable>
) : null}

          </View>
        ))
      )}
    </View>
   
<View style={estilos.cartao}>
  <Text style={estilos.tituloCartao}>
    🧾 Encomendas recebidas
  </Text>

  {carregandoEncomendasVendedor ? (
    <Text style={estilos.descricaoCartao}>
      A carregar encomendas...
    </Text>
  ) : erroEncomendasVendedor ? (
    <Text style={{ color: '#D93025', marginTop: 10 }}>
      {erroEncomendasVendedor}
    </Text>
  ) : encomendasVendedor.length === 0 ? (
    <Text style={estilos.descricaoCartao}>
      Ainda não existem encomendas para os seus produtos.
    </Text>
  ) : (
    encomendasVendedor.map((encomenda, indice) => (
      <View
        key={`${encomenda.encomenda_id}-${encomenda.produto_id}-${indice}`}
        style={{
          borderTopWidth: 1,
          borderTopColor: '#E2E8F0',
          paddingTop: 12,
          marginTop: 12,
        }}
      >
        <Text style={{ fontWeight: 'bold', color: '#123B70' }}>
          Encomenda: {encomenda.encomenda_id}
        </Text>

        <Text style={estilos.descricaoCartao}>
          Produto: {encomenda.nome_produto}
        </Text>

        <Text style={estilos.descricaoCartao}>
          Quantidade: {encomenda.quantidade}
        </Text>

        <Text style={estilos.descricaoCartao}>
          Preço unitário: {encomenda.preco_unitario} MT
        </Text>

        <Text style={estilos.descricaoCartao}>
          Subtotal: {encomenda.subtotal} MT
        </Text>

        
<Text style={estilos.descricaoCartao}>
  Estado atual: {encomenda.estado}
</Text>

<Text
  style={{
    fontWeight: 'bold',
    color: '#123B70',
    marginTop: 12,
    marginBottom: 8,
  }}
>
  Atualizar estado:
</Text>

{[
  'Pendente',
  'Em preparação',
  'Enviada',
  'Entregue',
  'Cancelada',
].map((estado) => (
  <Pressable
    key={estado}
    onPress={() =>
      atualizarEstadoEncomenda(
        encomenda.encomenda_id,
        estado
      )
    }
    style={{
      backgroundColor:
        encomenda.estado === estado
          ? '#123B70'
          : '#E8EEF7',
      padding: 10,
      borderRadius: 8,
      marginTop: 6,
      alignItems: 'center',
    }}
  >
    <Text
      style={{
        color:
          encomenda.estado === estado
            ? '#FFFFFF'
            : '#123B70',
        fontWeight: 'bold',
      }}
    >
      {estado === encomenda.estado ? '✓ ' : ''}
      {estado}
    </Text>
  </Pressable>
))}


        <Text style={estilos.descricaoCartao}>
          Telefone do cliente: {encomenda.telefone || 'Não informado'}
        </Text>

        <Text style={estilos.descricaoCartao}>
          Endereço de entrega: {encomenda.endereco_entrega || 'Não informado'}
        </Text>
<Text style={{ fontWeight: 'bold', color: '#123B70', marginTop: 14 }}>
  Solicitar entrega
</Text>
<Text style={estilos.descricaoCartao}>
  Endereço de recolha:
</Text>

<TextInput
  value={obterRascunhoEntrega(encomenda.encomenda_id).enderecoRecolha}
  onChangeText={(texto) =>
    atualizarRascunhoEntrega(encomenda.encomenda_id, 'enderecoRecolha', texto)
  }
  placeholder="Ex.: endereço da loja"
  style={estilos.input}
/>

<Text style={estilos.descricaoCartao}>
  Custo da entrega (MT):
</Text>

<TextInput
  value={obterRascunhoEntrega(encomenda.encomenda_id).custo}
  onChangeText={(texto) =>
    atualizarRascunhoEntrega(encomenda.encomenda_id, 'custo', texto)
  }
  placeholder="0"
  keyboardType="decimal-pad"
  style={estilos.input}
/>

<Text style={estilos.descricaoCartao}>
  Observações:
</Text>

<TextInput
  value={obterRascunhoEntrega(encomenda.encomenda_id).observacoes}
  onChangeText={(texto) =>
    atualizarRascunhoEntrega(encomenda.encomenda_id, 'observacoes', texto)
  }
  placeholder="Observações opcionais"
  style={estilos.input}
/>

<Pressable
  disabled={carregandoEntregas}
  onPress={() => {
    const rascunho = obterRascunhoEntrega(encomenda.encomenda_id);
    solicitarEntrega(
      encomenda.encomenda_id,
      rascunho.enderecoRecolha,
      encomenda.endereco_entrega || '',
      encomenda.telefone || '',
      rascunho.custo,
      rascunho.observacoes
    );
  }}
  style={{
    backgroundColor: carregandoEntregas ? '#8AA0B8' : '#123B70',
    padding: 12,
    borderRadius: 8,
    marginTop: 10,
    alignItems: 'center',
    opacity: carregandoEntregas ? 0.65 : 1,
  }}
>
  <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
    {carregandoEntregas ? 'A solicitar entrega...' : 'Solicitar entrega'}
  </Text>
</Pressable>
        {encomenda.observacoes ? (
          <Text style={estilos.descricaoCartao}>
            Observações: {encomenda.observacoes}
          </Text>
        ) : null}
      </View>
    ))
  )}
</View>

<View style={estilos.cartao}>
  <Text style={estilos.tituloCartao}>🚚 Entregas da empresa</Text>
  <Text style={estilos.descricaoCartao}>
    Consulte os pedidos de entrega registados para as encomendas da sua empresa.
  </Text>

  <Pressable
    onPress={carregarEntregasEmpresa}
    disabled={carregandoEntregas}
    style={{
      backgroundColor: carregandoEntregas ? '#8AA0B8' : '#123B70',
      padding: 12,
      borderRadius: 8,
      marginTop: 10,
      alignItems: 'center',
      opacity: carregandoEntregas ? 0.65 : 1,
    }}
  >
    <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
      {carregandoEntregas ? 'A carregar entregas...' : 'Atualizar entregas da empresa'}
    </Text>
  </Pressable>

  {!!erroEntregas && (
    <Text style={{ color: '#B42318', marginTop: 12, lineHeight: 20 }}>
      {erroEntregas}
    </Text>
  )}

  {!carregandoEntregas && !erroEntregas && entregasEmpresa.length === 0 && (
    <Text style={[estilos.descricaoCartao, { marginTop: 12 }]}>
      Ainda não existem entregas para apresentar, ou a lista ainda não foi carregada.
    </Text>
  )}

  {entregasEmpresa.map((entrega, indice) => (
    <View
      key={entrega.id || entrega.entrega_id || `${entrega.encomenda_id || 'entrega'}-${indice}`}
      style={{ borderTopWidth: 1, borderTopColor: '#E2E8F0', paddingTop: 12, marginTop: 12 }}
    >
      <Text style={{ color: '#123B70', fontWeight: 'bold' }}>
        Entrega: {entrega.numero || entrega.id || entrega.entrega_id || indice + 1}
      </Text>
      {!!entrega.encomenda_id && (
        <Text style={estilos.descricaoCartao}>Encomenda: {entrega.encomenda_id}</Text>
      )}
      <Text style={estilos.descricaoCartao}>
        Estado: {entrega.estado || entrega.status || 'Não informado'}
      </Text>
      {!!entrega.endereco_recolha && (
        <Text style={estilos.descricaoCartao}>Recolha: {entrega.endereco_recolha}</Text>
      )}
      {!!entrega.endereco_entrega && (
        <Text style={estilos.descricaoCartao}>Destino: {entrega.endereco_entrega}</Text>
      )}
      {!!entrega.telefone_destinatario && (
        <Text style={estilos.descricaoCartao}>Contacto: {entrega.telefone_destinatario}</Text>
      )}
      {entrega.custo_entrega !== undefined && entrega.custo_entrega !== null && (
        <Text style={estilos.descricaoCartao}>
          Custo: {Number(entrega.custo_entrega).toLocaleString('pt-MZ')} MT
        </Text>
      )}

      {!!entrega.entregador_id && (
        <View style={{ backgroundColor: '#E8F5E9', borderRadius: 8, padding: 12, marginTop: 8 }}>
          <Text style={{ color: '#17633A', fontWeight: 'bold' }}>
            Entregador atribuído: {entrega.entregador_nome || entrega.entregador_id}
          </Text>
          {!!entrega.atribuido_em && (
            <Text style={{ color: '#17633A', marginTop: 4, fontSize: 12 }}>
              Atribuído em: {new Date(entrega.atribuido_em).toLocaleString('pt-MZ')}
            </Text>
          )}
        </View>
      )}

      {entrega.estado === 'Aguardando atribuição' && (
        <View style={{ marginTop: 12 }}>
          <Text style={[estilos.descricaoCartao, { fontWeight: '600', marginBottom: 8 }]}>
            Escolha uma acção para esta entrega:
          </Text>
          <Pressable
            disabled={Boolean(entregaEmAtualizacaoId)}
            onPress={() => atualizarEstadoEntregaEmpresa(entrega.entrega_id || entrega.id, 'Aguardando recolha')}
            style={{ backgroundColor: entregaEmAtualizacaoId ? '#8AA6CC' : '#1769FF', padding: 12, borderRadius: 8, marginBottom: 8, alignItems: 'center', opacity: entregaEmAtualizacaoId ? 0.65 : 1 }}
          >
            <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
              {String(entregaEmAtualizacaoId) === String(entrega.entrega_id || entrega.id) ? 'A actualizar...' : 'Autorizar recolha'}
            </Text>
          </Pressable>
          <Pressable
            disabled={Boolean(entregaEmAtualizacaoId)}
            onPress={() => atualizarEstadoEntregaEmpresa(entrega.entrega_id || entrega.id, 'Cancelada')}
            style={{ backgroundColor: entregaEmAtualizacaoId ? '#8AA6CC' : '#B42318', padding: 12, borderRadius: 8, alignItems: 'center', opacity: entregaEmAtualizacaoId ? 0.65 : 1 }}
          >
            <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
              Cancelar entrega
            </Text>
          </Pressable>
        </View>
      )}

      {entrega.estado === 'Aguardando recolha' && (
        <View style={{ marginTop: 12 }}>
          {entrega.entregador_id ? (
            <View style={{ backgroundColor: '#F5F8FC', borderRadius: 8, padding: 12 }}>
              <Text style={{ color: '#123B70', fontSize: 13 }}>
                A entrega já tem um entregador atribuído. Aguarde a atualização do estado pelo entregador.
              </Text>
            </View>
          ) : (
            <>
              <Pressable
                disabled={carregandoEntregadoresAtivos || Boolean(entregaEmAtribuicaoId)}
                onPress={async () => {
                  const idAtual = String(entrega.entrega_id || entrega.id);
                  if (String(entregaEntregadoresAbertaId) === idAtual) {
                    setEntregaEntregadoresAbertaId(null);
                    setEntregadoresAtivos([]);
                    setErroEntregadoresAtivos('');
                    return;
                  }
                  setEntregaEntregadoresAbertaId(idAtual);
                  await carregarEntregadoresAtivos();
                }}
                style={{ backgroundColor: '#1769FF', padding: 12, borderRadius: 8, alignItems: 'center', opacity: (carregandoEntregadoresAtivos || entregaEmAtribuicaoId) ? 0.65 : 1 }}
              >
                <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
                  {carregandoEntregadoresAtivos && String(entregaEntregadoresAbertaId) === String(entrega.entrega_id || entrega.id)
                    ? 'A carregar entregadores...'
                    : String(entregaEntregadoresAbertaId) === String(entrega.entrega_id || entrega.id)
                      ? 'Ocultar entregadores ativos'
                      : 'Escolher entregador ativo'}
                </Text>
              </Pressable>

              {String(entregaEntregadoresAbertaId) === String(entrega.entrega_id || entrega.id) && (
                <View style={{ marginTop: 10, padding: 10, backgroundColor: '#F5F8FC', borderRadius: 10 }}>
                  {!!erroEntregadoresAtivos && (
                    <Text style={{ color: '#B42318', marginBottom: 8 }}>{erroEntregadoresAtivos}</Text>
                  )}
                  {carregandoEntregadoresAtivos ? (
                    <Text style={estilos.descricaoCartao}>A consultar entregadores ativos...</Text>
                  ) : entregadoresAtivos.length === 0 && !erroEntregadoresAtivos ? (
                    <Text style={estilos.descricaoCartao}>Não existem entregadores ativos disponíveis neste momento.</Text>
                  ) : entregadoresAtivos.map((entregador) => {
                    const chaveAtribuicao = `${entrega.entrega_id || entrega.id}:${entregador.id}`;
                    return (
                      <View key={entregador.id} style={{ borderTopWidth: 1, borderTopColor: '#D8E2F0', paddingTop: 10, marginTop: 10 }}>
                        <Text style={{ color: '#123B70', fontWeight: 'bold' }}>{entregador.nome_completo || 'Entregador'}</Text>
                        {!!entregador.provincia && <Text style={estilos.descricaoCartao}>Província: {entregador.provincia}</Text>}
                        {!!entregador.telefone && <Text style={estilos.descricaoCartao}>Telefone: {entregador.telefone}</Text>}
                        <Pressable
                          disabled={Boolean(entregaEmAtribuicaoId)}
                          onPress={() => atribuirEntregadorEntrega(entrega.entrega_id || entrega.id, entregador.id, entregador.nome_completo)}
                          style={{ backgroundColor: entregaEmAtribuicaoId === chaveAtribuicao ? '#8AA0B8' : '#16804A', padding: 10, borderRadius: 8, marginTop: 8, alignItems: 'center', opacity: entregaEmAtribuicaoId ? 0.65 : 1 }}
                        >
                          <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
                            {entregaEmAtribuicaoId === chaveAtribuicao ? 'A atribuir...' : 'Atribuir esta entrega'}
                          </Text>
                        </Pressable>
                      </View>
                    );
                  })}
                </View>
              )}
            </>
          )}
        </View>
      )}
    </View>
  ))}

  <Text style={{ color: '#65738B', fontSize: 12, marginTop: 12, lineHeight: 18 }}>
    Fluxo da entrega: a empresa autoriza a recolha enquanto está em “Aguardando atribuição”; depois, quando passa para “Aguardando recolha”, pode atribuir um entregador ativo. A partir da atribuição, o entregador atualiza os estados seguintes conforme as regras do Supabase.
  </Text>
</View>

<Pressable
  onPress={() => setPagina('empresa')}
  style={{
    backgroundColor: '#123B70',
    padding: 14,
    borderRadius: 8,
    marginTop: 16,
    alignItems: 'center',
  }}
>
  <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
    Entrar como empresa
  </Text>
</Pressable>
    <Pressable
      onPress={() => setPagina('servico')}
      style={{
        backgroundColor: '#65738B',
        padding: 14,
        borderRadius: 8,
        marginTop: 20,
        alignItems: 'center',
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        Voltar à loja
      </Text>
    </Pressable>
  </View>
)}

{pagina === 'candidatura' && (
  <View style={{ marginTop: 20 }}>
    {(!sessaoCandidato?.access_token || !sessaoCandidato?.user?.id || !vagaSelecionada?.id) ? (
      <>
        <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#123B70' }}>
          Não é possível abrir esta candidatura
        </Text>
        <Text style={{ marginTop: 10, color: '#65738B', lineHeight: 22 }}>
          Inicie sessão como candidato e selecione uma vaga publicada antes de continuar.
        </Text>
        <Pressable
          onPress={() => {
            setMensagemLogin('Inicie sessão como candidato para se candidatar a uma vaga.');
            setPagina('login');
          }}
          style={{ backgroundColor: '#123B70', padding: 14, borderRadius: 8, marginTop: 16, alignItems: 'center' }}
        >
          <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>Iniciar sessão</Text>
        </Pressable>
      </>
    ) : (
      <>
    <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#123B70' }}>
      Enviar candidatura
    </Text>

    <Text style={{ color: '#65738B', marginTop: 10 }}>
      Vaga: {vagaSelecionada?.titulo || 'Vaga não identificada'}
    </Text>

    <Text style={{ color: '#65738B', marginTop: 8 }}>
      Preencha os seus dados para se candidatar a esta vaga.
    </Text>

    {estadoEnvioCandidatura !== '' && (
      <Text
        style={{
          color: estadoEnvioCandidatura.includes('sucesso')
            ? '#16804A'
            : '#C62828',
          marginTop: 12,
          fontWeight: 'bold',
        }}
      >
        {estadoEnvioCandidatura}
      </Text>
    )}

    <TextInput
      placeholder="Nome completo"
      value={nomeCandidato}
      onChangeText={setNomeCandidato}
      style={{
        backgroundColor: '#FFFFFF',
        borderWidth: 1,
        borderColor: '#D6E2F0',
        borderRadius: 8,
        padding: 12,
        marginTop: 16,
      }}
    />

    <TextInput
      placeholder="Telefone"
      value={telefoneCandidato}
      onChangeText={setTelefoneCandidato}
      keyboardType="phone-pad"
      style={{
        backgroundColor: '#FFFFFF',
        borderWidth: 1,
        borderColor: '#D6E2F0',
        borderRadius: 8,
        padding: 12,
        marginTop: 12,
      }}
    />

    <TextInput
      placeholder="Email"
      value={emailCandidato}
      onChangeText={setEmailCandidato}
      keyboardType="email-address"
      autoCapitalize="none"
      style={{
        backgroundColor: '#FFFFFF',
        borderWidth: 1,
        borderColor: '#D6E2F0',
        borderRadius: 8,
        padding: 12,
        marginTop: 12,
      }}
    />

    <TextInput
      placeholder="Mensagem de apresentação"
      value={mensagemCandidatura}
      onChangeText={setMensagemCandidatura}
      multiline
      numberOfLines={4}
      style={{
        backgroundColor: '#FFFFFF',
        borderWidth: 1,
        borderColor: '#D6E2F0',
        borderRadius: 8,
        padding: 12,
        marginTop: 12,
        minHeight: 100,
        textAlignVertical: 'top',
      }}
    />

    <Pressable
      onPress={enviarCandidatura}
      disabled={enviandoCandidatura}
      style={{
        backgroundColor: enviandoCandidatura ? '#8AA0B8' : '#16804A',
        padding: 14,
        borderRadius: 8,
        marginTop: 16,
        alignItems: 'center',
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        {enviandoCandidatura ? 'A enviar...' : 'Enviar candidatura'}
      </Text>
    </Pressable>

    <Pressable
      onPress={() => setPagina('servico')}
      style={{
        backgroundColor: '#123B70',
        padding: 14,
        borderRadius: 8,
        marginTop: 20,
        alignItems: 'center',
      }}
    >
      <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
        Voltar às vagas
      </Text>
    </Pressable>
      </>
    )}
  </View>
)}

{pagina === 'inicio' && (
  <>
        <Text style={estilos.tituloPrincipal}>
          Tudo o que precisa, num só lugar.
        </Text>

        <Text style={estilos.textoIntroducao}>
          Emprego, compras, estudos e serviços para o seu dia a dia.
        </Text>

        <Text style={estilos.tituloServicos}>Os nossos serviços</Text>

        <View style={estilos.grelha}>
          {servicos.map((servico) => (
            <Pressable
              key={servico.titulo}
              style={estilos.cartao}
             onPress={() => {
  setServicoSelecionado(servico.titulo);
  setPagina('servico');
}}
            >
              <Text style={estilos.emoji}>{servico.emoji}</Text>
              <Text style={estilos.tituloCartao}>{servico.titulo}</Text>
              <Text style={estilos.descricaoCartao}>
                {servico.descricao}
              </Text>
            </Pressable>
          ))}
        </View>

        {(sessaoCandidato || sessaoEmpresa || sessaoAdmin) && (
          <View style={{ marginTop: 8, marginBottom: 8 }}>
            <Text style={estilos.tituloServicos}>Contas com sessão iniciada</Text>
            {sessaoCandidato && (
              <Pressable
                onPress={() => terminarSessao('candidato')}
                style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#D6E2F0', borderRadius: 10, padding: 12, marginBottom: 8 }}
              >
                <Text style={{ color: '#17345F', fontWeight: 'bold' }}>Terminar sessão de candidato</Text>
                <Text style={estilos.descricaoCartao}>{sessaoCandidato.user?.email || 'Conta de candidato'}</Text>
              </Pressable>
            )}
            {sessaoEmpresa && (
              <Pressable
                onPress={() => terminarSessao('empresa')}
                style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#D6E2F0', borderRadius: 10, padding: 12, marginBottom: 8 }}
              >
                <Text style={{ color: '#17345F', fontWeight: 'bold' }}>Terminar sessão de empresa</Text>
                <Text style={estilos.descricaoCartao}>{sessaoEmpresa.user?.email || 'Conta de empresa'}</Text>
              </Pressable>
            )}
            {sessaoAdmin && (
              <Pressable
                onPress={() => terminarSessao('admin')}
                style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#D6E2F0', borderRadius: 10, padding: 12, marginBottom: 8 }}
              >
                <Text style={{ color: '#17345F', fontWeight: 'bold' }}>Terminar sessão administrativa</Text>
                <Text style={estilos.descricaoCartao}>{sessaoAdmin.user?.email || 'Conta administrativa'}</Text>
              </Pressable>
            )}
          </View>
        )}

        <Text style={estilos.rodape}>
          RNO • Oportunidades para todos
        </Text>         <Pressable
          onPress={() => setPagina('empresa')}
          style={{
            backgroundColor: '#123B70',
            padding: 14,
            borderRadius: 10,
            marginTop: 16,
            alignItems: 'center',
          }}
        >
          <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
            Área da Empresa
          </Text>
               </Pressable>

        <Pressable
          onPress={() => {
            setMensagemAdmin('');
            setPagina('loginAdmin');
          }}
          style={{
            backgroundColor: '#07152E',
            padding: 14,
            borderRadius: 10,
            marginTop: 12,
            marginBottom: 20,
            alignItems: 'center',
            borderWidth: 1,
            borderColor: '#1769FF',
          }}
        >
          <Text style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
            🔐 Área Administrativa
          </Text>
        </Pressable>
      </>
)}
      </ScrollView>
    </SafeAreaView>
  );
}

const estilos = StyleSheet.create({
  fundo: {
    flex: 1,
    backgroundColor: '#F3F6FC',
  },
  cabecalho: {
    backgroundColor: '#123B8B',
    paddingTop: 28,
    paddingBottom: 28,
    paddingHorizontal: 22,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  logo: {
    color: '#FFFFFF',
    fontSize: 36,
    fontWeight: 'bold',
    letterSpacing: 2,
  },
  subtitulo: {
    color: '#DCE8FF',
    fontSize: 11,
    marginTop: 4,
    letterSpacing: 1,
  },
  conteudo: {
    padding: 20,
    paddingBottom: 35,
  },
  input: {
  backgroundColor: '#FFFFFF',
  borderWidth: 1,
  borderColor: '#D6E2F0',
  borderRadius: 8,
  padding: 12,
  marginTop: 6,
  color: '#172B4D',
},
  tituloPrincipal: {
    color: '#172B4D',
    fontSize: 25,
    fontWeight: 'bold',
    lineHeight: 32,
    marginTop: 8,
  },
  textoIntroducao: {
    color: '#65738B',
    fontSize: 14,
    lineHeight: 21,
    marginTop: 8,
    marginBottom: 25,
  },
  tituloServicos: {
    color: '#172B4D',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  grelha: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  cartao: {
    backgroundColor: '#FFFFFF',
    width: '48%',
    minHeight: 145,
    padding: 15,
    marginBottom: 14,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#E3EAF5',
  },
  emoji: {
    fontSize: 29,
    marginBottom: 12,
  },
  tituloCartao: {
    color: '#172B4D',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 6,
  },
  descricaoCartao: {
    color: '#65738B',
    fontSize: 12,
    lineHeight: 18,
  },
  rodape: {
    color: '#65738B',
    textAlign: 'center',
    marginTop: 20,
    fontSize: 12,
  },
});