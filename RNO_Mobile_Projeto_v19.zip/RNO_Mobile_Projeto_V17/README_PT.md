# RNO Mobile V16

Versão baseada no App.js original preservado nas versões anteriores. Esta versão liga a interface da empresa à listagem restrita de entregadores ativos e à RPC de atribuição, com uma RPC de entregas que devolve o nome do entregador atual.

Leia `COMEÇAR_AQUI_PT.md` e `docs/ALTERACOES_V16.md` antes de executar.
