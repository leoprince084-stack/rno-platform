# RNO V14 — Confirmar estados aceites pelas funções de entregas

## Por que existe esta etapa

O código original já chama estas RPCs do Supabase:

- `atualizar_estado_entrega(p_entrega_id, p_novo_estado)`
- `atualizar_estado_entregador(p_entrega_id, p_novo_estado)`
- `solicitar_entrega`
- `entregas_empresa`
- `minhas_entregas`
- `minhas_entregas_como_entregador`

O código do cliente não contém a definição das RPCs nem a lista autoritativa de estados permitidos. Não devemos adivinhar estados e expor botões que poderão falhar ou permitir transições inválidas.

## Como consultar as definições sem alterar dados

1. Abrir o dashboard do Supabase do projeto original `bwkpmirlwrsbeiavzapm`.
2. Abrir **SQL Editor** e criar uma consulta nova.
3. Copiar todo o conteúdo de `supabase/CONSULTAR_FUNCOES_ENTREGA.sql` para o editor.
4. Executar a consulta. É um `SELECT` sobre os metadados de funções PostgreSQL; não cria nem atualiza nada.
5. Copiar o resultado das linhas das funções `atualizar_estado_entrega` e `atualizar_estado_entregador` e partilhá-lo para revisão. Se possível, incluir também as funções de consulta e solicitação de entrega.

Antes de partilhar, verificar se alguma definição contém dados ou segredos privados. As definições normais de funções não devem conter chaves de serviço; se aparecer alguma credencial, removê-la do texto antes de partilhar.

## O que faremos com o resultado

Depois de conhecer a assinatura real, as condições de autorização e os estados que a função valida, poderemos adicionar controlos à interface para empresa e entregador com apenas as transições suportadas pelo backend. Não será necessário alterar as RPCs ou as políticas.

## Escopo desta versão

- Nenhuma tabela, função, política, bucket ou dado foi alterado.
- Nenhum estado de entrega foi inventado.
- `App.js` e a cópia original de segurança foram mantidos.
- Esta é uma versão de diagnóstico/documentação, não uma nova implementação de controlos de estado.
