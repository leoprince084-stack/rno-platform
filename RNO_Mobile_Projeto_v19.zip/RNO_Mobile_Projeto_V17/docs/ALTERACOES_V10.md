# RNO Mobile V10 — fluxo de vagas e candidaturas

## Objetivo

Melhorar o percurso de consulta de vagas e candidatura no código Expo/React Native existente, sem criar ou alterar estruturas no Supabase.

## Alterações feitas em `App.js`

1. **Ação “Procurar vagas”:** deixou de mostrar apenas um alerta de demonstração. Agora limpa a pesquisa e os filtros, remove os detalhes selecionados e desloca a página para a secção das vagas.
2. **Retomar candidatura após login:** quando a pessoa seleciona uma vaga antes de iniciar sessão, a vaga fica guardada no estado da aplicação. Depois de um login de candidato bem-sucedido, a aplicação regressa ao formulário dessa vaga, em vez de a mandar apenas para o menu de emprego.
3. **Preenchimento dos dados da candidatura:** após o login, a aplicação tenta ler `nome_completo`, `telefone` e `email` do perfil do candidato autenticado. Se a consulta não estiver disponível, recorre aos metadados da conta/email e não bloqueia o login por falha deste preenchimento auxiliar.
4. **Registo com sessão imediata:** quando o Supabase devolve uma sessão ao criar a conta do candidato, os dados básicos são preenchidos e, se houver uma vaga selecionada, o fluxo continua para a candidatura.
5. **Proteção de áreas de candidato:** os atalhos “Minhas candidaturas” e “Meu perfil” encaminham para o login quando não existe uma sessão de candidato válida.
6. **Verificação de candidatura repetida:** antes de inserir uma candidatura, a aplicação faz uma consulta de leitura por `candidato_id` e `vaga_id`. Se já encontrar uma candidatura, informa o utilizador e mostra o estado existente. Esta é uma proteção de interface para tentativas sequenciais; não impede duas requisições concorrentes. Uma garantia completa contra duplicados simultâneos exigiria uma restrição/garantia no backend, que deliberadamente não foi alterado nesta versão.
7. **Guarda do formulário:** o ecrã de candidatura verifica que existe uma sessão de candidato e uma vaga selecionada antes de mostrar o formulário válido.

## Backend e segurança

- Não foram criadas nem alteradas tabelas, colunas, funções RPC, políticas RLS, buckets ou dados Supabase.
- A consulta prévia de duplicados depende das permissões de leitura já existentes na tabela `candidaturas`. Se essas permissões não permitirem ao candidato ler as próprias candidaturas, o envio é interrompido com uma mensagem; não se contorna RLS.
- A aplicação continua a usar o endpoint e a chave publicável já presentes no código original. Não foi adicionada nenhuma chave administrativa.
- `docs/App_original_backup.js` foi preservado e continua a corresponder byte a byte ao `App.js` original entregue pelo utilizador.

## Validação feita

- Parser TypeScript para JSX/JavaScript: sem erros de sintaxe.
- Ficheiros JSON: validação a executar no pacote final.
- Integridade do ZIP: validação a executar no pacote final.
- Não foi possível executar um build Expo completo, nem teste funcional em dispositivo, nem pedidos autenticados reais ao Supabase neste ambiente.
