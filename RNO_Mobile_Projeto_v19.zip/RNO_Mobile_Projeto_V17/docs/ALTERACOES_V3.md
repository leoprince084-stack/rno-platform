# Alterações na versão 3

Esta versão parte da versão 2 e mantém o `App.js` original preservado em `docs/App_original_backup.js`.

## Alterações feitas

1. O botão de terminar sessão agora limpa a sessão local e tenta chamar o endpoint de logout do Supabase (`POST /auth/v1/logout`) com o access token da sessão correspondente.
2. A aplicação informa se o servidor confirmou o logout ou se só foi possível limpar a sessão local.
3. Removidos logs de diagnóstico que mostravam URLs de imagens, contagens de produtos e o identificador da conta da empresa no console.
4. Mantidos os adaptadores de armazenamento por plataforma: `storage.web.js` usa `sessionStorage` no navegador e `storage.native.js` usa AsyncStorage em iOS/Android.

## O que não foi alterado

- Não foram feitas chamadas à base de dados Supabase.
- Não foram criadas ou alteradas tabelas, dados, RPCs, políticas ou buckets.
- Não foram incluídas chaves de serviço/admin; a chave publishable já presente no código original foi preservada.
- Não foi alterada a versão das dependências.

## Validação nesta entrega

- `App.js` passou a análise sintática com o compilador TypeScript usado apenas como parser JSX/JavaScript.
- Os ficheiros JSON foram validados por parser JSON.
- O arquivo ZIP foi verificado com `unzip -t`.
- Não foi possível executar `npm install`, `expo start` ou um build real nesta sessão porque o acesso ao registo de pacotes não está disponível. Portanto, não afirmar que a aplicação foi compilada ou testada num dispositivo.
