# RNO V16 — atribuição de entregadores

## O que mudou na app
- A secção de entregas da empresa passa a consultar `empresa_entregas_com_atribuicao()`, RPC nova incluída no SQL V16.
- A empresa pode abrir a lista de entregadores ativos pela RPC já existente `empresa_listar_entregadores_ativos()`.
- A atribuição chama a RPC existente `atribuir_entrega(p_entrega_id, p_entregador_id)`.
- A interface mostra o entregador atribuído, usando `entregador_id` e `entregador_nome` devolvidos pela RPC de detalhe.
- Os pedidos têm estado de carregamento, mensagens de erro e prevenção de pedidos simultâneos no cliente.

## SQL necessário antes de usar esta versão
Execute `supabase/V16_EMPRESAS_ATRIBUICAO_ENTREGAS.sql` no SQL Editor do projeto Supabase original, depois de rever o conteúdo. O script cria `empresa_entregas_com_atribuicao()` e reforça `atribuir_entrega()` para recusar uma segunda atribuição. Não cria tabelas nem altera linhas existentes.

A função `empresa_listar_entregadores_ativos()` foi confirmada pelo utilizador como criada e executável por `authenticated`.

## Segurança e limitações
- O SQL assume, conforme o esquema e o código existente, que `public.empresas.id = auth.uid()` para empresas e que `public.entregadores.id = auth.uid()` para entregadores.
- A aplicação não usa `admin_listar_entregadores()` para contas de empresa.
- Não foi executado SQL no Supabase a partir deste ambiente; o script precisa de ser executado pelo utilizador.
- Não foi realizado build completo do Expo nem teste autenticado ponta a ponta. Validações estáticas apenas.
