# RNO Mobile V12 — revisão de loja e encomendas

## Base
A V12 parte da V11. `docs/App_original_backup.js` continua a preservar o App.js recebido originalmente. Não foram feitas operações de escrita no Supabase.

## Alterações

1. **Consulta dos artigos de encomenda:** removida a coluna `imagem_url` da seleção REST em `itens_encomenda`. A estrutura documentada anteriormente não inclui essa coluna; a seleção podia fazer falhar a consulta dos artigos. A interface mantém um estado alternativo quando não existe imagem.
2. **Quantidade no carrinho:** acrescentados controlos para diminuir/aumentar quantidade e limite de stock apresentado no catálogo. A RPC `criar_encomenda` continua a ser a autoridade final para validar o stock real no servidor.
3. **Validação no checkout:** impede cliques repetidos durante o processamento e valida ID, preço, quantidade e stock local antes de chamar a RPC existente.
4. **Resposta da encomenda:** a mensagem de sucesso deixa de mostrar `null` ou `[object Object]` quando a RPC devolve um formato diferente; apresenta o identificador quando existe.
5. **Publicação do produto:** a chamada PATCH usa `Prefer: return=representation` e exige uma linha atualizada na resposta antes de afirmar sucesso, evitando confirmação falsa quando nenhum registo corresponde aos filtros. A operação continua sujeita às políticas Supabase existentes.

## Integridade e segurança
- Não foram criadas tabelas, colunas, RPCs, políticas ou buckets.
- Não foram realizadas escritas no backend.
- Nenhuma credencial nova foi acrescentada.
- O ficheiro `docs/App_original_backup.js` permanece intacto.

## Verificações
- Análise sintática JavaScript/JSX com o parser/transpiler TypeScript: 0 erros de sintaxe e 0 diagnósticos de transpile.
- `package.json`, `app.json` e `eas.json`: JSON válido.
- Cópia `docs/App_original_backup.js`: idêntica ao `App.js` original fornecido (SHA-256 `2edec288d5cfa983a2e6e76d9e1ecf457fb96c8ce8d5da3ae90f2a6e1b5eacea`).
- ZIP: será validado depois de gerado.

## Limitações
Não foi possível executar um build completo do Expo, executar a aplicação num dispositivo ou testar com autenticação real no Supabase neste ambiente. Antes de produção, testar consulta de encomendas do cliente, publicação de um produto de teste e criação de encomenda autorizada.
