# RNO Mobile V17 — estado de atribuição visível

## Base
- Base de código: V16 do projeto de continuidade.
- `docs/App_original_backup.js` permanece a cópia preservada do App.js original.
- `docs/App_V16_backup.js` guarda o App.js antes das pequenas alterações da V17.

## Alterações de interface
1. Mostra `entregador_nome` (ou `entregador_id` como fallback) quando a entrega tem `entregador_id`, independentemente do estado da entrega.
2. Mostra `atribuido_em` formatado no cartão quando está disponível.
3. Remove a repetição do nome do entregador no bloco de ação de `Aguardando recolha`, deixando aí apenas a orientação de acompanhar a atualização do estado.
4. Corrige o texto de ajuda para explicar que a empresa autoriza recolha em `Aguardando atribuição` e atribui o entregador ativo em `Aguardando recolha`.

## Contratos do backend confirmados pelo utilizador
- `empresa_listar_entregadores_ativos()` — retorna `id`, `nome_completo`, `telefone`, `provincia`; `SECURITY DEFINER`; EXECUTE para `authenticated`.
- `empresa_entregas_com_atribuicao()` — retorna dados da entrega incluindo `entregador_id` e `entregador_nome`; `SECURITY DEFINER`; EXECUTE para `authenticated`.
- `atribuir_entrega(p_entrega_id uuid, p_entregador_id uuid)` — função existente do projeto.
- `atualizar_estado_entrega(p_entrega_id uuid, p_novo_estado text)` — para a empresa: `Aguardando atribuição` para `Aguardando recolha` ou `Cancelada`.
- `atualizar_estado_entregador(p_entrega_id uuid, p_novo_estado text)` — para o entregador, transições sequenciais conforme a definição existente.

O utilizador confirmou ainda que o RLS está ativo em `entregadores` e `entregas`, e que `authenticated` não tem privilégios diretos SELECT/UPDATE nessas tabelas. A interface, portanto, continua a usar as RPCs; não se devem adicionar permissões diretas só para fazer a interface funcionar.

## Verificação e limitações
- Foram verificadas as alterações textuais da V17 e a consistência dos ficheiros JSON.
- O ZIP final será validado com `unzip -t`.
- Não foi executado build Expo completo, teste num dispositivo nem teste autenticado de ponta a ponta nesta sessão.
- Nenhuma tabela, política ou registo do Supabase foi alterado ao preparar esta versão.
