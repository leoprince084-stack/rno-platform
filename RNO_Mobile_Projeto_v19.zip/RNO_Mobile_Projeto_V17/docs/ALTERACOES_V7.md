# Alterações V7 — Registo de empresas com confirmação de email

## Problema abordado

Na versão anterior, se o Supabase exigisse confirmação de email no registo de uma empresa, o endpoint de signup podia devolver uma conta sem `access_token`. O fluxo mostrava uma mensagem, mas não oferecia um percurso completo caso não existisse um perfil na tabela `empresas` depois da confirmação.

## Alterações no `App.js`

- Normaliza o email de empresa com `trim().toLowerCase()` e valida um formato básico antes do signup/login.
- Acrescenta confirmação da palavra-passe ao formulário de registo de empresa.
- Quando o signup não devolve uma sessão, não tenta escrever no REST sem token; orienta a pessoa a confirmar o email e depois iniciar sessão. Também avisa para não repetir o registo.
- Após login autenticado, recusa contas cujo metadado `tipo_conta` identifica explicitamente outro tipo de conta e consulta primeiro o perfil de empresa usando o `id` do utilizador autenticado.
- Se o perfil não existir e os metadados do utilizador tiverem todos os campos necessários, tenta um `INSERT` com o token autenticado. Não utiliza um upsert cego.
- Se faltarem metadados ou a criação automática falhar, abre um ecrã para completar o perfil já autenticado.
- O ecrã de conclusão consulta novamente o perfil se a escrita falhar, para cobrir o caso em que outro processo (por exemplo, um trigger existente) tenha criado o registo entretanto.
- Permite terminar a sessão pendente e regressar ao login sem guardar a sessão incompleta no estado de empresa ativo.

## O que não foi alterado

- Nenhuma tabela, coluna, trigger, função RPC, política RLS, conta ou registo no Supabase.
- Nenhum endereço, chave pública ou segredo do Supabase.
- O `docs/App_original_backup.js` permanece uma cópia intacta do `App.js` original fornecido.
- Não foram adicionadas dependências.

## Validação

- Parser TypeScript validou a sintaxe JSX/JavaScript: sem erros sintáticos.
- Os ficheiros JSON de configuração foram validados.
- O ZIP foi testado quanto à integridade.
- Não foi executado um build Expo completo nem uma inscrição/login real, para evitar criar contas reais ou escrever na base de dados sem um teste aprovado.

## Dependências do backend

O fluxo usa os contratos existentes do projeto: `POST /auth/v1/signup`, login por password, e tabela REST `public.empresas` com `id` igual ao UUID do utilizador autenticado. A criação do perfil após login precisa que as políticas RLS existentes permitam ao utilizador autenticado inserir o seu próprio perfil. Se a política atual não permitir essa operação e não existir trigger que crie o perfil, será necessário rever a política/trigger separadamente, com confirmação explícita; esta revisão não muda o backend.
