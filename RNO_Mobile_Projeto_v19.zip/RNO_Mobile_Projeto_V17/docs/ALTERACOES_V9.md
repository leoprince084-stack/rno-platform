# Alterações V9 — recuperação de palavra-passe

## O que foi acrescentado

- Ecrã `recuperarSenha` com validação básica do email e estado de envio.
- Ação `Esqueci-me da palavra-passe` disponível nos acessos de candidato, empresa e administrador.
- O botão de regresso volta ao ecrã de acesso de onde o utilizador iniciou a recuperação.
- Pedido de recuperação através do endpoint Auth do Supabase `/auth/v1/recover`, com redirecionamento para a página de recuperação web existente da RNO (`nova-senha.html`).
- Mensagem de sucesso genérica, para não revelar se um email está registado.
- Mensagens específicas para limite de pedidos (HTTP 429) e falhas de ligação.

## Importante

- A conclusão da alteração continua a depender da página `https://leoprince084-stack.github.io/rno-platform/nova-senha.html` estar publicada e de a URL estar permitida na configuração Redirect URLs do Supabase Auth.
- Não foram feitas chamadas reais ao Supabase; não foram enviadas mensagens de recuperação durante esta entrega.
- Não foram alteradas tabelas, dados, RPCs, políticas, buckets nem configurações Supabase.
- Não foram adicionadas dependências.
- `docs/App_V8_backup.js` preserva o App.js que serviu de base à V9; `docs/App_original_backup.js` continua a preservar o código original do projeto.

## Validação realizada

- Análise sintática JSX/JavaScript pelo parser TypeScript: sem erros de parse.
- Ficheiros JSON: válidos.
- Arquivo ZIP: integridade validada.
- Não foi executado build Expo, nem teste funcional no dispositivo ou no Supabase real.
