# Alterações na versão 2

1. Criado `lib/storage.web.js` para `localStorage`.
2. Criado `lib/storage.native.js` para AsyncStorage em iOS/Android.
3. Criado fallback `lib/storage.js` para ferramentas sem resolução de plataforma.
4. `App.js` restaura sessões salvas e tenta renovar `access_token` com o `refresh_token` na abertura.
5. Adicionados botões de terminar sessão na página inicial para candidato, empresa e administrador.
6. Adicionada a dependência `@react-native-async-storage/async-storage` ao `package.json`.

Não foram feitas operações no backend Supabase.
