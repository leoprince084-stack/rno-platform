# Auditoria estática RNO — versão 5

Data: 25 de outubro de 2026
Base de trabalho: `App.js` original recuperado e pacote de continuidade V4.

## Correções feitas nesta revisão

1. **Carga da lista administrativa após o login:** `entrarAdmin()` atualizava `sessaoAdmin` e chamava imediatamente `carregarEntregadoresAdmin()`. Como a atualização de estado React é assíncrona, a função podia ler a sessão anterior (nula) e não carregar a lista. A função agora aceita a sessão como parâmetro e recebe a sessão recém-autenticada nesse primeiro carregamento.
2. **Saída do painel administrativo:** o botão “Sair da área administrativa” apenas limpava o estado local. Agora utiliza `terminarSessao('admin')`, o mesmo fluxo que remove a sessão guardada e tenta encerrar a sessão no Supabase.
3. **Estado inicial das candidaturas:** `enviarCandidatura()` não enviava `status`, enquanto o outro formulário de candidatura do mesmo `App.js` enviava explicitamente `Em análise`. O campo agora é incluído para manter o comportamento consistente.

## Pontos encontrados que exigem confirmação ou trabalho posterior

1. **Registo de candidato:** no `App.js` analisado existe login de candidato, mas não foi encontrada uma função/ecrã de registo de candidato. O fluxo de criação de contas de candidato deve ser implementado depois de confirmarmos os campos e o trigger já existente no Supabase.
2. **Registo de empresa com confirmação de email ativa:** `cadastrarEmpresa()` termina o fluxo do lado do cliente quando a resposta de signup não contém `access_token`. Isso é prudente para não escrever no perfil com token vazio, mas o perfil da empresa só será criado nesse cenário se já existir um trigger/fluxo backend que o faça. Deve ser verificado com uma conta de teste, sem criar registos duplicados.
3. **Módulos demonstrativos:** Estudos, Serviços, Comunicação, Publicidade e Finanças usam dados/estados locais; ainda não são módulos persistentes no backend. Táxi apenas prepara um pedido local, e Pagamentos é informativo, sem processador de pagamentos ligado.
4. **Dependência do backend:** candidaturas, produtos, encomendas e entregas dependem das tabelas, RPCs, Storage e políticas RLS existentes. A auditoria do código cliente não prova que todas as permissões/rotinas do Supabase estejam corretamente configuradas.
5. **Sessões no armazenamento web:** tokens são guardados no armazenamento do navegador para permitir persistência. Em computadores partilhados, terminar sessão depois do teste. A segurança dos dados continua dependente das políticas RLS do Supabase.

## Validações executadas nesta revisão

- Verificação sintática de `App.js` com o parser TypeScript/JSX.
- Validação de JSON de `package.json`, `app.json` e `eas.json`.
- Verificação de que `docs/App_original_backup.js` é idêntico ao `App.js` original recuperado.
- Verificação de integridade do ZIP criado.

## Limites

Não foi executado `npm install`, build Expo, nem teste autenticado contra o Supabase nesta execução. Não foram criadas tabelas/migrações nem alterados dados do Supabase.
