# Alterações da V14

- Conservado o código de aplicação de V13 sem acrescentar estados de entrega não confirmados.
- Adicionada consulta somente leitura para obter assinatura e definição das RPCs relacionadas com entregas.
- Adicionado guia em português para executar a consulta no projeto Supabase original e devolver os resultados para análise.
- Nenhuma tabela, função, política, bucket ou dado foi alterado.
- Não foi feito build completo do Expo nem teste no dispositivo.
