# Alterações V5

- Corrigida a carga inicial de entregadores após autenticação administrativa: a sessão recém-obtida é passada diretamente à função de carregamento.
- Botão de saída do painel administrativo passou a usar o fluxo comum de encerramento de sessão.
- O envio de candidaturas pela função partilhada passou a enviar `status: 'Em análise'`, alinhado com o outro formulário.
- A auditoria estática e os pontos não confirmados constam em `AUDITORIA_V5.md`.

Nenhum dado ou configuração do Supabase foi modificado. Não foi realizado build Expo nem teste de integração com contas reais.
