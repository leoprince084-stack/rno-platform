# RNO Mobile V11 — gestão de vagas pela empresa

## Base utilizada

A V11 parte da V10 e preserva o `App.js` original em `docs/App_original_backup.js`, além de manter `docs/App_V10_backup.js` como referência da versão anterior.

## Alterações nesta versão

1. **Publicação de vagas no painel da empresa:** foi adicionado um formulário ao painel que o login de empresa já abre (`painelVendedor`). Campos obrigatórios: título, localização, tipo de emprego e descrição. Requisitos, salário e contacto informado são opcionais; quando o contacto estiver vazio, usa-se o telefone do perfil da empresa, se disponível.
2. **Associação ao perfil autenticado:** antes de publicar, a aplicação consulta o perfil `empresas` com o ID da sessão atual. O `empresa` e `empresa_id` da vaga são obtidos desse perfil/sessão, não de um campo de nome livre.
3. **Persistência na tabela existente:** a publicação usa `POST /rest/v1/vagas` com os campos já utilizados pelo esquema e restantes módulos: `titulo`, `empresa`, `empresa_id`, `localizacao`, `tipo`, `descricao`, `requisitos`, `salario`, `contacto`. Não são criadas tabelas, colunas, políticas ou funções.
4. **Lista “As minhas vagas”:** acrescentada consulta autenticada filtrada por `empresa_id` da sessão. A lista apresenta títulos, localização, tipo, salário e descrição.
5. **Acesso às candidaturas recebidas:** o painel da empresa tem agora um botão direto para a página existente de gestão de candidaturas. A página de gestão tem uma ação de retorno ao painel da empresa quando já existe sessão.
6. **Verificação do estado da candidatura:** a ação de atualização valida o estado permitido, verifica se a vaga relacionada está associada ao ID da empresa autenticada e pede `return=representation`. Se o Supabase não devolver uma linha atualizada, a interface não afirma sucesso e indica que as políticas RLS podem estar a bloquear a operação.

## Segurança e limites

- Não houve pedidos de escrita ao Supabase durante esta alteração.
- Não foram modificadas tabelas, dados, RPCs, políticas RLS, buckets nem configurações.
- A validação no cliente melhora o fluxo da interface, mas **não substitui as políticas RLS do servidor**. A segurança efetiva de INSERT em `vagas` e UPDATE em `candidaturas` depende das políticas já configuradas no Supabase.
- Se a publicação falhar, a aplicação apresenta o código HTTP e a mensagem devolvida pelo Supabase. Não se deve criar uma política nova sem primeiro rever a política e o esquema existentes.

## Verificações realizadas

- Análise sintática JavaScript/JSX através do transpiler TypeScript: aprovada.
- `package.json`, `app.json` e `eas.json`: JSON válido.
- Verificados por pesquisa estática: endpoint correto `/rest/v1/vagas`, validação de sessão, consulta do perfil da empresa, filtro de vagas por `empresa_id`, validação da empresa relacionada ao atualizar candidatura.
- `docs/App_original_backup.js` continua idêntico ao `App.js` original fornecido.
- Integridade do ZIP final: verificada.

## Testes ainda necessários

Não foi executado build completo do Expo, não houve login real nem pedidos de escrita à base de dados. Antes de usar em produção, testar num ambiente de execução com uma conta empresarial de teste e uma vaga de teste. A publicação cria uma vaga real e poderá torná-la visível conforme as permissões e consultas públicas já existentes. Confirmar também as políticas RLS da tabela `vagas` e `candidaturas` sem as alterar às cegas.
