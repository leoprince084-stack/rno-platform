# Alterações na versão 4

- O adaptador web (`lib/storage.web.js`) prefere agora `localStorage`, para manter a sessão após recarregar/reabrir o navegador.
- Se `localStorage` não estiver acessível, tenta `sessionStorage` como alternativa.
- O adaptador de fallback (`lib/storage.js`) segue o mesmo comportamento.
- A lógica nativa (`lib/storage.native.js`) e o código principal (`App.js`) não foram alterados nesta versão.
- Nenhuma chamada ao Supabase foi feita; não foram alteradas tabelas, dados, RPCs, políticas ou buckets.

## Limitações conhecidas

- `localStorage` torna o token de sessão acessível ao JavaScript do próprio site; manter a aplicação protegida contra XSS e terminar sessão em computadores partilhados continua importante.
- Não foi possível executar uma compilação Expo completa ou testar em dispositivo físico neste ambiente. A validação foi estática.
