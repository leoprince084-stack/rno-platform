# Alterações V8 — autenticação e restauração de sessão

## Alterações

- O login de candidato foi extraído para `entrarCandidato()`, com validação do email, proteção contra cliques repetidos e estado visual de carregamento.
- Mensagens relacionadas à confirmação de email são explicadas em português, em vez de mostrar apenas o erro bruto.
- Se os metadados indicarem explicitamente outro tipo de conta, a sessão recém-criada é terminada por best effort e o candidato é encaminhado para a área adequada.
- Para contas antigas sem `tipo_conta`, é feita uma leitura (se autorizada) do perfil `candidatos` para ajudar a distinguir o perfil. Nenhuma escrita na tabela é feita por esta verificação.
- Na restauração de sessões, candidato e empresa não são restaurados sob o papel errado quando os metadados indicam explicitamente outro tipo. Para a conta administrativa, a autorização continua dependendo da RPC de administração existente.
- Uma sessão sem `refresh_token` e com `expires_at` já expirado deixa de ser restaurada.
- O botão de login indica estado de carregamento e fica desativado durante o pedido para reduzir envios duplicados.

## Não alterado

- O Supabase, as tabelas, dados, funções RPC, políticas RLS e Storage não foram alterados.
- Não foram criadas contas nem realizadas chamadas reais de autenticação.
- Não foram introduzidas dependências.
- `docs/App_original_backup.js` continua a preservar o App.js original.

## Validação

- Sintaxe JSX/JavaScript validada com o parser TypeScript instalado: sem erros sintáticos.
- JSON de configuração validado.
- ZIP validado com `unzip -t`.
- Não foi executado build completo do Expo nem teste funcional de login em Supabase real neste ambiente.

## Observações

O login continua a usar os endpoints REST de autenticação existentes e a chave pública `publishable`. A segurança dos dados de cada utilizador continua dependente das políticas RLS já configuradas no Supabase.
