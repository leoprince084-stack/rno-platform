# Plano técnico — RNO

## Já existente no código recebido (ainda requer teste real)
- Autenticação para candidato, empresa e administrador.
- Consulta e envio de candidaturas a vagas.
- Perfil de candidato e gestão de candidaturas.
- Consulta pública de empresas/vendedores.
- Produtos, fotografia de produto, publicação, carrinho e criação de encomenda via RPC.
- Consulta de encomendas do cliente e do vendedor.
- Registo de entregadores, aprovação administrativa e consulta/alteração de estados de entregas.

## Alterações incluídas nesta cópia
- Corrigido o identificador `userId` no registo da empresa, que era utilizado sem declaração.
- Os campos do formulário empresarial deixam de ser limpos antes da gravação do perfil.
- Acrescentado tratamento para a situação em que o Supabase cria o utilizador mas não devolve `access_token` por exigir confirmação de email. Nessa situação, o aplicativo informa que é necessária verificação do perfil no Supabase.
- Acrescentado ecrã `minhasEntregas` que antes era navegado por botão, mas não tinha uma secção de apresentação de dados.
- Acrescentadas áreas iniciais de Estudos, Serviços, Táxi, Pagamentos, Comunicação, Publicidade e Finanças.

## Pendências antes de produção
1. Testar registo, confirmação de email e perfil de empresa com a configuração real do Supabase.
2. Investigar e testar pedidos de encomenda com itens de vários vendedores; não remover verificações de autorização.
3. Confirmar a estrutura devolvida por `minhas_entregas` para mapear correctamente todos os campos.
4. Criar modelos/tabelas para estudos, profissionais, mensagens, anúncios e movimentos financeiros; definir RLS antes de ligar os ecrãs.
5. Integrar um fornecedor de pagamentos aprovado e testar em ambiente sandbox antes de movimentar dinheiro real.
6. Para Táxi, integrar geolocalização com permissões, estimativa de preço, motoristas, aceitação de viagens, cancelamentos, rastreamento e segurança.
7. Tornar mensagens e movimentos financeiros persistentes, privados e controlados por utilizador.
8. Adicionar notificações, moderação, denúncia de abuso, política de privacidade e eliminação de conta.
9. Executar testes automatizados e manuais em Android/iOS; confirmar requisitos de publicação actuais.
