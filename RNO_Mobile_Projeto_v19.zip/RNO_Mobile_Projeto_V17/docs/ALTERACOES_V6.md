# Alterações V6 — Registo de candidato

1. Adicionados estados dedicados ao formulário de registo de candidato.
2. Adicionada a função `cadastrarCandidato`, que valida os campos e chama o endpoint de signup do Supabase com metadados da conta.
3. Adicionado ecrã `registoCandidato`, acessível a partir do ecrã de login.
4. Simplificado o ecrã de login e removido o bloco de candidatura duplicado que estava inserido dentro do ecrã de login; o ecrã `candidatura` independente permanece.
5. Não foi efetuado INSERT direto na tabela `candidatos`, e não foram alterados dados, tabelas, triggers, políticas, funções RPC ou Storage.

## Limites desta revisão

- Não foi efetuado um registo real para evitar criar uma conta sem confirmação explícita e sem teste controlado.
- O perfil exige que o trigger existente do Supabase consuma `raw_user_meta_data.tipo_conta = 'candidato'` e os campos enviados. Este comportamento deve ser verificado com uma conta de teste.
- Não foi executado um build Expo completo nem teste em dispositivo físico nesta revisão.
