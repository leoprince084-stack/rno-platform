# RNO V15 — controlos de estado de entregas

## Base utilizada
As definições das RPCs foram fornecidas pelo utilizador a partir do Supabase.

## Transições da empresa
`public.atualizar_estado_entrega(p_entrega_id uuid, p_novo_estado text)` aceita apenas `Aguardando recolha` e `Cancelada`, e só quando o estado atual é `Aguardando atribuição` e a entrega pertence à empresa autenticada. A interface mostra os botões apenas nesse estado.

## Transições do entregador
`public.atualizar_estado_entregador(p_entrega_id uuid, p_novo_estado text)` permite: `Aguardando recolha` → `Recolhida`; `Recolhida` → `Em trânsito`; `Em trânsito` → `Entregue` ou `Entrega falhada`. A interface só mostra o botão correspondente ao estado atual.

## Fiabilidade do cliente
- As chamadas usam `entrega_id` / ID de entrega e os tokens da sessão atual.
- Os botões são desativados enquanto uma chamada de estado está em andamento.
- O cliente só apresenta sucesso se a RPC responder HTTP OK e o resultado for booleano verdadeiro.
- Mensagens de erro JSON são extraídas quando presentes.

## Limitações
- Não foram modificadas tabelas, funções RPC, políticas, buckets ou dados.
- Não foi executado build completo do Expo, nem teste real autenticado de transições no Supabase.
- A aplicação depende das regras de autorização existentes no Supabase, que permanecem a autoridade final.
