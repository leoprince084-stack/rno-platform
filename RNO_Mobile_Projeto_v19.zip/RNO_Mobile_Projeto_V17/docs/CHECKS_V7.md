# Verificações V7

- Parser JSX/JavaScript: passou sem diagnósticos sintáticos.
- `app.json`, `package.json`, `eas.json`: JSON válidos.
- Cópia de segurança `docs/App_original_backup.js`: mantém o hash do `App.js` original fornecido.
- Verificações estáticas: o fluxo de registo exige confirmação da palavra-passe; o caminho de email de confirmação não faz INSERT sem sessão; o login de empresa rejeita tipos de conta explicitamente incompatíveis e procura um perfil por ID antes de tentar inserir; nenhum upsert cego foi introduzido no novo fluxo.
- Build Expo / execução em iOS, Android e web: não realizado neste ambiente, porque as dependências do projeto não estão instaladas aqui.
- Teste autenticado de registo/login: não realizado; evitar criação de contas ou escritas reais no Supabase sem uma conta de teste autorizada.
- Supabase: não foram feitas chamadas, escritas, migrações ou alterações às políticas nesta revisão.
