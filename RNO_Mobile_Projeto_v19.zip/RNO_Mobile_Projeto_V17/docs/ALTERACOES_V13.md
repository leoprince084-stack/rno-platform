# RNO Mobile V13 — Revisão do fluxo de entregas

## O que foi corrigido

1. **Rascunho separado por encomenda.** Antes, o endereço de recolha era parcialmente condicionado pela encomenda selecionada, mas custo e observações eram estados partilhados. Ao preencher pedidos diferentes, os valores podiam ser mostrados ou enviados junto à encomenda errada. Agora o estado do formulário é indexado pelo `encomenda_id`.
2. **Bloqueio de submissões repetidas.** O botão de pedir entrega fica desativado enquanto o pedido está em processamento e mostra o estado de carregamento.
3. **Limpeza do formulário após sucesso.** O rascunho é limpo apenas para a encomenda cujo pedido foi aceite pela resposta HTTP.
4. **Consulta de entregas da empresa.** Foi acrescentada uma secção no painel do vendedor para chamar a RPC existente `entregas_empresa`, mostrar carregamento/erro/vazio e exibir os campos que a aplicação já espera.
5. **Erros apresentados uma vez.** O erro partilhado de entregas deixou de ser repetido dentro de cada cartão de encomenda e é mostrado na secção de entregas da empresa.

## Lacuna identificada e mantida explícita

As funções `atualizar_estado_entrega` e `atualizar_estado_entregador` existem no código, mas não estavam ligadas a botões em nenhuma das vistas. Não acrescentei uma lista de estados inventada: os valores aceites por estas RPCs e as transições válidas têm de ser confirmados a partir das definições reais no Supabase antes de ligar controlos de atualização.

## Segurança e escopo

- Não foram realizadas chamadas de escrita ao Supabase.
- Não foram criadas nem alteradas tabelas, funções, políticas, dados ou buckets.
- `docs/App_original_backup.js` foi mantido intacto.

## Verificações executadas

- Análise sintática JavaScript/JSX via TypeScript transpile: 0 diagnósticos de sintaxe.
- `package.json`, `app.json`, `eas.json`: JSON válido.
- Cópia `docs/App_original_backup.js`: idêntica ao `App.js` original fornecido.
- Integridade do ZIP: será verificada após a criação do arquivo.

## Limitações

Não foi executado um build completo Expo, teste num dispositivo, nem teste autenticado no Supabase real. Os resultados da RPC `entregas_empresa` também não foram consultados em produção; a interface usa campos com alternativas compatíveis com os campos já usados no código (id/entrega_id, estado/status, endereços e telefone).
