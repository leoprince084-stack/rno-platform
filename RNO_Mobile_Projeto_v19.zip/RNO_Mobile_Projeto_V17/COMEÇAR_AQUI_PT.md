# RNO Mobile V17 — Começar aqui

Esta versão continua o projeto Expo/React Native original e integra a confirmação do backend fornecida pelo utilizador.

## Backend de entregas
O utilizador confirmou no Supabase que `public.empresa_entregas_com_atribuicao()` existe, devolve os campos da entrega e do entregador, é `SECURITY DEFINER` e concede `EXECUTE` ao papel `authenticated`.
O utilizador também confirmou que `public.empresa_listar_entregadores_ativos()` existe e pode ser executada por `authenticated`.

**Não execute novamente scripts SQL só por causa desta versão.** As duas RPCs acima já foram confirmadas pelo utilizador. A interface usa ainda a função existente `public.atribuir_entrega(p_entrega_id, p_entregador_id)`.

## Alteração V17
- O cartão da entrega mostra o nome/ID do entregador atribuído e a data de atribuição em todos os estados, não apenas quando a entrega está em `Aguardando recolha`.
- A mensagem de ajuda descreve corretamente as duas etapas da empresa: autorizar a recolha e depois atribuir um entregador ativo.

## Como testar quando o ambiente estiver disponível
1. Entrar como uma conta de empresa que tenha perfil em `public.empresas`.
2. Abrir as entregas da empresa e atualizar a lista.
3. Para uma entrega em `Aguardando atribuição`, autorizar a recolha.
4. Quando a entrega aparecer em `Aguardando recolha`, abrir a lista de entregadores ativos e atribuir um entregador aprovado/ativo.
5. Confirmar que o nome do entregador aparece na entrega.
6. Entrar com essa conta de entregador e testar a sequência permitida: `Aguardando recolha` → `Recolhida` → `Em trânsito` → `Entregue` ou `Entrega falhada`.

Não foram executadas operações reais de escrita no backend a partir deste pacote. Ainda é necessário testar no ambiente Expo com sessões reais.
